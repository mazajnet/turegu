<?php

// Handle installation
Route::group(['middleware' => 'install'], function(){
/*
|--------------------------------------------------------------------------
| System Routes
|--------------------------------------------------------------------------
*/
Auth::routes();

/*
|--------------------------------------------------------------------------
| Administrator Routes
|--------------------------------------------------------------------------
*/
Route::group(['middleware' => 'admin'], function(){

    // Admin routes
    Route::get('/admin/logout', 'Admin\AdminLoginController@logout')->name('admin_logout');
    Route::get('/admin/dashboard','Admin\AdminLoginController@dashboard')->name('admin_dashboard');
    Route::get('/admin/my_account','Admin\AdminController@index')->name('admin_my_account');
    Route::put('/admin/my_account/update/{id}','Admin\AdminController@update')->name('admin_my_account_update');

    // Additional Blog Routes
    Route::post('/admin/blog/activate/{id}', 'Admin\AdminBlogController@activate');
    Route::post('/admin/blog/deactivate/{id}', 'Admin\AdminBlogController@deactivate');
    Route::get('/admin/blog/autocomplete/', 'Admin\AdminBlogController@autocomplete');
    Route::post('/admin/blog/search/', 'Admin\AdminBlogController@search')->name('admin_blog_search');
    Route::post('/admin/blog/massdestroy', 'Admin\AdminBlogController@massDestroy');
    Route::post('/admin/blog/deleteImage/{id}', 'Admin\AdminBlogController@deleteFeatured');

    // Additional Page Routes
    Route::post('/admin/page/activate/{id}', 'Admin\AdminPageController@activate');
    Route::post('/admin/page/deactivate/{id}', 'Admin\AdminPageController@deactivate');
    Route::get('/admin/page/autocomplete/', 'Admin\AdminPageController@autocomplete');
    Route::post('/admin/page/search/', 'Admin\AdminPageController@search')->name('admin_page_search');
    Route::post('/admin/page/massdestroy', 'Admin\AdminPageController@massDestroy');

    Route::post('/admin/faq/massdestroy', 'Admin\AdminFaqController@massDestroy');

    // Additional Project Routes
    Route::post('/admin/project/activate/{id}', 'Admin\AdminProjectController@activate');
    Route::post('/admin/project/deactivate/{id}', 'Admin\AdminProjectController@deactivate');
    Route::post('/admin/project/makefeatured/{id}', 'Admin\AdminProjectController@makeFeatured');
    Route::post('/admin/project/makedefault/{id}', 'Admin\AdminProjectController@makeDefault');
    Route::get('/admin/project/autocomplete/', 'Admin\AdminProjectController@autocomplete');
    Route::post('/admin/project/search/', 'Admin\AdminProjectController@search')->name('admin_project_search');
    Route::post('/admin/project/massdestroy', 'Admin\AdminProjectController@massDestroy');

    // Additional Property Routes
    Route::post('/admin/property/activate/{id}', 'Admin\AdminPropertyController@activate');
    Route::post('/admin/property/deactivate/{id}', 'Admin\AdminPropertyController@deactivate');
    Route::post('/admin/property/makefeatured/{id}', 'Admin\AdminPropertyController@makeFeatured');
    Route::post('/admin/property/makedefault/{id}', 'Admin\AdminPropertyController@makeDefault');
    Route::get('/admin/property/autocomplete/', 'Admin\AdminPropertyController@autocomplete');
    Route::post('/admin/property/search/', 'Admin\AdminPropertyController@search')->name('admin_property_search');
    Route::post('/admin/property/massdestroy', 'Admin\AdminPropertyController@massDestroy');

    // Site Settings Controller Routes
    Route::get('/admin/settings/site_settings', 'Admin\AdminSiteSettingsController@index')->name('admin_site_settings');
    Route::post('admin/settings/site_settings/insert', 'Admin\AdminSiteSettingsController@insert')->name('admin_site_settings_update');
    
    // User Settings Controller Routes
    Route::get('/admin/settings/user_settings', 'Admin\AdminUserSettingsController@index')->name('admin_user_settings');
    Route::post('admin/settings/user_settings/insert', 'Admin\AdminUserSettingsController@insert')->name('admin_user_settings_update');
    
    // Purchase Controller Routes
    Route::get('/admin/company/purchase', 'Admin\AdminPurchaseController@index')->name('admin_company_purchase');

    // Activity Controller Routes
    Route::get('/admin/company/activity', 'Admin\AdminActivityController@index')->name('admin_company_activity');

    // Activity Controller Routes
    Route::get('/admin/request', 'Admin\AdminRequestController@index')->name('admin_requests');

    // Property Settings Controller Routes
    Route::get('/admin/settings/payment_settings', 'Admin\AdminPaymentSettingsController@index')->name('admin_payment_settings');
    Route::post('admin/settings/payment_settings/insert', 'Admin\AdminPaymentSettingsController@insert')->name('admin_payment_settings_update');

    // Property Settings Controller Routes
    Route::get('/admin/settings/design_settings', 'Admin\AdminDesignSettingsController@index')->name('admin_design_settings');
    Route::post('admin/settings/design_settings/insert', 'Admin\AdminDesignSettingsController@insert')->name('admin_design_settings_update');

    // Language Settings Controller Routes
    Route::get('/admin/settings/language', 'Admin\AdminLanguageController@index')->name('admin_language_settings');
    Route::post('/admin/settings/language/update', 'Admin\AdminLanguageController@update')->name('admin_language_update');
    Route::post('/admin/settings/language/makeDefault/{id}', 'Admin\AdminLanguageController@makeDefault');
    Route::post('/admin/settings/language/destroy/{id}', 'Admin\AdminLanguageController@destroy');

    Route::get('/admin/selectable/projectFeature', 'Admin\AdminProjectFeatureController@index')->name('admin_selectable_projectFeature');
    Route::get('/admin/selectable/projectFeature/getProjectFeature/{id}', 'Admin\AdminProjectFeatureController@getProjectFeature');
    Route::post('/admin/selectable/projectFeature/update', 'Admin\AdminProjectFeatureController@update')->name('admin_selectable_projectFeature_update');
    Route::post('/admin/selectable/projectFeature/store', 'Admin\AdminProjectFeatureController@store')->name('admin_selectable_projectFeature_store');
    Route::post('/admin/selectable/projectFeature/destroy/{id}', 'Admin\AdminProjectFeatureController@destroy');


    Route::get('/admin/selectable/propertyFeature', 'Admin\AdminPropertyFeatureController@index')->name('admin_selectable_propertyFeature');
    Route::get('/admin/selectable/propertyFeature/getPropertyFeature/{id}', 'Admin\AdminPropertyFeatureController@getPropertyFeature');
    Route::post('/admin/selectable/propertyFeature/update', 'Admin\AdminPropertyFeatureController@update')->name('admin_selectable_propertyFeature_update');
    Route::post('/admin/selectable/propertyFeature/store', 'Admin\AdminPropertyFeatureController@store')->name('admin_selectable_propertyFeature_store');
    Route::post('/admin/selectable/propertyFeature/destroy/{id}', 'Admin\AdminPropertyFeatureController@destroy');


    Route::get('/admin/selectable/orientation', 'Admin\AdminOrientationController@index')->name('admin_selectable_orientation');
    Route::get('/admin/selectable/orientation/getOrientation/{id}', 'Admin\AdminOrientationController@getOrientation');
    Route::post('/admin/selectable/orientation/update', 'Admin\AdminOrientationController@update')->name('admin_selectable_orientation_update');
    Route::post('/admin/selectable/orientation/store', 'Admin\AdminOrientationController@store')->name('admin_selectable_orientation_store');
    Route::post('/admin/selectable/orientation/destroy/{id}', 'Admin\AdminOrientationController@destroy');

    Route::get('/admin/selectable/paymentOption', 'Admin\AdminPaymentOptionController@index')->name('admin_selectable_paymentOption');
    Route::get('/admin/selectable/paymentOption/getPaymentOption/{id}', 'Admin\AdminPaymentOptionController@getPaymentOption');
    Route::post('/admin/selectable/paymentOption/update', 'Admin\AdminPaymentOptionController@update')->name('admin_selectable_paymentOption_update');
    Route::post('/admin/selectable/paymentOption/store', 'Admin\AdminPaymentOptionController@store')->name('admin_selectable_paymentOption_store');
    Route::post('/admin/selectable/paymentOption/destroy/{id}', 'Admin\AdminPaymentOptionController@destroy');

    Route::get('/admin/selectable/view', 'Admin\AdminViewController@index')->name('admin_selectable_view');
    Route::get('/admin/selectable/view/getView/{id}', 'Admin\AdminViewController@getView');
    Route::post('/admin/selectable/view/update', 'Admin\AdminViewController@update')->name('admin_selectable_view_update');
    Route::post('/admin/selectable/view/store', 'Admin\AdminViewController@store')->name('admin_selectable_view_store');
    Route::post('/admin/selectable/view/destroy/{id}', 'Admin\AdminViewController@destroy');

    Route::get('/admin/selectable/wallMaterial', 'Admin\AdminWallMaterialController@index')->name('admin_selectable_wallMaterial');
    Route::get('/admin/selectable/wallMaterial/getWallMaterial/{id}', 'Admin\AdminWallMaterialController@getWallMaterial');
    Route::post('/admin/selectable/wallMaterial/update', 'Admin\AdminWallMaterialController@update')->name('admin_selectable_wallMaterial_update');
    Route::post('/admin/selectable/wallMaterial/store', 'Admin\AdminWallMaterialController@store')->name('admin_selectable_wallMaterial_store');
    Route::post('/admin/selectable/wallMaterial/destroy/{id}', 'Admin\AdminWallMaterialController@destroy');

    Route::get('/admin/selectable/kitchenMaterials', 'Admin\AdminKitchenMaterialController@index')->name('admin_selectable_kitchenMaterial');
    Route::get('/admin/selectable/kitchenMaterial/getKitchenMaterial/{id}', 'Admin\AdminKitchenMaterialController@getKitchenMaterial');
    Route::post('/admin/selectable/kitchenMaterial/update', 'Admin\AdminKitchenMaterialController@update')->name('admin_selectable_kitchenMaterial_update');
    Route::post('/admin/selectable/kitchenMaterial/store', 'Admin\AdminKitchenMaterialController@store')->name('admin_selectable_kitchenMaterial_store');
    Route::post('/admin/selectable/kitchenMaterial/destroy/{id}', 'Admin\AdminKitchenMaterialController@destroy');

    Route::get('/admin/selectable/flooringMaterial', 'Admin\AdminFlooringMaterialController@index')->name('admin_selectable_flooringMaterial');
    Route::get('/admin/selectable/flooringMaterial/getFlooringMaterial/{id}', 'Admin\AdminFlooringMaterialController@getFlooringMaterial');
    Route::post('/admin/selectable/flooringMaterial/update', 'Admin\AdminFlooringMaterialController@update')->name('admin_selectable_flooringMaterial_update');
    Route::post('/admin/selectable/flooringMaterial/store', 'Admin\AdminFlooringMaterialController@store')->name('admin_selectable_flooringMaterial_store');
    Route::post('/admin/selectable/flooringMaterial/destroy/{id}', 'Admin\AdminFlooringMaterialController@destroy');

    // Property Features Controller Routes
    Route::get('/admin/setting/currency', 'Admin\AdminCurrencyController@index')->name('admin_currency');
    Route::get('/admin/setting/currency/getCurrency/{id}', 'Admin\AdminCurrencyController@getCurrency');
    Route::post('/admin/setting/currency/store', 'Admin\AdminCurrencyController@store')->name('admin_currency_store');
    Route::post('/admin/setting/currency/destroy/{id}', 'Admin\AdminCurrencyController@destroy');

    // Property Review Controller Routes
    Route::get('/admin/review', 'Admin\AdminReviewController@index')->name('admin_review');
    Route::post('/admin/review/complete/{id}', 'Admin\AdminReviewController@complete');
    Route::post('/admin/review/dismiss/{id}', 'Admin\AdminReviewController@dismiss');
    Route::post('/admin/review/delete/{id}', 'Admin\AdminReviewController@delete');
    Route::post('/admin/review/getReview/{id}', 'Admin\AdminReviewController@getReview');

    // Users Controller Rutes
    Route::get('/admin/user', 'Admin\AdminUserController@index')->name('admin_users');
    Route::get('/admin/user/autocomplete/', 'Admin\AdminUserController@autocomplete');
    Route::get('/admin/user/userinfo/', 'Admin\AdminUserController@userinfo');
    Route::post('/admin/user/search/', 'Admin\AdminUserController@search')->name('admin_user_search');
    Route::post('/admin/user/destroy/{id}', 'Admin\AdminUserController@destroy');
    Route::post('/admin/user/upgrade/{id}', 'Admin\AdminUserController@upgrade');
    Route::post('/admin/user/massdestroy', 'Admin\AdminUserController@massDestroy');
    Route::post('/admin/user/update', 'Admin\AdminUserController@update')->name('admin_user_update');
    Route::post('/admin/user/activate/{id}', 'Admin\AdminUserController@activate');
    Route::post('/admin/user/deactivate/{id}', 'Admin\AdminUserController@deactivate');

    // Admin Ads
    Route::get('/admin/ad', 'Admin\AdminAdController@index')->name('admin_ads');

    // Admin Banners
    Route::get('/admin/banner', 'Admin\AdminBannerController@index')->name('admin_banners');


    // User Requests Controller Routes
    Route::get('/admin/user/request', 'Admin\AdminUserRequestController@index')->name('admin_users_request');
    Route::post('/admin/user/request/complete/{id}', 'Admin\AdminUserRequestController@complete');
    Route::post('/admin/user/request/dismiss/{id}', 'Admin\AdminUserRequestController@dismiss');
    Route::post('/admin/user/request/delete/{id}', 'Admin\AdminUserRequestController@delete');

    // Translator Controller Routers
    Route::get('/admin/settings/translator', 'Admin\AdminTranslatorController@index')->name('admin_translator');
    Route::post('/admin/settings/translator/getString/{key}', 'Admin\AdminTranslatorController@getString');
    Route::post('/admin/settings/translator/updateString', 'Admin\AdminTranslatorController@updateString');
    Route::post('/admin/settings/translator/createString', 'Admin\AdminTranslatorController@createString')->name('admin_create_string');
    Route::get('/admin/settings/translator/export', 'Admin\AdminLanguageController@export')->name('strings_export');
    Route::post('/admin/settings/translator/import', 'Admin\AdminLanguageController@import')->name('strings_import');

    //  Owners Controller Routes
    Route::get('/admin/company', 'Admin\AdminCompanyController@index')->name('admin_company');
    Route::get('/admin/company/edit/{id}', 'Admin\AdminCompanyController@edit')->name('admin_company_edit');
    Route::post('/admin/company/update/{id}', 'Admin\AdminCompanyController@update')->name('admin_company_update');
    Route::post('/admin/company/activate/{id}', 'Admin\AdminCompanyController@activate');
    Route::post('/admin/company/deactivate/{id}', 'Admin\AdminCompanyController@deactivate');
    Route::post('/admin/company/destroy/{id}', 'Admin\AdminCompanyController@delete');
    Route::post('/admin/company/deleteImage/{id}', 'Admin\AdminCompanyController@deleteImage');
    Route::get('/admin/company/properties/{id}', 'Admin\AdminCompanyController@allproperties')->name('admin_company_projects');
    Route::get('/admin/company/projects/{id}', 'Admin\AdminCompanyController@allprojects')->name('admin_company_properties');
    Route::get('/admin/company/purchases/{id}', 'Admin\AdminCompanyController@allpurchases')->name('admin_company_purchases');
    Route::get('/admin/company/ads/{id}', 'Admin\AdminCompanyController@allads')->name('admin_company_ads');
    Route::get('/admin/company/banners/{id}', 'Admin\AdminCompanyController@allbanners')->name('admin_company_banners');
    Route::get('/admin/company/autocomplete/', 'Admin\AdminCompanyController@autocomplete');
    Route::post('/admin/company/search/', 'Admin\AdminCompanyController@search')->name('admin_company_search');

    // Admin Packages
    Route::get('/admin/settings/package', 'Admin\AdminPackageController@index')->name('admin_packages');
    Route::post('/admin/settings/package/update', 'Admin\AdminPackageController@update')->name('admin_packages_update');

    // Admin Membeships
    Route::get('/admin/settings/membership', 'Admin\AdminMembershipController@index')->name('admin_memberships');
    Route::post('/admin/settings/membership/update', 'Admin\AdminMembershipController@update')->name('admin_memberships_update');

    // Admin Banner Type
    Route::get('/admin/settings/bannerType', 'Admin\AdminBannerTypeController@index')->name('admin_bannerTypes');
    Route::post('/admin/settings/bannerType/update', 'Admin\AdminBannerTypeController@update')->name('admin_bannerTypes_update');

    // Admin Ad Type
    Route::get('/admin/settings/adType', 'Admin\AdminAdTypeController@index')->name('admin_adTypes');
    Route::post('/admin/settings/adType/update', 'Admin\AdminAdTypeController@update')->name('admin_adTypes_update');


    // Resource Admin Controllers
    Route::resource('/admin/blog', 'Admin\AdminBlogController', ['as' => 'admin']);
    Route::resource('/admin/page', 'Admin\AdminPageController', ['as' => 'admin']);
    Route::resource('/admin/faq', 'Admin\AdminFaqController', ['as' => 'admin']);
    Route::resource('/admin/project', 'Admin\AdminProjectController', ['as' => 'admin']);
    Route::resource('/admin/taxonomy/property-type', 'Admin\AdminPropertyTypeController', ['as' => 'admin.taxonomy']);
    Route::resource('/admin/taxonomy/project-type', 'Admin\AdminProjectTypeController', ['as' => 'admin.taxonomy']);
    Route::resource('/admin/taxonomy/project-unit-type', 'Admin\AdminProjectUnitTypeController', ['as' => 'admin.taxonomy']);
    Route::resource('/admin/taxonomy/contract-type', 'Admin\AdminContractTypeController', ['as' => 'admin.taxonomy']);
    Route::resource('/admin/location/country', 'Admin\AdminCountryController', ['as' => 'admin.location']);
    Route::resource('/admin/location/city', 'Admin\AdminCityController', ['as' => 'admin.location']);
    Route::resource('/admin/location/province', 'Admin\AdminProvinceController', ['as' => 'admin.location']);
    Route::resource('/admin/property', 'Admin\AdminPropertyController', ['as' => 'admin']);

});

Route::get('/admin', 'Admin\AdminLoginController@index')->name('admin_login');
Route::get('/admin/reset', 'Admin\AdminLoginController@resetPassword')->name('admin_reset');

// Image Handler
Route::get('/image_handler', 'ImageHandler@index');
Route::post('/image_handler/upload', 'ImageHandler@store')->name('image_handler_upload');
Route::post('/image_handler/delete', 'ImageHandler@delete')->name('image_handler_delete');
Route::post('/image_handler/deleteBase', 'ImageHandler@deleteBase')->name('image_handler_deleteBase');

/*
|--------------------------------------------------------------------------
| Frontend Routes
|--------------------------------------------------------------------------
*/

Route::group(['middleware' => 'user'], function(){

    // Only for users
    Route::get('/my-account', 'UserController@index')->name('my_account');
    Route::post('/user-update', 'UserController@update')->name('user_update');
    Route::post('/user-request', 'UserController@request');

    // Message Controller Routes
    Route::get('/message', 'MessageController@index')->name('message');
    Route::get('/message/{id}', 'MessageController@thread')->name('message_list');
    Route::post('/message/reply/{id}', 'MessageController@reply')->name('message_reply');
    Route::post('/message/post', 'MessageController@post')->name('message_company');

});


Route::get('/', function(){
    return 'Working!';
})->name('home');

// Home Routes
Route::get('/user/resend', 'UserController@resend')->name('resend_activation_mail');
Route::post('/user/changeLanguage', 'UserController@changeLanguage')->name('change_language');
Route::post('/user/changeCurrency', 'UserController@changeCurrency')->name('change_currency');
Route::get('/user/reset', 'UserController@resetPassword')->name('reset_password');
Route::post('/user/resend_mail', 'Auth\LoginController@resendMail')->name('resend_activation');
Route::get('/user/activation/{token}', 'Auth\RegisterController@activateUser')->name('user.activate');
Route::get('/user-register', 'UserController@register')->name('register')->middleware('logged');
Route::post('/reCaptcha', 'HomeController@reCaptcha')->name('reCaptcha');
Route::post('/review', 'HomeController@review')->name('make_review');
Route::get('/login', 'UserController@login')->name('login')->middleware('logged');
Route::get('/activate-account', 'UserController@activateAccount')->name('activate_account');
Route::post('/search', 'SearchController@index')->name('search');
Route::get('/contact', 'HomeController@contact')->name('contact');
Route::post('/mail/sendcontact', 'EmailController@contact')->name('send_contact');
Route::get('/blog', 'BlogController@index')->name('blog');
Route::get('/logout', 'UserController@logout')->name('logout');
Route::get('/page/{alias}', 'PageController@index')->name('page');
Route::get('/blog/post/{alias}', 'BlogController@post');
Route::get('/explore/properties', 'ExploreController@properties')->name('explore_properties');
Route::get('/explore/projects', 'ExploreController@projects')->name('explore_projects');

// Payments
Route::post('/payment-page', 'PaymentController@index')->name('booking_pay_page');
Route::post('/booking/payment', 'PaymentController@payment')->name('booking_pay');
Route::get('/booking/payment/success', 'PaymentController@paymentSuccess')->name('book_payment_success');
Route::get('/booking/payment/cancel', 'PaymentController@paymentCancel')->name('book_payment_cancel');
Route::get('/booking/payment/thank-you', 'PaymentController@paymentThankYou')->name('book_payment_thank_you');

// Social login
Route::get('/facebook/redirect', 'SocialLoginController@facebookRedirect')->name('facebook_redirect');
Route::get('/facebook/callback', 'SocialLoginController@facebookCallback')->name('facebook_callback');
Route::get('/google/redirect', 'SocialLoginController@googleRedirect')->name('google_redirect');
Route::get('/google/callback', 'SocialLoginController@googleCallback')->name('google_callback');

// Explore
Route::get('/explore/getproperties', 'ExploreController@get_properties');
Route::get('/explore/getprojects', 'ExploreController@get_projects');

// Filter
Route::post('/filter/properties', 'FilterController@properties');
Route::post('/filter/projects', 'FilterController@projects');

// Projects
Route::get('/project/{alias}', 'ProjectController@index');

// Properties
Route::get('/property/{alias}', 'PropertyController@index');
Route::post('/bookproperty', 'PropertyController@book');

// Categories
Route::get('/category/{id}/properties', 'CategoryController@get_properties');
Route::get('/category/{id}/projects', 'CategoryController@get_projects');
Route::get('/category/{alias}', 'CategoryController@index');

// Locations
Route::get('/location/{id}/projects', 'LocationController@get_projects');
Route::get('/location/{id}/properties', 'LocationController@get_properties');
Route::get('/location/{alias}', 'LocationController@index');



/*
|--------------------------------------------------------------------------
| Owners Routes
|--------------------------------------------------------------------------
*/
Route::get('/company', 'Company\CompanyLoginController@index')->name('company_login');

Route::group(['middleware' => 'company'], function(){

    // company routes
    Route::get('/company/logout', 'Company\CompanyLoginController@logout')->name('company_logout');
    Route::get('/company/dashboard','Company\CompanyLoginController@dashboard')->name('company_dashboard');
    Route::get('/company/booksi','Company\CompanyLoginController@booksi')->name('company_booksi');
    Route::get('/company/faq','Company\CompanyLoginController@faq')->name('company_faq');
    Route::get('/company/my_account','Company\CompanyController@index')->name('company_my_account');
    Route::put('/company/my_account/update/{id}','Company\CompanyController@update')->name('company_my_account_update');

    // Admin Ads
    Route::get('/company/ad', 'Company\CompanyAdController@index')->name('company_ads');
    Route::post('/company/ad/createProperty', 'Company\CompanyAdController@createProperty')->name('company_create_property_ad');
    Route::post('/company/ad/createProject', 'Company\CompanyAdController@createProject')->name('company_create_project_ad');
    Route::post('/company/ad/editProperty', 'Company\CompanyAdController@editProperty')->name('company_edit_property_ad');
    Route::post('/company/ad/editProject', 'Company\CompanyAdController@editProject')->name('company_edit_project_ad');
    Route::post('/company/ad/extend', 'Company\CompanyAdController@extend')->name('company_extend_ad');
    Route::delete('/company/ad/{id}', 'Company\CompanyAdController@delete');

    // Admin Banners
    Route::get('/company/banner', 'Company\CompanyBannerController@index')->name('company_banners');
    Route::post('/company/banner/create', 'Company\CompanyBannerController@create')->name('company_create_banner');
    Route::post('/company/banner/extend', 'Company\CompanyBannerController@extend')->name('company_extend_banner');
    Route::post('/company/banner/editImage', 'Company\CompanyBannerController@editImage')->name('company_edit_banner');
    Route::delete('/company/banner/{id}', 'Company\CompanyBannerController@delete');

    // Owner Payments
    Route::post('/company/payment', 'Company\CompanyPaymentController@payment')->name('company_payment');
    Route::get('/company/payment/success', 'Company\CompanyPaymentController@paymentSuccess')->name('payment_success');
    Route::get('/company/payment/cancel', 'Company\CompanyPaymentController@paymentCancel')->name('payment_cancel');
    Route::get('/company/payment/thank-you', 'Company\CompanyPaymentController@paymentThankYou')->name('payment_thank_you');

    // Users Controller Rutes
    Route::get('/company/agent', 'Company\CompanyAgentController@index')->name('company_agent');
    Route::post('/company/agent/destroy/{id}', 'Company\CompanyAgentController@destroy');
    Route::post('/company/agent/upgrade/{id}', 'Company\CompanyAgentController@upgrade');
    Route::post('/company/agent/create', 'Company\CompanyAgentController@create')->name('company_agent_create');

    // Additional Project Routes
    Route::post('/company/project/activate/{id}', 'Company\CompanyProjectController@activate');
    Route::post('/company/project/deactivate/{id}', 'Company\CompanyProjectController@deactivate');
    Route::post('/company/project/makefeatured/{id}', 'Company\CompanyProjectController@makeFeatured');
    Route::post('/company/project/makedefault/{id}', 'Company\CompanyProjectController@makeDefault');
    Route::get('/company/project/autocomplete/', 'Company\CompanyProjectController@autocomplete');
    Route::post('/company/project/search/', 'Company\CompanyProjectController@search')->name('company_project_search');
    Route::post('/company/project/massdestroy', 'Company\CompanyProjectController@massDestroy');
    Route::post('/company/project/assign', 'Company\CompanyProjectController@assign')->name('company_project_asign');


    Route::get('/company/project/{id}/unit', 'Company\CompanyProjectController@unit')->name('company_project_units');
    Route::get('/company/project/{id}/unit/create', 'Company\CompanyProjectController@createUnit')->name('company_project_unit_create');
    Route::post('/company/project/{id}/unit/store', 'Company\CompanyProjectController@storeUnit')->name('company_project_unit_store');
    Route::post('/company/project/{id}/unit/delete/{unit}', 'Company\CompanyProjectController@deleteUnit')->name('company_project_unit_delete');
    Route::get('/company/project/{id}/unit/edit/{unit}', 'Company\CompanyProjectController@editUnit')->name('company_project_unit_edit');
    Route::patch('/company/project/{id}/unit/update/{unit}', 'Company\CompanyProjectController@updateUnit')->name('company_project_unit_update');

    // Additional Property Routes
    Route::post('/company/property/activate/{id}', 'Company\CompanyPropertyController@activate');
    Route::post('/company/property/assign', 'Company\CompanyPropertyController@assign')->name('company_property_asign');
    Route::post('/company/property/deactivate/{id}', 'Company\CompanyPropertyController@deactivate');
    Route::post('/company/property/makefeatured/{id}', 'Company\CompanyPropertyController@makeFeatured');
    Route::post('/company/property/makedefault/{id}', 'Company\CompanyPropertyController@makeDefault');
    Route::get('/company/property/autocomplete/', 'Company\CompanyPropertyController@autocomplete');
    Route::post('/company/property/search/', 'Company\CompanyPropertyController@search')->name('company_property_search');
    Route::post('/company/property/massdestroy', 'Company\CompanyPropertyController@massDestroy');
    Route::post('/company/property/updateDates/', 'Company\CompanyPropertyController@updateDates')->name('company_property_update_dates');

    Route::post('/company/property/getProvinces', 'Company\CompanyPropertyController@getProvinces')->name('company_property_get_provinces');
    Route::post('/company/property/getCities', 'Company\CompanyPropertyController@getCities')->name('company_property_get_cities');

    // Property Review Controller Routes
    Route::get('/company/review', 'Company\CompanyReviewController@index')->name('company_review');
    Route::post('/company/review/getReview/{id}', 'Company\CompanyReviewController@getReview');

    // Message Controller Routes
    Route::get('/company/message', 'Company\CompanyMessageController@index')->name('company_message');
    Route::get('/company/message/{id}', 'Company\CompanyMessageController@thread')->name('company_message_list');
    Route::post('/company/message/reply/{id}', 'Company\CompanyMessageController@reply')->name('company_message_reply');
    Route::post('/company/message/delete/{id}', 'Company\CompanyMessageController@delete');
    Route::post('/company/message/close/{id}', 'Company\CompanyMessageController@close');

    // Purchases and Activities
    Route::get('/company/activities', 'Company\CompanyActivityController@index')->name('company_activities');
    Route::get('/company/purchases', 'Company\CompanyPurchaseController@index')->name('company_purchases');
    Route::get('/company/prices', 'Company\CompanyPaymentController@prices')->name('company_prices');
    Route::get('/company/memberships', 'Company\CompanyPaymentController@membership')->name('company_memberships');
    Route::get('/company/balance', 'Company\CompanyBalanceController@index')->name('company_balance');

    // Owner Payments Balances
    Route::post('/company/balance/payment', 'Company\CompanyBalanceController@payment')->name('company_balance_payment');
    Route::get('/company/balance/payment/success', 'Company\CompanyBalanceController@paymentSuccess')->name('payment_balance_success');
    Route::get('/company/balance/payment/cancel', 'Company\CompanyBalanceController@paymentCancel')->name('payment_balance_cancel');

    Route::get('/company/view-tour', 'Company\CompanyViewTourController@index')->name('company_view_tour');
    Route::get('/company/view-tour/create', 'Company\CompanyViewTourController@create')->name('company_view_tour_create');
    Route::get('/company/view-tour/{id}/edit', 'Company\CompanyViewTourController@edit')->name('company_view_tour_edit');
    Route::post('/company/view-tour/{id}/update', 'Company\CompanyViewTourController@update')->name('company_view_tour_update');
    Route::post('/company/view-tour/store', 'Company\CompanyViewTourController@store')->name('company_view_tour_store');
    Route::post('/company/view-tour/delete', 'Company\CompanyViewTourController@delete')->name('company_view_tour_delete');
    Route::post('/company/view-tour/getProperties', 'Company\CompanyViewTourController@getPropertiesByagent')->name('company_properties_by_agent');

    // Bookings Controller Routes
    Route::get('/company/request/view-tour', 'Company\CompanyRequestController@viewTour')->name('company_view_tours_requests');
    Route::get('/company/request/private-request', 'Company\CompanyRequestController@privateTour')->name('company_private_request');
    Route::get('/company/request/property-request', 'Company\CompanyRequestController@propertyRequest')->name('company_property_request');
    Route::post('/company/request/user_details/{id}', 'Company\CompanyRequestController@userInfo');
    Route::post('/company/request/delete/{id}', 'Company\CompanyRequestController@delete');
    Route::post('/company/request/activate/{id}', 'Company\CompanyRequestController@activate');
    Route::post('/company/request/reject/{id}', 'Company\CompanyRequestController@reject');

    // Availability Dates Controller Routes
    Route::get('/company/property/date/{id}', 'Company\CompanyPropertyDateController@index')->name('company_property_date');

    // Resource Owner Controllers
    Route::resource('/company/project', 'Company\CompanyProjectController', ['as' => 'company']);
    Route::resource('/company/property', 'Company\CompanyPropertyController', ['as' => 'company']);

});

Route::get('/agent', 'Agent\AgentLoginController@index')->name('agent_login');

Route::group(['middleware' => 'agent'], function(){

    // agent routes
    Route::get('/agent/logout', 'Agent\AgentLoginController@logout')->name('agent_logout');
    Route::get('/agent/dashboard','Agent\AgentLoginController@dashboard')->name('agent_dashboard');
    Route::get('/agent/booksi','Agent\AgentLoginController@booksi')->name('agent_booksi');
    Route::get('/agent/faq','Agent\AgentLoginController@faq')->name('agent_faq');
    Route::get('/agent/my_account','Agent\AgentController@index')->name('agent_my_account');
    Route::put('/agent/my_account/update/{id}','Agent\AgentController@update')->name('agent_my_account_update');

     // Bookings Controller Routes
    Route::get('/agent/view-tour', 'Agent\AgentViewTourController@index')->name('agent_view_tour');
    Route::get('/agent/request/view-tour-request', 'Agent\AgentRequestController@viewTour')->name('agent_view_request');
    Route::get('/agent/request/private-request', 'Agent\AgentRequestController@privateTour')->name('agent_private_request');
    Route::get('/agent/request/property-request', 'Agent\AgentRequestController@propertyRequest')->name('agent_property_request');
    Route::post('/agent/request/user_details/{id}', 'Agent\AgentRequestController@userInfo');
    Route::post('/agent/request/activate/{id}', 'Agent\AgentRequestController@activate');
    Route::post('/agent/request/reject/{id}', 'Agent\AgentRequestController@reject');

    // Message Controller Routes
    Route::get('/agent/message', 'Agent\AgentMessageController@index')->name('agent_message');
    Route::get('/agent/message/{id}', 'Agent\AgentMessageController@thread')->name('agent_message_list');
    Route::post('/agent/message/reply/{id}', 'Agent\AgentMessageController@reply')->name('agent_message_reply');
    Route::post('/agent/message/delete/{id}', 'Agent\AgentMessageController@delete');
    Route::post('/agent/message/close/{id}', 'Agent\AgentMessageController@close');


    // For Agent Subadmins
    Route::group(['middleware' => 'agent_subadmin'], function(){

        // Additional Property Routes
        Route::post('/agent/property/massdestroy', 'Agent\AgentPropertyController@massDestroy');

        Route::post('/agent/property/getProvinces', 'Agent\AgentPropertyController@getProvinces')->name('agent_property_get_provinces');
        Route::post('/agent/property/getCities', 'Agent\AgentPropertyController@getCities')->name('agent_property_get_cities');

        // Resource Owner Controllers
        Route::resource('/agent/property', 'Agent\AgentPropertyController', ['as' => 'agent']);
    });

});

});
