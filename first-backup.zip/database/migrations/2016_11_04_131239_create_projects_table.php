<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateProjectsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        /* 'company_id', 'status', 'agent_id', 'country_id', 'province_id', 'city_id', 'video', 'logo', 'alias', 'project_type', 'number_of_units', 'developer', 'delivery_date', 'prices', 'location', 'features', 'payment_plan', 'meta_keywords', 'meta_description', 'meta_title',
        */
        Schema::create('projects', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('company_id');
            $table->integer('agent_id')->default(0);
            $table->integer('country_id');
            $table->integer('city_id');
            $table->integer('province_id');
            $table->integer('project_type_id');
            $table->integer('number_of_units');
            $table->integer('status')->default(0);
            $table->integer('featured')->default(0);
            $table->string('developer')->nullable();
            $table->date('delivery_date');
            $table->string('prices');
            $table->string('address')->nullable();
            $table->string('geo_lat')->nullable();
            $table->string('geo_lng')->nullable();
            $table->string('zip')->nullable();
            $table->string('features')->nullable();
            $table->string('payment_plan')->nullable();
            $table->string('meta_title')->nullable();
            $table->text('meta_description')->nullable();
            $table->text('meta_keywords')->nullable();
            $table->string('alias');
            $table->string('logo')->nullable();
            $table->string('video')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('projects');
    }
}
