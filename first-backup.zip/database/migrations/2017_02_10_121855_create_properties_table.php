<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreatePropertiesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('properties', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('company_id');
            $table->integer('agent_id')->default(0);
            $table->integer('status')->default(0);
            $table->integer('featured')->default(0);
            $table->integer('contract_type_id');
            $table->integer('property_type_id');
            $table->integer('country_id');
            $table->integer('province_id');
            $table->integer('city_id');
            $table->integer('year_built');
            $table->integer('kitchen_appliances')->default(0);
            $table->integer('built_in_wardrobe')->default(0);
            $table->integer('price')->default(0);
            $table->string('address')->nullable();
            $table->string('geo_lat')->nullable();
            $table->string('geo_lng')->nullable();
            $table->string('zip')->nullable();
            $table->string('features');
            $table->string('property_info');
            $table->text('plans')->nullable();
            $table->string('payment_options')->nullable();
            $table->string('area')->nullable();
            $table->string('orientations')->nullable();
            $table->string('views')->nullable();
            $table->string('wall_materials')->nullable();
            $table->string('flooring_materials')->nullable();
            $table->string('kitchen_materials')->nullable();
            $table->text('video')->nullable();
            $table->string('meta_title')->nullable();
            $table->text('meta_description')->nullable();
            $table->text('meta_keywords')->nullable();
            $table->string('alias');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('properties');
    }
}
