<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateCompaniesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('companies', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('user_id')->unsigned()->index();
            $table->integer('membership_id')->unsigned()->index();
            $table->integer('points')->unsigned()->default(0);
            $table->date('membership_expires');
            $table->string('type_id');
            $table->string('contract')->nullable();
            $table->string('company', 255)->nullable();
            $table->string('website')->nulable();
            $table->string('email')->nulable();
            $table->string('phone')->nulable();
            $table->text('location');
            $table->text('description')->nullable();
            $table->string('logo', 150)->default('no_image.jpg');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('companies');
    }
}
