<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateMembershipsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('memberships', function (Blueprint $table) {
            $table->increments('id');
            $table->string('key');
            $table->integer('monthly');
            $table->integer('agents');
            $table->integer('listings');
            $table->integer('photo_slots');
            $table->integer('listing_duration');
            $table->integer('projects')->default(0);
            $table->integer('private_tour')->default(0);
            $table->integer('inquires')->default(0);
            $table->integer('view_tour')->default(0);
            $table->integer('property_requests')->default(0);
            $table->integer('search_company')->default(0);
            $table->integer('home_logo')->default(0);
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('memberships');
    }
}
