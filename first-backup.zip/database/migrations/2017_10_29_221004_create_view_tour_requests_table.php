<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateViewTourRequestsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('view_tour_requests', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('view_tour_id');
            $table->integer('company_id');
            $table->integer('agent_id');
            $table->integer('status')->default(0);
            $table->integer('payment_method');
            $table->integer('seats')->default(1);
            $table->string('first_name');
            $table->string('last_name');
            $table->string('email');
            $table->string('phone');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('view_tour_requests');
    }
}
