<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateViewToursTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {

        Schema::create('view_tours', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('company_id');
            $table->integer('agent_id');
            $table->integer('number_of_properties');
            $table->integer('number_of_days');
            $table->integer('lunch')->default(0);
            $table->integer('airport_pickup')->default(0);
            $table->integer('accomodation')->default(0);
            $table->integer('price')->default(0);
            $table->integer('air_flight_tickets')->default(0);
            $table->date('start_date');
            $table->date('end_date');
            $table->string('properties')->nullable();
            $table->string('location')->nullable();
            $table->string('payment_method')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('view_tours');
    }
}
