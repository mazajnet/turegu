@extends('layouts.company')

@section('title')
<title>{{get_string('dashboard') . ' - ' . get_setting('site_name', 'site')}}</title>
@endsection

    @section('page_title')
        <h3 class="page-title mbot10">{{get_string('dashboard')}}</h3>
    @endsection
    @section('content')
        <div class="row mbot0">
            @if(Session::has('payment_status')) <?php $status = Session::get('payment_status'); ?>
                <div class="col s12">
                    <div class="col s12 text-centered">
                        <h5 class="@if(!$status['status']) color-red @else color-primary @endif">{{ $status['msg'] }}</h5>
                    </div>
                </div>
            @endif

            @if(Session::has('projects_not_enabled'))
                <div class="col s12">
                    <div class="col s12 text-centered">
                        <p class="color-red">{{ get_string('projects_not_enabled') }}</p>
                    </div>
                </div>
            @endif

            @if(Session::has('view_tours_not_enabled'))
                <div class="col s12">
                    <div class="col s12 text-centered">
                        <p class="color-red">{{ get_string('view_tour_not_enabled') }}</p>
                    </div>
                </div>
            @endif

             @if(Session::has('property_requests_not_enabled'))
                <div class="col s12">
                    <div class="col s12 text-centered">
                        <p class="color-red">{{ get_string('property_requests_not_enabled') }}</p>
                    </div>
                </div>
            @endif
    
            @if($user->company->is_active)

            <div class="col s12">
                <div class="col l3 m6 s12">
                    <div class="card">
                        <div class="card-content no-padding">
                            <div class="blue-card card-stats-body waves-effect">
                                <div class="stats-icon right-align">
                                    <i class="medium material-icons">home</i>
                                </div>
                                <div class="stats-text left-align">
                                    <strong class="counter">{{ $data['properties'] }}</strong><br>
                                    <span>{{get_string('properties')}}</span>
                                </div>
                            </div>
                        </div><!--end .card-body -->
                    </div>
                </div>
                <div class="col l3 m6 s12">
                    <div class="card">
                        <div class="card-content no-padding">
                            <div class="blue-card card-stats-body waves-effect">
                                <div class="stats-icon right-align">
                                    <i class="medium material-icons">home</i>
                                </div>
                                <div class="stats-text left-align">
                                    <strong class="counter">{{ $data['projects'] }}</strong><br>
                                    <span>{{get_string('projects')}}</span>
                                </div>
                            </div>
                        </div><!--end .card-body -->
                    </div>
                </div>
                <div class="col l3 m6 s12">
                    <div class="card">
                        <div class="card-content no-padding">
                            <div class="blue-card card-stats-body waves-effect">
                                <div class="stats-icon right-align">
                                    <i class="medium material-icons">business_center</i>
                                </div>
                                <div class="stats-text left-align">
                                    <strong class="counter">{{ $data['agents'] }}</strong><br>
                                    <span>{{ get_string('agents')}}</span>
                                </div>
                            </div>
                        </div><!--end .card-body -->
                    </div>
                </div>
                <div class="col l3 m6 s12">
                    <div class="card">
                        <div class="card-content no-padding">
                            <div class="blue-card card-stats-body waves-effect">
                                <div class="stats-icon right-align">
                                    <i class="medium material-icons">extension</i>
                                </div>
                                <div class="stats-text left-align">
                                    <strong class="counter">{{ $data['points'] }}</strong><br>
                                    <span>{{get_string('points')}}</span>
                                </div>
                            </div>
                        </div><!--end .card-body -->
                    </div>
                </div>
            </div>

            @else

               <!-- TODO::: HANDLE PAYMENT --> 

            @endif
        </div>
    </div>
    @endsection
@section('footer')
    <script>
        $(document).ready(function() {
            $('.counter').counterUp({
                delay: 10,
                time: 1000
            });
        });
    </script>
@endsection