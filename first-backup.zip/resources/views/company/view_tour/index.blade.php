@extends('layouts.company')

@section('title')
    <title>{{get_string('view_tours') . ' - ' . get_setting('site_name', 'site')}}</title>
@endsection
@section('content')
@section('page_title')
    <h3 class="page-title mbot10">{{get_string('view_tours')}}</h3>
@endsection
    <div class="col l6 m4 s12 right right-align mbot10">
        <a href="{{route('company_view_tour_create')}}" class="btn waves-effect"> {{get_string('create_view_tour')}} <i class="material-icons small">add_circle</i></a>
    </div>
    <div class="col s12">
        @if($viewTours->count())
        <div class="table-responsive">
        <table class="table bordered striped">
            <thead class="thead-inverse">
            <tr>
                <th>
                    <input type="checkbox" class="filled-in primary-color" id="select-all" />
                    <label for="select-all"></label>
                </th>
                <th>{{get_string('agent')}}</th>
                <th>{{get_string('date')}}</th>
                <th>{{get_string('number_of_properties')}}</th>
                <th>{{get_string('number_of_days')}}</th>
                <th>{{get_string('price')}}</th>
                <th class="icon-options">{{get_string('options')}}</th>
            </tr>
            </thead>
            <tbody>
                @foreach($viewTours as $viewTour)
                    <tr>
                        <td>
                            <input type="checkbox" class="filled-in primary-color" id="{{$viewTour->id}}" />
                            <label for="{{$viewTour->id}}"></label>
                        </td>
                        <td>@if($viewTour->agent) {{$viewTour->agent->username}}  @else <i class="small material-icons color-red">clear</i> @endif</td>
                        <td>{{ $viewTour->start_date .' - '. $viewTour->end_date }}</td>
                        <td>{{ $viewTour->number_of_properties }} </td>
                        <td>{{ $viewTour->number_of_days }} </td>
                        <td>{{ get_setting('currency', 'site') }}{{ $viewTour->price }} </td>
                        <td>
                            <div class="icon-options">
                                <a href="{{ route('company_view_tour_edit', $viewTour) }}"><i class="small material-icons color-primary">mode_edit</i></a>
                                <a href="#" class="delete-button" data-id="{{$viewTour->id}}"><i class="small material-icons color-red">delete</i></a>
                            </div>
                        </td>
                    </tr>
                @endforeach
            </tbody>
        </table>
        </div>
        {{$viewTours->links()}}
        @else
            <strong class="center-align">{{get_string('no_results')}}</strong>
        @endif
    </div>
@endsection

@section('footer')
<script>
    $(document).ready(function(){
        $('.delete-button').click(function(event){
            event.preventDefault();
            var id = $(this).data('id');
            var selector = $(this).parents('tr');
            var token = $('[name="_token"]').val();
            bootbox.confirm({
                title: '{{get_string('confirm_action')}}',
                message: '{{get_string('delete_confirm')}}',
                onEscape: true,
                backdrop: true,
                buttons: {
                    cancel: {
                        label: '{{get_string('no')}}',
                        className: 'btn waves-effect'
                    },
                    confirm: {
                        label: '{{get_string('yes')}}',
                        className: 'btn waves-effect'
                    }
                },
                callback: function (result) {
                    if(result){
                        $.ajax({
                            url: '{{ route('company_view_tour_delete') }}',
                            type: 'post',
                            data: {_method: 'delete', _token :token, id: id},
                            success:function(msg) {
                                selector.remove();
                                toastr.success(msg);
                            },
                            error:function(msg){
                                toastr.error(msg.responseJSON);
                            }
                        });
                    }
                }
            });
        });
    });
</script>
@endsection