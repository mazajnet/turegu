@extends('layouts.company')

@section('title')
    <title>{{get_string('create_view_tour') . ' - ' . get_setting('site_name', 'site')}}</title>
@endsection

@section('style')
    <link href="{{ URL::asset('assets/css/plugins/backend_jquery-ui.min.css')}}" rel="stylesheet">
@endsection

@section('content')
@section('page_title')
    <h3 class="page-title mbot10">{{get_string('create_view_tour')}}</h3>
@endsection
<div class="col s12">
    @if(!$errors->isEmpty())
        <span class="wrong-error">* {{get_string('validation_error')}}</span>
        
    @endif
    {!!Form::open(['method' => 'post', 'url' => route('company_view_tour_store', $viewTour)])!!}
        <div class="panel">
            <div class="panel-heading">
                <ul class="nav nav-tabs">
                    <li class="tab"><a href="#data-panel" data-toggle="tab">{{get_string('data')}}</a></li>
                </ul>
            </div>
        <div class="panel-body">
            <div class="tab-content">
                <div id="data-panel" class="tab-pane active">
                    <div class="col s6">
                        <div class="form-group  {{$errors->has('agent_id') ? 'has-error' : ''}}">
                            <select class="form-control agent-select" name="agent_id" placeholder="{{ get_string('agent') }}">
                                @foreach($agents as $key => $value)
                                <option class="agent-select-option" value="{{ $key }}">{{ $value }}</option>
                                @endforeach
                            </select>
                            {{Form::label('agent_id', get_string('agent'))}}
                            @if($errors->has('agent_id'))
                                <span class="wrong-error">* {{$errors->first('agent_id')}}</span>
                            @endif
                        </div>
                    </div>
                    <div class="col s6">
                        <div class="form-group  {{$errors->has('price') ? 'has-error' : ''}}">
                            {{Form::number('price', null, ['class' => 'category-select form-control', 'min' => 0, 'step' => 1, 'placeholder' => get_string('price')])}}
                            {{Form::label('price', get_string('price'))}}
                            @if($errors->has('price'))
                                <span class="wrong-error">* {{$errors->first('price')}}</span>
                            @endif
                        </div>
                    </div>
                    <div class="col s12 well checkbox-grid">
                        <p>{{get_string('properties')}}</p>
                        <div id="properties-list">
                            
                        </div>
                    </div>
                    <div class="col l6 m6 s12">
                        <div class="form-group  {{$errors->has('start_date') ? 'has-error' : ''}}">
                            {{Form::text('start_date', null, ['class' => 'start_date-picker form-control', 'placeholder' => get_string('start_date')])}}
                            {{Form::label('start_date', get_string('start_date'))}}
                            @if($errors->has('start_date'))
                                <span class="wrong-error">* {{$errors->first('start_date')}}</span>
                            @endif
                        </div>
                    </div>
                    <div class="col l6 m6 s12">
                        <div class="form-group  {{$errors->has('end_date') ? 'has-error' : ''}}">
                            {{Form::text('end_date', null, ['class' => 'end_date-picker form-control', 'placeholder' => get_string('end_date')])}}
                            {{Form::label('end_date', get_string('end_date'))}}
                            @if($errors->has('end_date'))
                                <span class="wrong-error">* {{$errors->first('end_date')}}</span>
                            @endif
                        </div>
                    </div>
                    <div class="col l6 m6 s12">
                        <div class="form-group  {{$errors->has('location') ? 'has-error' : ''}}">
                            {{Form::text('location', null, ['class' => 'feet-area form-control', 'placeholder' => get_string('location')])}}
                            {{Form::label('location', get_string('location'))}}
                            @if($errors->has('location'))
                                <span class="wrong-error">* {{$errors->first('location')}}</span>
                            @endif
                        </div>
                    </div>
                    <div class="col s6">
                        <div class="form-group  {{$errors->has('accomodation') ? 'has-error' : ''}}">
                            {{Form::select('accomodation', [0 => get_string('no'), 1 => get_string('yes')], null, ['class' => 'category-select form-control', 'placeholder' => get_string('accomodation')])}}
                            {{Form::label('accomodation', get_string('accomodation'))}}
                            @if($errors->has('accomodation'))
                                <span class="wrong-error">* {{$errors->first('accomodation')}}</span>
                            @endif
                        </div>
                    </div>
                    <div class="col s6">
                        <div class="form-group  {{$errors->has('airport_pickup') ? 'has-error' : ''}}">
                            {{Form::select('airport_pickup', [0 => get_string('no'), 1 => get_string('yes')], null, ['class' => 'category-select form-control', 'placeholder' => get_string('airport_pickup')])}}
                            {{Form::label('airport_pickup', get_string('airport_pickup'))}}
                            @if($errors->has('airport_pickup'))
                                <span class="wrong-error">* {{$errors->first('airport_pickup')}}</span>
                            @endif
                        </div>
                    </div>
                    <div class="col s6">
                        <div class="form-group  {{$errors->has('air_flight_tickets') ? 'has-error' : ''}}">
                            {{Form::select('air_flight_tickets', [0 => get_string('no'), 1 => get_string('yes')], null, ['class' => 'category-select form-control', 'placeholder' => get_string('air_flight_tickets')])}}
                            {{Form::label('air_flight_tickets', get_string('air_flight_tickets'))}}
                            @if($errors->has('air_flight_tickets'))
                                <span class="wrong-error">* {{$errors->first('air_flight_tickets')}}</span>
                            @endif
                        </div>
                    </div>
                    <div class="col s6">
                        <div class="form-group  {{$errors->has('lunch') ? 'has-error' : ''}}">
                            {{Form::select('lunch', [0 => get_string('no'), 1 => get_string('yes')], null, ['class' => 'category-select form-control', 'placeholder' => get_string('lunch')])}}
                            {{Form::label('lunch', get_string('lunch'))}}
                            @if($errors->has('lunch'))
                                <span class="wrong-error">* {{$errors->first('lunch')}}</span>
                            @endif
                        </div>
                    </div>
                    <div class="col s6">
                        <div class="form-group  {{$errors->has('payment_method') ? 'has-error' : ''}}">
                            {{Form::select('payment_method', $paymentMethods, null, ['class' => 'category-select form-control', 'placeholder' => get_string('payment_method')])}}
                            {{Form::label('payment_method', get_string('payment_method'))}}
                            @if($errors->has('payment_method'))
                                <span class="wrong-error">* {{$errors->first('payment_method')}}</span>
                            @endif
                        </div>
                    </div>
                </div>
            </div>
            <div class="col clearfix s12 mtop10">
                <div class="form-group">
                    <button class="btn waves-effect" type="submit" name="action">{{get_string('create_view_tour')}}</button>
                    <a href="{{route('company_view_tour')}}" class="btn waves-effect">{{get_string('back')}}</a>
                </div>
            </div>
            {{Form::hidden('company_id', Auth::user()->id)}}
            {!!Form::close()!!}
        </div>
    </div>
</div>
@endsection

@section('footer')
    <script>
        $(document).ready(function() {

            // Datepickers
            $('.start_date-picker').datepicker({
                dateFormat: 'dd/mm/yy',
                minDate: 0,
                onSelect: function(dateText, inst) {
                    var startDate = $(this).datepicker('getDate');
                    if($('.end_date-picker').hasClass('hasDatePicker')){
                        $('.end_date-picker').datepicker('destroy');
                    }
                    startDate.setDate(startDate.getDate() + 1);
                    $("[name='start_date']").val(dateText);
                    $("[name='end_date']").removeAttr('disabled');
                    $('.end_date-picker').datepicker({
                        dateFormat: 'dd/mm/yy',
                        minDate: startDate,
                        onSelect: function(dateText, inst) {
                            $("[name='end_date']").val(dateText);
                        }
                    });
                }
            });

            if($('.agent-select').val() != '') getPropertiesByAgent($('.agent-select').val());

            $(this).on('click change', '.agent-select', function () {

                if(!(this.selectedIndex == -1)) {
                    var id = $(this).val();
                    getPropertiesByAgent(id);
                }

            });

        });

        function getPropertiesByAgent(id) {

            $.ajax({
                url: '{{ route('company_properties_by_agent') }}',
                type: 'post', 
                data: {_token: $('[name="_token"]').val(), id: id},
                success: function (data){
                    
                    var html = '';
                    $.each(data, function(key, value) {
                        html += '<div class="col s2"><div class="form-group"><input type="checkbox" name="properties[]" value="' + key + '" class="filled-in primary-color" id="'+ key +'" /><label for="'+ key +'"></label><span class="checkbox-label">'+ value +'</span></div></div>';
                    });

                    $('#properties-list').html(html);
                }
            });
        }
    </script>
@endsection