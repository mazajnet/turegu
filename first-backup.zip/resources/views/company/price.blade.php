@extends('layouts.company')

@section('title')
    <title>{{get_string('prices') . ' - ' . get_setting('site_name', 'site')}}</title>
@endsection
@section('content')
@section('page_title')
@endsection
<?php $points = get_string('points'); ?>
<div class="col s12">
    <h3 class="page-title mbot10">{{get_string('packages')}}</h3>
    <div class="table-responsive">
        <table class="table bordered striped">
            <thead class="thead-inverse">
            <tr>
                <th>
                    <input type="checkbox" class="filled-in primary-color" id="select-all" />
                    <label for="select-all"></label>
                </th>
                <th>{{get_string('package')}}</th>
                <th>{{get_string('cost')}}</th>
                <th>{{get_string('points')}}</th>
                <th>{{get_string('bonus')}}</th>
            </tr>
            </thead>
            <tbody>
                @foreach($packages as $package) 

                    <tr>
                        <td>
                            <input type="checkbox" class="filled-in primary-color" id="package-{{ $package->id }}" />
                            <label for="package-{{ $package->id }}"></label>
                        </td>
                        <td>{{ get_string('package') .' #'. $package->id }}</td>
                        <td>{{ get_setting('currency', 'site') . $package->cost }}</td>
                        <td>{{ $package->points .' '. $points }}</td>
                        <td>{{ $package->bonus .' '.$points }}</td>
                    </tr>

                @endforeach
            </tbody>
        </table>
    </div>
</div>
<div class="col m6 s12">
    <h3 class="page-title mbot10">{{get_string('bannerType')}}</h3>
    <div class="table-responsive">
        <table class="table bordered striped">
            <thead class="thead-inverse">
            <tr>
                <th>
                    <input type="checkbox" class="filled-in primary-color" id="select-all" />
                    <label for="select-all"></label>
                </th>
                <th>{{get_string('bannerType')}}</th>
                <th>{{get_string('weekly')}}</th>
                <th>{{get_string('monthly')}}</th>
                <th>{{get_string('yearly')}}</th>
                <th>{{get_string('maximum')}}</th>
            </tr>
            </thead>
            <tbody>
                @foreach($bannerTypes as $bannerType) 

                    <tr>
                        <td>
                            <input type="checkbox" class="filled-in primary-color" id="bannerType-{{ $bannerType->id }}" />
                            <label for="bannerType-{{ $bannerType->id }}"></label>
                        </td>
                        <td>{{ get_string($bannerType->key) }}</td>
                        <td>{{ $bannerType->weekly .' '. $points }}</td>
                        <td>{{ $bannerType->monthly .' '. $points }}</td>
                        <td>{{ $bannerType->yearly .' '.$points }}</td>
                        <td>{{ $bannerType->maximum }}</td>
                    </tr>

                @endforeach
            </tbody>
        </table>
    </div>
</div>
<div class="col m6 s12">
    <h3 class="page-title mbot10">{{get_string('adTypes')}}</h3>
    <div class="table-responsive">
        <table class="table bordered striped">
            <thead class="thead-inverse">
            <tr>
                <th>
                    <input type="checkbox" class="filled-in primary-color" id="select-all" />
                    <label for="select-all"></label>
                </th>
                <th>{{get_string('adType')}}</th>
                <th>{{get_string('weekly')}}</th>
                <th>{{get_string('monthly')}}</th>
                <th>{{get_string('yearly')}}</th>
                <th>{{get_string('maximum')}}</th>
            </tr>
            </thead>
            <tbody>
                @foreach($adTypes as $adType) 

                    <tr>
                        <td>
                            <input type="checkbox" class="filled-in primary-color" id="adType-{{ $adType->id }}" />
                            <label for="adType-{{ $adType->id }}"></label>
                        </td>
                        <td>{{ get_string($adType->key) }}</td>
                        <td>{{ $adType->weekly .' '. $points }}</td>
                        <td>{{ $adType->monthly .' '. $points }}</td>
                        <td>{{ $adType->yearly .' '. $points }}</td>
                        <td>{{ $adType->maximum }}</td>
                    </tr>

                @endforeach
            </tbody>
        </table>
    </div>
</div>
@endsection
