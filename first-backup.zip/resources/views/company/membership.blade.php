@extends('layouts.company')

@section('title')
    <title>{{get_string('memberships') . ' - ' . get_setting('site_name', 'site')}}</title>
@endsection

@section('content')
@section('page_title')
    <h3 class="page-title mbot10">{{get_string('memberships')}}</h3>
@endsection
<div class="col s12">
    <table class="table bordered striped">
        <thead class="thead-inverse">
            <tr>
                <th style="width: 30%"></th>
                @foreach($memberships as $membership)
                    <th>{{get_string($membership->key)}}</th>
                @endforeach
            </tr>
        </thead>
        <tbody>
            <tr>
                <td style="font-weight: bold;">{{ get_string('monthly') }}</td>
                @foreach($memberships as $membership)
                    <td>{{ $membership->monthly .' '. get_string('points')}}</td>
                @endforeach
            </tr>
            <tr>
                <td style="font-weight: bold;"> {{ get_string('agents') }}</td>
                @foreach($memberships as $membership)
                    <td>{{ $membership->agents}}</td>
                @endforeach
            </tr>
            <tr>
                <td style="font-weight: bold;">{{ get_string('listings') }}</td>
                @foreach($memberships as $membership)
                    <td>{{ $membership->listings}}</td>
                @endforeach
            </tr>
            <tr>
                <td style="font-weight: bold;">{{ get_string('listing_duration') }}</td>
                @foreach($memberships as $membership)
                    <td>{{ $membership->listing_duration}}</td>
                @endforeach
            </tr>
            <tr>
                <td style="font-weight: bold;">{{ get_string('projects') }}</td>
                @foreach($memberships as $membership)
                    <td>{{ $membership->projects ? get_string('yes') : get_string('no') }}</td>
                @endforeach
            </tr>
            <tr>
                <td style="font-weight: bold;">{{ get_string('private_tour') }}</td>
                @foreach($memberships as $membership)
                    <td>{{ $membership->private_tour ? get_string('yes') : get_string('no') }}</td>
                @endforeach
            </tr>
            <tr>
                <td style="font-weight: bold;">{{ get_string('view_tour') }}</td>
                @foreach($memberships as $membership)
                    <td>{{ $membership->view_tour ? get_string('yes') : get_string('no') }}</td>
                @endforeach
            </tr>
            <tr>
                <td style="font-weight: bold;">{{ get_string('property_requests') }}</td>
                @foreach($memberships as $membership)
                    <td>{{ $membership->property_request ? get_string('yes') : get_string('no') }}</td>
                @endforeach
            </tr>
            <tr>
                <td style="font-weight: bold;"> {{ get_string('search_company') }}</td>
                @foreach($memberships as $membership)
                    <td>{{ $membership->search_company ? get_string('yes') : get_string('no') }}</td>
                @endforeach
            </tr>
            <tr>
                <td style="font-weight: bold;">{{ get_string('home_logo') }}</td>
                @foreach($memberships as $membership)
                    <td>{{ $membership->home_logo ? get_string('yes') : get_string('no') }}</td>
                @endforeach
            </tr>
        </tbody>
    </table>
</div>
@endsection
