@extends('layouts.company')

@section('title')
    <title>{{get_string('create_unit') . ' - ' . get_setting('site_name', 'site')}}</title>
@endsection

@section('content')
@section('page_title')
    <h3 class="page-title mbot10">{{get_string('create_unit')}}</h3>
@endsection
<div class="col s12">
    @if(!$errors->isEmpty())
        <span class="wrong-error">* {{get_string('validation_error')}}</span>
    @endif
    {!!Form::open(['method' => 'post', 'url' => route('company_project_unit_store', $id), 'files' => 'true'])!!}
        <div class="panel">
            <div class="panel-heading">
                <ul class="nav nav-tabs">
                    <li class="tab active"><a href="#content-panel" data-toggle="tab">{{get_string('content')}}</a></li>
                    <li class="tab"><a href="#data-panel" data-toggle="tab">{{get_string('data')}}</a></li>
                    <li class="tab"><a href="#media-panel" data-toggle="tab">{{get_string('media')}}</a></li>
                </ul>
            </div>
        <div class="panel-body">
            <div class="tab-content">
                <div id="content-panel" class="tab-pane active">
                    <div class="panel">
                        <div class="panel-heading">
                            <ul class="nav nav-tabs">
                                @foreach($languages as $language)
                                    <li class="tab {{$language->default ? 'active' : ''}}"><a href="#lang{{$language->id}}" data-parent="#content" data-toggle="tab"><img src="{{$language->flag}}"/><span>{{$language->language}}</span></a></li>
                                @endforeach
                            </ul>
                        </div>
                        <div class="panel-body">
                            <div class="tab-content">
                                @foreach($languages as $language)
                                    <div id="lang{{$language->id}}" class="tab-pane {{$language->default ? 'active' : ''}}">
                                        <div class="col s12">
                                            <div class="form-group  {{$errors->has('name.'.$language->id.'') ? 'has-error' : ''}}">
                                                {{Form::text('name['.$language->id.']', null, ['class' => 'form-control', 'placeholder' => get_string('unit')])}}
                                                {{Form::label('name['.$language->id.']', get_string('unit'))}}
                                                @if($errors->has('name.'.$language->id.''))
                                                    <span class="wrong-error">* {{$errors->first('name.'.$language->id.'')}}</span>
                                                @endif
                                            </div>
                                        </div>
                                        <div class="col s12">
                                            {{Form::textarea('description['.$language->id.']', null, ['class' => 'hidden desc-content'])}}
                                            @if($errors->has('description.'.$language->id.''))
                                                <span class="wrong-error">* {{$errors->first('description.'.$language->id.'')}}</span>
                                            @endif
                                        </div>
                                    </div>
                                @endforeach
                            </div>
                        </div>
                    </div>
                </div>

                <div id="media-panel" class="tab-pane">

                     <div class="col l12 m12 s12">
                        <div id="file-dropzone" class="dropzone">
                            <div class="dz-message">{{get_string('upload_images')}}<br/><i class="material-icons medium">cloud_upload</i>
                            </div>
                            <div class="fallback">
                            </div>
                        </div>
                    </div>

                    <div class="col s12">
                        <div class="input-group {{$errors->has('plans') ? 'has-error' : ''}}">
                            <label class="input-group-btn">
                            <span class="btn btn-primary waves-effect">{{get_string('plans')}} <i class="material-icons small">add_circle</i>
                                {!! Form::file('plans[]', ['id' => 'plans', 'class' => 'hidden', 'multiple']) !!}
                            </span>
                            </label>
                            <input type="text" class="form-control" readonly>
                        </div>
                        @if($errors->has('plans'))
                            <span class="wrong-error">* {{$errors->first('plans')}}</span>
                        @endif
                        <span class="field-info">{{get_string('select_plans')}}</span>
                    </div>

                    <div class="hidden-fields hidden">
                    </div>

                </div>

                <div id="data-panel" class="tab-pane">
                    <div class="col s6">
                        <div class="form-group  {{$errors->has('unit_type_id') ? 'has-error' : ''}}">
                            {{Form::select('project_unit_type_id', $unit_types, null, ['class' => 'category-select form-control', 'placeholder' => get_string('project_unit_types')])}}
                            {{Form::label('project_unit_type_id', get_string('project_unit_types'))}}
                            @if($errors->has('unit_type_id'))
                                <span class="wrong-error">* {{$errors->first('unit_type_id')}}</span>
                            @endif
                        </div>
                    </div>
                    <div class="col s6">
                        <div class="form-group  {{$errors->has('price') ? 'has-error' : ''}}">
                            {{Form::number('price', null, ['class' => 'category-select form-control', 'min' => 0, 'step' => 1, 'placeholder' => get_string('price')])}}
                            {{Form::label('price', get_string('price'))}}
                            @if($errors->has('price'))
                                <span class="wrong-error">* {{$errors->first('price')}}</span>
                            @endif
                        </div>
                    </div>
                    <div class="col l6 m6 s12">
                        <div class="form-group  {{$errors->has('area.feet') ? 'has-error' : ''}}">
                            {{Form::text('area[feet]', null, ['class' => 'feet-area form-control', 'placeholder' => get_string('property_size')])}}
                            {{Form::label('area[feet]', get_string('property_size').' feet')}}
                            @if($errors->has('area.feet'))
                                <span class="wrong-error">* {{$errors->first('area.feet')}}</span>
                            @endif
                        </div>
                    </div>
                    <div class="col l6 m6 s12">
                        <div class="form-group  {{$errors->has('area.m2') ? 'has-error' : ''}}">
                            {{Form::text('area[m2]', null, ['class' => 'm2-area form-control', 'placeholder' => get_string('property_size')])}}
                            {{Form::label('area[m2]', get_string('property_size').' m2')}}
                            @if($errors->has('area.m2'))
                                <span class="wrong-error">* {{$errors->first('area.m2')}}</span>
                            @endif
                        </div>
                    </div>
                    <div class="col s12 clearfix">
                        <h5 class="section-title">{{get_string('property_info')}}</h5>
                    </div>  
                    <div class="col l6 m6 s12">
                        <div class="form-group  {{$errors->has('property_info.rooms') ? 'has-error' : ''}}">
                            {{Form::text('property_info[rooms]', null, ['class' => 'form-control', 'placeholder' => get_string('property_rooms')])}}
                            {{Form::label('property_info[rooms]', get_string('property_rooms'))}}
                            @if($errors->has('property_info.rooms'))
                                <span class="wrong-error">* {{$errors->first('property_info.rooms')}}</span>
                            @endif
                        </div>
                    </div>
                    <div class="col l6 m6 s12">
                        <div class="form-group  {{$errors->has('property_info.bedrooms') ? 'has-error' : ''}}">
                            {{Form::text('property_info[bedrooms]', null, ['class' => 'form-control', 'placeholder' => get_string('property_bedrooms')])}}
                            {{Form::label('property_info[bedrooms]', get_string('property_bedrooms'))}}
                            @if($errors->has('property_info.bedrooms'))
                                <span class="wrong-error">* {{$errors->first('property_info.bedrooms')}}</span>
                            @endif
                        </div>
                    </div>
                    <div class="col l6 m6 s12">
                        <div class="form-group  {{$errors->has('property_info.bathrooms') ? 'has-error' : ''}}">
                            {{Form::text('property_info[bathrooms]', null, ['class' => 'form-control', 'placeholder' => get_string('property_bathrooms')])}}
                            {{Form::label('property_info[bathrooms]', get_string('property_bathrooms'))}}
                            @if($errors->has('property_info.bathrooms'))
                                <span class="wrong-error">* {{$errors->first('property_info.bathrooms')}}</span>
                            @endif
                        </div>
                    </div>
                    <div class="col l6 m6 s12">
                        <div class="form-group  {{$errors->has('property_info.garages') ? 'has-error' : ''}}">
                            {{Form::text('property_info[garages]', null, ['class' => 'form-control', 'placeholder' => get_string('property_garages')])}}
                            {{Form::label('property_info[garages]', get_string('property_garages'))}}
                            @if($errors->has('property_info.garages'))
                                <span class="wrong-error">* {{$errors->first('property_info.garages')}}</span>
                            @endif
                        </div>
                    </div>
                </div>
            </div>
            <div class="col clearfix s12 mtop10">
                <div class="form-group">
                    <button class="btn waves-effect" type="submit" name="action">{{get_string('create_unit')}}</button>
                    <a href="{{route('company_project_units', $id)}}" class="btn waves-effect">{{get_string('back')}}</a>
                </div>
            </div>
            {{Form::hidden('company_id', Auth::user()->id)}}
            {{Form::hidden('project_id', $id)}}
            {!!Form::close()!!}
        </div>
    </div>
</div>
@endsection

@section('footer')
    <script src="https://maps.googleapis.com/maps/api/js?key={{get_setting('google_map_key', 'site')}}&libraries=places"></script>
    <script>
        $(document).ready(function(){
            $('.desc-content').summernote({
                height: 200,
                maxwidth: false,
                minwidth: false,
                placeholder: '{{get_string('description')}}',
                disableDragAndDrop: true,
                toolbar: [
                    ["style", ["style"]],
                    ["font", ["bold", "underline", "clear"]],
                    ["color", ["color"]],
                    ["para", ["ul", "ol", "paragraph"]],
                ],callbacks: {
                    onPaste: function (e) {
                        var bufferText = ((e.originalEvent || e).clipboardData || window.clipboardData).getData('Text');
                        e.preventDefault();
                        document.execCommand('insertText', false, bufferText);
                    }
                }
            });


            $(this).on('input', '.feet-area', function() {
                if($(this).val() != '' ) $('.m2-area').val(parseFloat($(this).val()) * 0.092903);
                if($(this).val() == '' ) $('.m2-area').val('');
            });

            $(this).on('input', '.m2-area', function() {
                if($(this).val() != '' ) $('.feet-area').val(parseFloat($(this).val()) * 10.7639);
                if($(this).val() == '' ) $('.feet-area').val('');
            });

            $(this).on('input', '.country-select', function() {
                
                $.ajax({
                    url: '{{ route('company_property_get_provinces') }}',
                    type: 'post',
                    data: {_token: $('[name="_token"]').val(), country_id: $(this).val()},
                    success: function (data){
                        var html = '<option value="">{{ get_string('province') }}</option>';
                        $.each(data, function(key, value){
                            html += '<option value="' + key + '">'+ value +'</option>';
                        });

                        $('.province-select').html(html);
                    }   
                });

            });

             $(this).on('input', '.province-select', function() {
                
                $.ajax({
                    url: '{{ route('company_property_get_cities') }}',
                    type: 'post',
                    data: {_token: $('[name="_token"]').val(), province_id: $(this).val()},
                    success: function (data){
                        var html = '<option value="">{{ get_string('city') }}</option>';
                        $.each(data, function(key, value){
                            html += '<option value="' + key + '">'+ value +'</option>';
                        });

                        $('.city-select').html(html);
                    }   
                });

            });
        });

        Dropzone.autoDiscover = false;
        $(document).ready(function(){
            $('#file-dropzone').dropzone({
                url: '{{url('/image_handler/upload')}}',
                paramsName: 'image',
                params: {_token: $('[name=_token]').val()},
                maxFilesize: 100,
                uploadMultiple: false,
                addRemoveLinks: true,
                maxfilesize: 1,
                parallelUploads: 1,
                maxFiles: 6,
                init: function() {

                    this.on('success', function(file, json) {
                        var selector = file._removeLink;
                        $(selector).attr('data-dz-remove', json.data);
                        $('.hidden-fields').append('<input type="hidden" name="images[]" value="'+ json.data +'">');
                    });

                    this.on('addedfile', function(file) {

                    });

                    this.on("removedfile", function(file) {
                        var selector = file._removeLink;
                        var data = $(selector).attr('data-dz-remove');
                        $.ajax({
                            type: 'POST',
                            url: '{{url('/image_handler/delete')}}',
                            data: {data: data, _token: $('[name=_token]').val()},
                            dataType: 'html',
                            success: function(msg){
                                $('.hidden-fields').find('[value="'+ data +'"]').remove();
                            }
                        });
                    });
                }
            });
        });
        // Google Map
        $(document).ready(function() {
            if(typeof google !== 'undefined' && google){
                var map = new google.maps.Map(document.getElementById('google-map'), {
                    center:{
                        lat: 37.4515023,
                        lng: 34.8378279
                    },
                    zoom:4
                });
                var marker = new google.maps.Marker({
                    position: {
                        lat: 37.4515023,
                        lng: 34.8378279
                    },
                    map: map,
                    draggable: true
                });
                var infowindow = new google.maps.InfoWindow();
                var searchBox = document.getElementById('address-map');
                var autocomplete = new google.maps.places.Autocomplete(searchBox);

                autocomplete.bindTo('bounds', map);
                autocomplete.addListener('place_changed', function() {
                    infowindow.close();
                    marker.setVisible(false);
                    var place = autocomplete.getPlace();
                    if (!place.geometry) {
                        return;
                    }

                    // If the place has a geometry, then present it on a map.
                    if (place.geometry.viewport) {
                        map.fitBounds(place.geometry.viewport);
                    } else {
                        map.setCenter(place.geometry.location);
                        map.setZoom(15);
                    }

                    marker.setPosition(place.geometry.location);
                    marker.setVisible(true);

                    var address = '';
                    if (place.address_components) {
                        address = [
                            (place.address_components[0] && place.address_components[0].short_name || ''),
                            (place.address_components[1] && place.address_components[1].short_name || ''),
                            (place.address_components[2] && place.address_components[2].short_name || '')
                        ].join(' ');
                    }

                    infowindow.setContent('<div><strong>' + place.name + '</strong><br>' + address);
                    infowindow.open(map, marker);
                });

                google.maps.event.addListener(marker, 'position_changed', function () {
                    var lat = marker.getPosition().lat();
                    var lng = marker.getPosition().lng();
                    $('[name="geo_lng"]').val(lat);
                    $('[name="geo_lat"]').val(lng);
                });
                $('a[href$="location-panel"]').click(function(){
                    var currCenter = map.getCenter();
                    setTimeout(function(){
                        google.maps.event.trigger($("#google-map")[0], 'resize');
                        map.setCenter(currCenter);
                    }, 50);
                });
            }
        });
    </script>
@endsection