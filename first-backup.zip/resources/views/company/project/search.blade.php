@extends('layouts.company')

@section('title')
    <title>{{get_string('search_results') . ' - ' . get_setting('site_name', 'site')}}</title>
@endsection
@section('content')
@section('page_title')
    <h3 class="page-title mbot10">{{get_string('search_results')}}</h3>
@endsection
<div class="col s8 right right-align mbot10">
    <a href="{{route('company.project.index')}}" class="btn waves-effect"> {{get_string('project_all')}}</a>
    <a href="{{route('company.project.create')}}" class="btn waves-effect"> {{get_string('create_project')}} <i class="material-icons small">add_circle</i></a>
    <a href="#" class="mass-delete btn waves-effect btn-red"><i class="material-icons color-white">delete</i></a>
</div>
    <div class="col s12">
        @if($projects->count())
            <div class="table-responsive">
                <table class="table bordered striped">
                    <thead class="thead-inverse">
                    <tr>
                        <th>
                            <input type="checkbox" class="filled-in primary-color" id="select-all" />
                            <label for="select-all"></label>
                        </th>
                        <th>{{get_string('project')}}</th>
                        <th>{{get_string('company')}}</th>
                        <th>{{get_string('agent')}}</th>
                        <th>{{get_string('type')}}</th>
                        <th>{{get_string('location')}}</th>
                        <th>{{get_string('status')}}</th>
                        <th>{{get_string('featured')}}</th>
                        <th class="icon-options">{{get_string('options')}}</th>
                    </tr>
                    </thead>
                    <tbody>
                    @foreach($projects as $project)
                    <tr>
                        <td>
                            <input type="checkbox" class="filled-in primary-color" id="{{$project->id}}" />
                            <label for="{{$project->id}}"></label>
                        </td>
                        <td>{{$project->contentDefault->name}}</td>
                        <td>@if ($project->company){{$project->company->user->username}} @else <i class="small material-icons color-red">clear</i> @endif</td>
                        <td>@if ($project->agent){{$project->agent->user->username}} @else <i class="small material-icons color-red">clear</i> @endif</td>
                        <td>{{$project->type ? $project->type->contentDefault->name : ''}}</td>
                        <td>{{$project->city ? $project->city->contentDefault->name .', ' : '' }} {{$project->province ? $project->province->contentDefault->name .' - ' : '' }}  {{ $project->country ? $project->country->contentDefault->name : '' }}</td>
                        <td class="page-status">{{$project->status ? get_string('active') : get_string('pending')}}</td>
                        <td class="page-featured">{{$project->featured ? get_string('yes') : get_string('no')}}</td>
                        <td>
                            <div class="icon-options">
                                <a href="{{url('project').'/'.$project->alias}}" title="{{get_string('view_project')}}"><i class="small material-icons color-primary">visibility</i></a>

                                @if(!$project->agent_id) 

                                <a class="assign-button" data-id="{{$project->id}}" data-toggle="modal" href="#user-modal" title="{{get_string('assign_agent')}}"><i class="small material-icons color-primary">person</i></a> 

                                @endif

                                <a href="{{route('company_project_units', $project->id)}}"><i class="small material-icons color-primary">view_module</i></a>
                                <a href="{{route('company.project.edit', $project->id)}}" title="{{get_string('edit_project')}}"><i class="small material-icons color-primary">mode_edit</i></a>
                                <a href="#" class="delete-button" data-id="{{$project->id}}" title="{{get_string('delete_project')}}"><i class="small material-icons color-red">delete</i></a>
                            </div>
                        </td>
                    </tr>
                @endforeach
                    </tbody>
                </table>
            </div>
            {{$projects->links()}}
        @else
            <strong class="center-align">{{get_string('no_results')}}</strong>
        @endif
    </div>
<input type="hidden" name="_token" class="token" value="{{ csrf_token() }}">
@endsection

@section('footer')
<div id="user-modal" class="modal not-summernote fade" role="dialog">
    <div class="modal-dialog">
        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <a href="#!" class="close" data-dismiss="modal" aria-label="Close"><i class="material-icons">clear</i></a>
                <strong class="modal-title">{{get_string('assign_agent')}}</strong>
            </div>
            <div class="modal-body">
                {!! Form::open(['method' => 'post', 'url' => route('company_project_asign'), 'id' => 'user-form']) !!}
                {{ Form::input('hidden', 'project_id', null, ['class' => 'hidden', 'id' => 'project_id']) }}
                <div class="row mbot0">


                    <div class="col s12">
                        <div class="form-group  {{$errors->has('first_name') ? 'has-error' : ''}}">
                            {{Form::select('user_id', $agents, null, ['required', 'class' => 'form-control', 'placeholder' => get_string('select_agent')])}}
                            {{Form::label('user_id', get_string('select_agent'))}}
                            @if($errors->has('user_id'))
                                <span class="wrong-error">* {{$errors->first('user_id')}}</span>
                            @endif
                        </div>
                    </div>


                </div>
            </div>
            <div class="modal-footer">
                <a href="#!" class="waves-effect btn btn-default" data-dismiss="modal">{{get_string('close')}}</a>
                <button type="submit" name="action" class="update-lang-form waves-effect btn btn-default">{{get_string('assign')}}</button>
            </div>
            {!! Form::close() !!}
        </div>
    </div>
</div>
    <script>
        $(document).ready(function(){
            
            $('.assign-button').click(function(e){
                $('[name="project_id"]').val($(this).data('id'));
            });

            $('.delete-button').click(function(event){
                event.preventDefault();
                var id = $(this).data('id');
                var selector = $(this).parents('tr');
                var token = $('[name="_token"]').val();
                bootbox.confirm({
                    title: '{{get_string('confirm_action')}}',
                    message: '{{get_string('delete_confirm')}}',
                    onEscape: true,
                    backdrop: true,
                    buttons: {
                        cancel: {
                            label: '{{get_string('no')}}',
                            className: 'btn waves-effect'
                        },
                        confirm: {
                            label: '{{get_string('yes')}}',
                            className: 'btn waves-effect'
                        }
                    },
                    callback: function (result) {
                        if(result){
                            $.ajax({
                                url: '{{ url('/company/project/') }}/'+id,
                                type: 'post',
                                data: {_method: 'delete', _token :token},
                                success:function(msg) {
                                    selector.remove();
                                    toastr.success(msg);
                                },
                                error:function(msg){
                                    toastr.error(msg.responseJSON);
                                }
                            });
                        }
                    }
                });
            });

            $('.activate-button').click(function(event){
                event.preventDefault();
                var id = $(this).data('id');
                var selector = $(this).parents('tr');
                var thisBtn = $(this).parents('.icon-options');
                var status = selector.children('.page-status');
                var token = $('[name="_token"]').val();
                bootbox.confirm({
                    title: '{{get_string('confirm_action')}}',
                    message: '{{get_string('activate_project_confirm')}}',
                    onEscape: true,
                    backdrop: true,
                    buttons: {
                        cancel: {
                            label: '{{get_string('no')}}',
                            className: 'btn waves-effect'
                        },
                        confirm: {
                            label: '{{get_string('yes')}}',
                            className: 'btn waves-effect'
                        }
                    },
                    callback: function (result) {
                        if(result){
                            $.ajax({
                                url: '{{ url('/company/project/activate/') }}/'+id,
                                type: 'post',
                                data: {_token :token},
                                success:function(msg) {
                                    thisBtn.children('.activate-button').addClass('hidden');
                                    thisBtn.children('.deactivate-button').removeClass('hidden');
                                    status.html('{{get_string('active')}}');
                                    toastr.success(msg);
                                },
                                error:function(msg){
                                    toastr.error(msg.responseJSON);
                                }
                            });
                        }
                    }
                });
            });

            $('.deactivate-button').click(function(event){
                event.preventDefault();
                var id = $(this).data('id');
                var selector = $(this).parents('tr');
                var thisBtn = $(this).parents('.icon-options');
                var status = selector.children('.page-status');
                var token = $('[name="_token"]').val();
                bootbox.confirm({
                    title: '{{get_string('confirm_action')}}',
                    message: '{{get_string('deactivate_project_confirm')}}',
                    onEscape: true,
                    backdrop: true,
                    buttons: {
                        cancel: {
                            label: '{{get_string('no')}}',
                            className: 'btn waves-effect'
                        },
                        confirm: {
                            label: '{{get_string('yes')}}',
                            className: 'btn waves-effect'
                        }
                    },
                    callback: function (result) {
                        if(result){
                            $.ajax({
                                url: '{{ url('/company/project/deactivate/') }}/'+id,
                                type: 'post',
                                data: {_token :token},
                                success:function(msg) {
                                    thisBtn.children('.deactivate-button').addClass('hidden');
                                    thisBtn.children('.activate-button').removeClass('hidden');
                                    status.html('{{get_string('pending')}}');
                                    toastr.success(msg);
                                },
                                error:function(msg){
                                    toastr.error(msg.responseJSON);
                                }
                            });
                        }
                    }
                });
            });

            $('.make-featured-button').click(function(event){
                event.preventDefault();
                var id = $(this).data('id');
                var selector = $(this).parents('tr');
                var thisBtn = $(this).parents('.icon-options');
                var status = selector.children('.page-featured');
                var token = $('[name="_token"]').val();
                bootbox.prompt({
                    title: '{{get_string('confirm_action')}}',
                    inputType: 'select',
                    inputOptions: [
                        {
                            text: '{{ get_string('choose_your_package') }}',
                            value: '',
                        },
                        {
                            text: '{{ get_string('week_featured') }} - {{ get_setting('points_featured_week', 'payment') }} {{ get_string('points') }}',
                            value: '1',
                        },
                        {
                            text: '{{ get_string('month_featured') }} - {{ get_setting('points_featured_month', 'payment') }} {{ get_string('points') }}',
                            value: '2',
                        },
                        {
                            text: '{{ get_string('3months_featured') }} - {{ get_setting('points_featured_3months', 'payment') }} {{ get_string('points') }}',
                            value: '3',
                        }
                    ],
                    message: '{{get_string('make_featured_confirm')}}',
                    onEscape: true,
                    backdrop: true,
                    buttons: {
                        cancel: {
                            label: '{{get_string('no')}}',
                            className: 'btn waves-effect'
                        },
                        confirm: {
                            label: '{{get_string('yes')}}',
                            className: 'btn waves-effect'
                        }
                    },
                    callback: function (result) {
                        if(result){
                            $.ajax({
                                url: '{{ url('/company/project/makefeatured/') }}/'+id,
                                type: 'post',
                                data: {_token :token, price:result},
                                success:function(msg) {
                                    thisBtn.children('.make-featured-button').addClass('hidden');
                                    thisBtn.children('.make-default-button').removeClass('hidden');
                                    status.html('{{get_string('yes')}}');
                                    toastr.success(msg);
                                    setTimeout(function(){location.reload()}, 1500);
                                },
                                error:function(msg){
                                    toastr.error(msg.responseJSON);
                                }
                            });
                        }else{
                            toastr.warning('{{ get_string('choose_your_package') }}!');
                        }
                    }
                });
            });

            $('.make-default-button').click(function(event){
                event.preventDefault();
                var id = $(this).data('id');
                var selector = $(this).parents('tr');
                var thisBtn = $(this).parents('.icon-options');
                var status = selector.children('.page-featured');
                var token = $('[name="_token"]').val();
                bootbox.confirm({
                    title: '{{get_string('confirm_action')}}',
                    message: '{{get_string('make_default_confirm')}}',
                    onEscape: true,
                    backdrop: true,
                    buttons: {
                        cancel: {
                            label: '{{get_string('no')}}',
                            className: 'btn waves-effect'
                        },
                        confirm: {
                            label: '{{get_string('yes')}}',
                            className: 'btn waves-effect'
                        }
                    },
                    callback: function (result) {
                        if(result){
                            $.ajax({
                                url: '{{ url('/company/project/makedefault/') }}/'+id,
                                type: 'post',
                                data: {_token :token},
                                success:function(msg) {
                                    thisBtn.children('.make-default-button').addClass('hidden');
                                    thisBtn.children('.make-featured-button').removeClass('hidden');
                                    status.html('{{get_string('no')}}');
                                    toastr.success(msg);
                                },
                                error:function(msg){
                                    toastr.error(msg.responseJSON);
                                }
                            });
                        }
                    }
                });
            });


            $('.mass-delete').click(function(event){
                event.preventDefault();
                var id = [];
                var selector = [];
                $("tbody input:checkbox:checked").each(function(){
                    id.push($(this).attr('id'));
                    selector.push($(this).parents('tr'));
                });
                var token = $('[name="_token"]').val();
                bootbox.confirm({
                    title: '{{get_string('confirm_action')}}',
                    message: '{{get_string('delete_confirm_bulk')}}',
                    onEscape: true,
                    backdrop: true,
                    buttons: {
                        cancel: {
                            label: '{{get_string('no')}}',
                            className: 'btn waves-effect'
                        },
                        confirm: {
                            label: '{{get_string('yes')}}',
                            className: 'btn waves-effect'
                        }
                    },
                    callback: function (result) {
                        if(result){
                            $.ajax({
                                url: '{{ url('/company/project/massdestroy') }}',
                                type: 'post',
                                data: {id: id, _token :token},
                                success:function(msg) {
                                    $.each(selector, function(index, item){
                                        $(this).remove();
                                    });
                                    $('#select-all').prop('checked', false);
                                    toastr.success(msg);
                                },
                                error: function(msg){
                                    toastr.error(msg.responseJSON);
                                }
                            });
                        }
                    }
                });
            });
        });
    </script>
@endsection