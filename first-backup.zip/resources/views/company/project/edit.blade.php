@extends('layouts.company')

@section('title')
    <title>{{get_string('edit_project') . ' - ' . get_setting('site_name', 'site')}}</title>
@endsection
@section('style')
    <link href="{{ URL::asset('assets/css/plugins/backend_jquery-ui.min.css')}}" rel="stylesheet">
@endsection
@section('content')
@section('page_title')
    <h3 class="page-title mbot10">{{get_string('edit_project')}}</h3>
@endsection
<div class="col s12">
    @if(!$errors->isEmpty())
        <span class="wrong-error">* {{get_string('validation_error')}}</span>
    @endif
    {!!Form::open(['method' => 'patch', 'url' => route('company.project.update', $project->id), 'files' => 'true'])!!}
    <div class="panel">
        <div class="panel-heading">
            <ul class="nav nav-tabs">
               <li class="tab active"><a href="#content-panel" data-toggle="tab">{{get_string('content')}}</a></li>
                <li class="tab"><a href="#location-panel" data-toggle="tab">{{get_string('location')}}</a></li>
                <li class="tab"><a href="#data-panel" data-toggle="tab">{{get_string('data')}}</a></li>
                <li class="tab"><a href="#media-panel" data-toggle="tab">{{get_string('media')}}</a></li>
            </ul>
        </div>
        <div class="panel-body">
            <div class="tab-content">
                <div id="content-panel" class="tab-pane active">
                    <div class="panel">
                        <div class="panel-heading">
                            <ul class="nav nav-tabs">
                                @foreach($languages as $language)
                                    <li class="tab {{$language->default ? 'active' : ''}}"><a href="#lang{{$language->id}}" data-parent="#content" data-toggle="tab"><img src="{{$language->flag}}"/><span>{{$language->language}}</span></a></li>
                                @endforeach
                            </ul>
                        </div>
                        <div class="panel-body">
                            <div class="tab-content">
                                @foreach($languages as $language)
                                    <div id="lang{{$language->id}}" class="tab-pane {{$language->default ? 'active' : ''}}">
                                        <div class="col s12">
                                            <div class="form-group  {{$errors->has('name.'.$language->id.'') ? 'has-error' : ''}}">
                                                {{Form::text('name['.$language->id.']',  $project->content($language->id)->name, ['class' => 'form-control', 'placeholder' => get_string('name')])}}
                                                {{Form::label('name['.$language->id.']', get_string('name'))}}
                                                @if($errors->has('name.'.$language->id.''))
                                                    <span class="wrong-error">* {{$errors->first('name.'.$language->id.'')}}</span>
                                                @endif
                                            </div>
                                        </div>
                                        <div class="col s12">
                                            {{Form::textarea('description['.$language->id.']', $project->content($language->id)->description, ['class' => 'hidden desc-content'])}}
                                            @if($errors->has('description.'.$language->id.''))
                                                <span class="wrong-error">* {{$errors->first('description.'.$language->id.'')}}</span>
                                            @endif
                                        </div>
                                    </div>
                                @endforeach
                            </div>
                        </div>
                    </div>
                </div>
                <div id="location-panel" class="tab-pane">
                    <div class="col m4 s6">
                        <div class="form-group  {{$errors->has('country_id') ? 'has-error' : ''}}">
                            {{Form::select('country_id', $countries, $project->country_id, ['class' => 'country-select form-control', 'placeholder' => get_string('country')])}}
                            @if($errors->has('country_id'))
                                <span class="wrong-error">* {{$errors->first('country_id')}}</span>
                            @endif
                        </div>
                    </div>
                    <div class="col m4 s6">
                        <div class="form-group  {{$errors->has('province_id') ? 'has-error' : ''}}">
                            {{Form::select('province_id', $provinces, $project->province_id, ['class' => 'province-select form-control', 'placeholder' => get_string('province')])}}
                            @if($errors->has('province_id'))
                                <span class="wrong-error">* {{$errors->first('province_id')}}</span>
                            @endif
                        </div>
                    </div>
                    <div class="col m4 s6">
                        <div class="form-group  {{$errors->has('city_id') ? 'has-error' : ''}}">
                            {{Form::select('city_id', $cities, $project->city_id, ['class' => 'city-select form-control', 'placeholder' => get_string('city')])}}
                            @if($errors->has('city_id'))
                                <span class="wrong-error">* {{$errors->first('city_id')}}</span>
                            @endif
                        </div>
                    </div>
                    <div class="col s12">
                        <div class="row mbot0">
                            <div class="col l6 m12 s12">
                                <div class="row mbot0">
                                    <div class="col l12 m12 s12">
                                        <div class="form-group  {{$errors->has('address') ? 'has-error' : ''}}">
                                            {{Form::text('address', $project->address, ['class' => 'form-control', 'placeholder' => get_string('address')])}}
                                            {{Form::label('address', get_string('address'))}}
                                            @if($errors->has('address'))
                                                <span class="wrong-error">* {{$errors->first('address')}}</span>
                                            @endif
                                        </div>
                                    </div>
                                    <div class="col l12 m12 s12">
                                        <div class="form-group  {{$errors->has('zip') ? 'has-error' : ''}}">
                                            {{Form::text('zip', $project->zip, ['class' => 'form-control', 'placeholder' => get_string('zip')])}}
                                            {{Form::label('zip', get_string('zip'))}}
                                            @if($errors->has('zip'))
                                                <span class="wrong-error">* {{$errors->first('zip')}}</span>
                                            @endif
                                        </div>
                                    </div>
                                    <div class="col l12 m12 s12">
                                        <div class="form-group">
                                            {{Form::text('geo_lng', $project->geo_lng, ['class' => 'form-control', 'placeholder' => get_string('geo_lon'), 'readonly'])}}
                                            {{Form::label('geo_lng', get_string('geo_lon'))}}
                                        </div>
                                    </div>
                                    <div class="col l12 m12 s12">
                                        <div class="form-group">
                                            {{Form::text('geo_lat', $project->geo_lat, ['class' => 'form-control', 'placeholder' => get_string('geo_lat'), 'readonly'])}}
                                            {{Form::label('geo_lat', get_string('geo_lat'))}}
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col l6 m12 s12">
                                <div class="form-group  {{($errors->has('location.geo_lon') || ($errors->has('location.geo_lon')))  ? 'has-error' : ''}}">
                                    {{Form::text('marker', null, ['class' => 'form-control autocomplete', 'id' => 'address-map', 'placeholder' => get_string('drop_marker')])}}
                                    {{Form::label('marker', get_string('drop_marker'))}}
                                    @if($errors->has('geo_lng') || $errors->has('geo_lat'))
                                        <span class="wrong-error">* {{get_string('google_address_required')}} </span>
                                    @endif
                                </div>
                                <div id="google-map">
                                </div>
                                <span class="field-info">{{get_string('drag_marker')}}</span>
                            </div>
                        </div>
                    </div>
                </div>
                <div id="media-panel" class="tab-pane">
                    <div class="col l12 m12 s12">
                        <div id="file-dropzone" class="dropzone">
                            <div class="dz-message">{{get_string('upload_images')}}<br/><i class="material-icons medium">cloud_upload</i>
                            </div>
                            <div class="fallback">
                            </div>
                        </div>
                    </div>

                    <div class="col s12">
                        <div class="form-group  {{$errors->has('video') ? 'has-error' : ''}}">
                            {{Form::text('video', $project->video, ['class' => 'form-control', 'placeholder' => get_string('video_id')])}}
                            {{Form::label('video', get_string('video_id'))}}
                            @if($errors->has('video'))
                                <span class="wrong-error">* {{$errors->first('video')}}</span>
                            @endif
                        </div>
                    </div>

                    <div class="col l6 m6 s12">
                        <div class="input-group {{$errors->has('image') ? 'has-error' : ''}}">
                            <label class="input-group-btn">
                            <span class="btn btn-primary waves-effect">{{get_string('logo')}} <i class="material-icons small">add_circle</i>
                                {!! Form::file('image', ['id' => 'image', 'class' => 'hidden']) !!}
                            </span>
                            </label>
                            <input type="text" class="form-control" readonly>
                        </div>
                        @if($errors->has('image'))
                            <span class="wrong-error">* {{$errors->first('image')}}</span>
                        @endif
                        <span class="field-info">{{get_string('min_dimension_360')}}</span>
                    </div>

                    <div class="hidden-fields hidden">
                    </div>
                </div>
                <div id="data-panel" class="tab-pane">
                    <div class="col s6">
                        <div class="form-group  {{$errors->has('project_type_id') ? 'has-error' : ''}}">
                            {{Form::select('project_type_id', $project_types, $project->project_type_id, ['class' => 'category-select form-control', 'placeholder' => get_string('project_types')])}}
                            {{Form::label('project_type_id', get_string('project_types'))}}
                            @if($errors->has('project_type_id'))
                                <span class="wrong-error">* {{$errors->first('project_type_id')}}</span>
                            @endif
                        </div>
                    </div>
                    <div class="col s6">
                        <div class="form-group  {{$errors->has('number_of_units') ? 'has-error' : ''}}">
                            {{Form::number('number_of_units', $project->number_of_units, ['class' => 'category-select form-control', 'min' => 0, 'step' => 1, 'placeholder' => get_string('number_of_units')])}}
                            {{Form::label('number_of_units', get_string('number_of_units'))}}
                            @if($errors->has('number_of_units'))
                                <span class="wrong-error">* {{$errors->first('number_of_units')}}</span>
                            @endif
                        </div>
                    </div>
                    <div class="col s6">
                        <div class="form-group  {{$errors->has('prices.min') ? 'has-error' : ''}}">
                            {{Form::number('prices[min]', $project->prices['min'], ['class' => 'category-select form-control', 'min' => 0, 'step' => 1, 'placeholder' => get_string('price').' min'])}}
                            {{Form::label('prices[min]', get_string('price') .' min')}}
                            @if($errors->has('prices.min'))
                                <span class="wrong-error">* {{$errors->first('prices.min')}}</span>
                            @endif
                        </div>
                    </div>
                    <div class="col s6">
                        <div class="form-group  {{$errors->has('prices.max') ? 'has-error' : ''}}">
                            {{Form::number('prices[max]', $project->prices['max'], ['class' => 'category-select form-control', 'min' => 0, 'step' => 1, 'placeholder' => get_string('price').' max'])}}
                            {{Form::label('prices[max]', get_string('price') .' max')}}
                            @if($errors->has('prices.max'))
                                <span class="wrong-error">* {{$errors->first('prices.max')}}</span>
                            @endif
                        </div>
                    </div>
                    <div class="col s6">
                        <div class="form-group  {{$errors->has('developer') ? 'has-error' : ''}}">
                            {{Form::text('developer', $project->developer, ['class' => 'category-select form-control', 'placeholder' => get_string('developer')])}}
                            {{Form::label('developer', get_string('developer'))}}
                            @if($errors->has('developer'))
                                <span class="wrong-error">* {{$errors->first('developer')}}</span>
                            @endif
                        </div>
                    </div>
                    <div class="col s6 backend-datepicker">
                        <div class="form-group  {{$errors->has('delivery_date') ? 'has-error' : ''}}">
                            {{Form::text('delivery_date', $project->delivery_date, ['class' => 'datepicker category-select form-control', 'placeholder' => get_string('delivery_date')])}}
                            {{Form::label('delivery_date', get_string('delivery_date'))}}
                            @if($errors->has('delivery_date'))
                                <span class="wrong-error">* {{$errors->first('delivery_date')}}</span>
                            @endif
                        </div>
                    </div>
                    <div class="col s6">
                        <div class="form-group  {{$errors->has('payment_plan') ? 'has-error' : ''}}">
                            {{Form::text('payment_plan', $project->payment_plan, ['class' => 'category-select form-control', 'placeholder' => get_string('payment_plan')])}}
                            {{Form::label('payment_plan', get_string('payment_plan'))}}
                            @if($errors->has('payment_plan'))
                                <span class="wrong-error">* {{$errors->first('payment_plan')}}</span>
                            @endif
                        </div>
                    </div>
                    <div class="col s12 well checkbox-grid">
                        <p>{{get_string('choose_features')}}</p>
                        @foreach($features as $feature)
                            <div class="col s2">
                                <div class="form-group">
                                    <input type="checkbox" name="features[]" @if((old('features') && in_array_r($feature->id, old('features'))) || ($project->features && in_array($feature->id, $project->features))) checked @endif value="{{$feature->id}}" class="filled-in primary-color" id="{{$feature->id}}" />
                                    <label for="{{$feature->id}}"></label>
                                    <span class="checkbox-label">{{$feature->feature[$default_language->id]}}</span>
                                </div>
                            </div>
                        @endforeach
                    </div>
                    
                    <div class="hidden-fields hidden">
                    </div>
                </div>
            </div>
            <div class="col clearfix s12 mtop10">
                <div class="form-group">
                    <button class="btn waves-effect" type="submit" name="action">{{get_string('edit_project')}}</button>
                    <a href="{{route('company.project.index')}}" class="btn waves-effect">{{get_string('project_all')}}</a>
                    <a href="#" class="delete-button btn waves-effect btn-red" data-id="{{$project->id}}"><i class="material-icons color-white">delete</i></a>
                </div>
            </div>
            {{Form::hidden('company_id', Auth::user()->id)}}
            {{Form::hidden('agent_id', $project->agent_id ?: 0)}}
            {!!Form::close()!!}
        </div>
    </div>
</div>
@endsection

@section('footer')
    <script src="https://maps.googleapis.com/maps/api/js?key={{get_setting('google_map_key', 'site')}}&libraries=places"></script>
    <script>
        $(document).ready(function(){
            $('.desc-content').summernote({
                height: 200,
                maxwidth: false,
                minwidth: false,
                placeholder: '{{get_string('enter_project_content')}}',
                disableDragAndDrop: true,
                toolbar: [
                    ["style", ["style"]],
                    ["font", ["bold", "underline", "clear"]],
                    ["color", ["color"]],
                    ["para", ["ul", "ol", "paragraph"]],
                ],callbacks: {
                    onPaste: function (e) {
                        var bufferText = ((e.originalEvent || e).clipboardData || window.clipboardData).getData('Text');
                        e.preventDefault();
                        document.execCommand('insertText', false, bufferText);
                    }
                }
            });
        
        // Datepickers
            $('.datepicker').datepicker({
                dateFormat: 'dd/mm/yy',
                minDate: 0,
                onSelect: function(dateText, inst) {
                    var startDate = $(this).datepicker('getDate');
                    startDate.setDate(startDate.getDate() + 1);
                    $("[name='delivery_date']").val(dateText);
                }
            });

            $(this).on('click change', '.country-select', function() {
                if(!(this.selectedIndex == -1)) getProvincesByCountry($(this).val());
            });

            $(this).on('click change', '.province-select', function() {
                if(!(this.selectedIndex == -1)) getCitiesByProvince($(this).val());                    
            });
        });

        function getProvincesByCountry(id) {
            $.ajax({
                url: '{{ route('company_property_get_provinces') }}',
                type: 'post',
                data: {_token: $('[name="_token"]').val(), country_id: id},
                success: function (data){
                    var html = '<option value="">{{ get_string('province') }}</option>';
                    $.each(data, function(key, value){
                        html += '<option value="' + key + '">'+ value +'</option>';
                    });

                    $('.province-select').html(html);
                }   
            });
        }

        function getCitiesByProvince(id) {
            $.ajax({
                url: '{{ route('company_property_get_cities') }}',
                type: 'post',
                data: {_token: $('[name="_token"]').val(), province_id: id},
                success: function (data){
                    var html = '<option value="">{{ get_string('city') }}</option>';
                    $.each(data, function(key, value){
                        html += '<option value="' + key + '">'+ value +'</option>';
                    });

                    $('.city-select').html(html);
                }   
            });
        }

        Dropzone.autoDiscover = false;
        $(document).ready(function(){
            var fileDropzone = $('#file-dropzone');
            $(fileDropzone).dropzone({
                url: '{{url('/image_handler/upload')}}',
                paramsName: 'image',
                params: {_token: $('[name=_token]').val()},
                maxFilesize: 100,
                uploadMultiple: false,
                addRemoveLinks: true,
                maxfilesize: 1,
                parallelUploads: 1,
                maxFiles: 6,
                init: function() {

                    @if($project->images)
                        @foreach($project->images as $image)
                            var mockFile = { name: '{{ $image->image }}', size: 100000 };
                            this.emit("addedfile", mockFile);
                            this.createThumbnailFromUrl(mockFile, '/images/data/{{ $image->image }}');
                            this.emit("success", mockFile);
                        $('.hidden-fields').append('<input type="hidden" name="images[]" value="{{ $image->image }}">');
                        @endforeach
                    @endif

                    this.on('success', function(file, json) {
                        var selector = file._removeLink;
                        $(selector).attr('data-dz-remove', json.data);
                        $('.hidden-fields').append('<input type="hidden" name="images[]" value="'+ json.data +'">');
                    });

                    this.on('addedfile', function(file) {

                    });

                    this.on("removedfile", function(file) {
                        var selector = file._removeLink;
                        var data = $(selector).attr('data-dz-remove');
                        if(!data){
                            data = file.name;
                            $.ajax({
                                type: 'POST',
                                url: '{{url('/image_handler/deleteBase')}}',
                                data: {data: data, _token: $('[name=_token]').val(), type: 'project', id: '{{$project->id}}'},
                                dataType: 'html',
                                success: function(msg){
                                    $('.hidden-fields').find('[value="'+ data +'"]').remove();
                                }
                            });
                        }else{
                            $.ajax({
                                type: 'POST',
                                url: '{{url('/image_handler/delete')}}',
                                data: {data: data, _token: $('[name=_token]').val()},
                                dataType: 'html',
                                success: function(msg){
                                    $('.hidden-fields').find('[value="'+ data +'"]').remove();
                                }
                            });
                        }
                    });
                }
            });
        });

        // Google Map
        $(document).ready(function() {
            if(typeof google !== 'undefined' && google){
                var map = new google.maps.Map(document.getElementById('google-map'), {
                    center:{
                        lat: {{ $project->geo_lng }},
                        lng: {{ $project->geo_lat }}
                    },
                    zoom: 10
                });
                var marker = new google.maps.Marker({
                    position: {
                        lat: {{ $project->geo_lng }},
                        lng: {{ $project->geo_lat }}
                    },
                    map: map,
                    draggable: true
                });
                var infowindow = new google.maps.InfoWindow();
                var searchBox = document.getElementById('address-map');
                var autocomplete = new google.maps.places.Autocomplete(searchBox);

                autocomplete.bindTo('bounds', map);
                autocomplete.addListener('place_changed', function() {
                    infowindow.close();
                    marker.setVisible(false);
                    var place = autocomplete.getPlace();
                    if (!place.geometry) {
                        return;
                    }

                    // If the place has a geometry, then present it on a map.
                    if (place.geometry.viewport) {
                        map.fitBounds(place.geometry.viewport);
                    } else {
                        map.setCenter(place.geometry.location);
                        map.setZoom(15);
                    }

                    marker.setPosition(place.geometry.location);
                    marker.setVisible(true);

                    var address = '';
                    if (place.address_components) {
                        address = [
                            (place.address_components[0] && place.address_components[0].short_name || ''),
                            (place.address_components[1] && place.address_components[1].short_name || ''),
                            (place.address_components[2] && place.address_components[2].short_name || '')
                        ].join(' ');
                    }

                    infowindow.setContent('<div><strong>' + place.name + '</strong><br>' + address);
                    infowindow.open(map, marker);
                });

                google.maps.event.addListener(marker, 'position_changed', function () {
                    var lat = marker.getPosition().lat();
                    var lng = marker.getPosition().lng();
                    $('[name="geo_lng"]').val(lat);
                    $('[name="geo_lat"]').val(lng);
                });
                $('a[href$="location-panel"]').click(function(){
                    var currCenter = map.getCenter();
                    setTimeout(function(){
                        google.maps.event.trigger($("#google-map")[0], 'resize');
                        map.setCenter(currCenter);
                    }, 50);
                });
            }
        });
        $(document).ready(function(){
            $('.delete-button').click(function(event){
                event.preventDefault();
                var id = $(this).data('id');
                var token = $('[name="_token"]').val();
                bootbox.confirm({
                    title: '{{get_string('confirm_action')}}',
                    message: '{{get_string('delete_confirm')}}',
                    onEscape: true,
                    backdrop: true,
                    buttons: {
                        cancel: {
                            label: '{{get_string('no')}}',
                            className: 'btn waves-effect'
                        },
                        confirm: {
                            label: '{{get_string('yes')}}',
                            className: 'btn waves-effect'
                        }
                    },
                    callback: function (result) {
                        if(result){
                            $.ajax({
                                url: '{{ url('/company/project/') }}/'+id,
                                type: 'post',
                                data: {_method: 'delete', _token :token},
                                success:function(msg) {
                                    window.location = "/company/project";
                                }
                            });
                        }
                    }
                });
            });
        });
    </script>
@endsection