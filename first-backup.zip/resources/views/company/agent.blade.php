@extends('layouts.company')

@section('title')
    <title>{{get_string('agents') . ' - ' . get_setting('site_name', 'site')}}</title>
@endsection
@section('content')
@section('page_title')
    <h3 class="page-title mbot10">{{get_string('agents')}}</h3>
@endsection
<div class="col l12 m12 s12 right right-align mbot10">
    <a href="#user-modal" data-toggle="modal" class="add-button btn waves-effect"> {{ get_string('create_agent')}} <i class="material-icons small">add_circle</i></a>
</div>
<div class="col s12">
    @if(Session::has('maximum_agents'))
        <span class="wrong-error">* {{get_string('maximum_agents')}}</span>
    @endif
    @if(!$errors->isEmpty())
        <span class="wrong-error">* {{get_string('validation_error')}}</span>
    @endif
    @if($users->count())
        <div class="table-responsive">
            <table class="table bordered striped">
                <thead class="thead-inverse">
                <tr>
                    <th>
                        <input type="checkbox" class="filled-in primary-color" id="select-all" />
                        <label for="select-all"></label>
                    </th>
                    <th>{{get_string('username')}}</th>
                    <th>{{get_string('email')}}</th>
                    <th>{{get_string('first_name')}}</th>
                    <th>{{get_string('last_name')}}</th>
                    <th>{{get_string('subadmin')}}</th>
                    <th class="icon-options">{{get_string('options')}}</th>
                </tr>
                </thead>
                <tbody>
                @foreach($users as $user)
                    <tr>
                        <td>
                            <input type="checkbox" class="filled-in primary-color" id="{{$user->id}}" />
                            <label for="{{$user->id}}"></label>
                        </td>
                        <td>{{$user->username}}</td>
                        <td>{{$user->email}}</td>
                        <td>{{$user->agent->first_name}}</td>
                        <td>{{$user->agent->last_name}}</td>
                        <td>{{$user->agent->is_subadmin ? get_string('yes') : get_string('no') }}</td>
                        <td>
                            <div class="icon-options">
                                <a href="#" class="delete-button" data-id="{{$user->id}}" title="{{get_string('delete_user')}}"><i class="small material-icons color-red">delete</i></a>
                                @if(!$user->agent->is_subadmin)
                                    <a href="#" class="upgrade-button" data-id="{{$user->id}}" title="{{get_string('upgrade_user')}}"><i class="small material-icons color-blue">add_box</i></a>
                                @endif
                            </div>
                        </td>
                    </tr>
                @endforeach
                </tbody>
            </table>
        </div>
        {{$users->links()}}
    @else
        <strong class="center-align clearfix">{{get_string('no_results')}}</strong>
    @endif
</div>
@endsection

@section('footer')
<!-- Modal -->
<div id="user-modal" class="modal not-summernote fade" role="dialog">
    <div class="modal-dialog">
        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <a href="#!" class="close" data-dismiss="modal" aria-label="Close"><i class="material-icons">clear</i></a>
                <strong class="modal-title">{{get_string('create_agent')}}</strong>
            </div>
            <div class="modal-body">
                {!! Form::open(['method' => 'post', 'url' => route('company_agent_create'), 'id' => 'user-form']) !!}
                {{ Form::input('hidden', 'id', null, ['class' => 'hidden', 'id' => 'user_id']) }}
                <div class="row mbot0">
                    <div class="col l6 s12">
                        <div class="form-group  {{$errors->has('first_name') ? 'has-error' : ''}}">
                            {{Form::text('first_name', null, [ 'id' => 'user-first-name', 'class' => 'form-control', 'placeholder' => get_string('first_name')])}}
                            {{Form::label('first_name', get_string('first_name'))}}
                            @if($errors->has('first_name'))
                                <span class="wrong-error">* {{$errors->first('first_name')}}</span>
                            @endif
                        </div>
                    </div>
                    <div class="col l6 s12">
                        <div class="form-group  {{$errors->has('last_name') ? 'has-error' : ''}}">
                            {{Form::text('last_name', null, [ 'id' => 'user-last-name', 'class' => 'form-control', 'placeholder' => get_string('last_name')])}}
                            {{Form::label('last_name', get_string('last_name'))}}
                            @if($errors->has('last_name'))
                                <span class="wrong-error">* {{$errors->first('last_name')}}</span>
                            @endif
                        </div>
                    </div>
                    <div class="col l6 s12 clearfix">
                        <div class="form-group  {{$errors->has('email') ? 'has-error' : ''}}">
                            {{Form::text('email', null, [ 'id' => 'user-email', 'required', 'class' => 'form-control', 'placeholder' => get_string('email')])}}
                            {{Form::label('email', get_string('email'))}}
                            @if($errors->has('email'))
                                <span class="wrong-error">* {{$errors->first('email')}}</span>
                            @endif
                        </div>
                    </div>
                    <div class="col l6 s12">
                        <div class="form-group  {{$errors->has('username') ? 'has-error' : ''}}">
                            {{Form::text('username', null, [ 'id' => 'user-username', 'required', 'class' => 'form-control', 'placeholder' => get_string('username')])}}
                            {{Form::label('username', get_string('username'))}}
                            @if($errors->has('username'))
                                <span class="wrong-error">* {{$errors->first('username')}}</span>
                            @endif
                        </div>
                    </div>
                    <div class="col l6 s12">
                        <div class="form-group  {{$errors->has('contact_phone') ? 'has-error' : ''}}">
                            {{Form::text('contact_phone', null, [ 'id' => 'user-last-name', 'class' => 'form-control', 'placeholder' => get_string('contact') .' '. get_string('phone')])}}
                            {{Form::label('contact_phone', get_string('contact') .' '. get_string('phone'))}}
                            @if($errors->has('contact_phone'))
                                <span class="wrong-error">* {{$errors->first('contact_phone')}}</span>
                            @endif
                        </div>
                    </div>
                    <div class="col l6 s12">
                        <div class="form-group  {{$errors->has('contact_email') ? 'has-error' : ''}}">
                            {{Form::text('contact_email', null, [ 'id' => 'user-contact_email', 'class' => 'form-control', 'placeholder' => get_string('contact') .' '. get_string('email')])}}
                            {{Form::label('contact_email', get_string('contact') .' '. get_string('email'))}}
                            @if($errors->has('contact_email'))
                                <span class="wrong-error">* {{$errors->first('contact_email')}}</span>
                            @endif
                        </div>
                    </div>
                    <div class="col s12">
                        <div class="form-group  {{$errors->has('position') ? 'has-error' : ''}}">
                            {{Form::text('position', null, [ 'id' => 'user-position', 'required', 'class' => 'form-control', 'placeholder' => get_string('position')])}}
                            {{Form::label('position', get_string('position'))}}
                            @if($errors->has('position'))
                                <span class="wrong-error">* {{$errors->first('position')}}</span>
                            @endif
                        </div>
                    </div>
                    {!! Form::hidden('is_subadmin', 0) !!}
                    {!! Form::hidden('image', 'no_image.jpg') !!}
                    {!! Form::hidden('user_id', Auth::user()->id) !!}
                </div>
            </div>
            <div class="modal-footer">
                <a href="#!" class="waves-effect btn btn-default" data-dismiss="modal">{{get_string('close')}}</a>
                <button type="submit" name="action" class="update-lang-form waves-effect btn btn-default">{{get_string('update')}}</button>
            </div>
            {!! Form::close() !!}
        </div>
    </div>
</div>
<script>
    $(document).ready(function(){

        $('.delete-button').click(function(event){
            event.preventDefault();
            var id = $(this).data('id');
            var selector = $(this).parents('tr');
            var token = $('[name=_token]').val();
            bootbox.confirm({
                title: '{{get_string('confirm_action')}}',
                message: '{{get_string('delete_confirm')}}',
                onEscape: true,
                backdrop: true,
                buttons: {
                    cancel: {
                        label: '{{get_string('no')}}',
                        className: 'btn waves-effect'
                    },
                    confirm: {
                        label: '{{get_string('yes')}}',
                        className: 'btn waves-effect'
                    }
                },
                callback: function (result) {
                    if(result){
                        $.ajax({
                            url: '{{ url('/company/agent/destroy') }}/'+id,
                            type: 'post',
                            data: {_token :token},
                            success:function(msg) {
                                selector.remove();
                                toastr.success(msg);
                            },
                            error:function(msg){
                                toastr.error(msg.responseJSON);
                            }
                        });
                    }
                }
            });
        });

        $('.upgrade-button').click(function(event){
            event.preventDefault();
            var id = $(this).data('id');
            var selector = $(this).parents('tr');
            var token = $('[name=_token]').val();
            bootbox.confirm({
                title: '{{get_string('confirm_action')}}',
                message: '{{get_string('upgrade_user_confirm')}}',
                onEscape: true,
                backdrop: true,
                buttons: {
                    cancel: {
                        label: '{{get_string('no')}}',
                        className: 'btn waves-effect'
                    },
                    confirm: {
                        label: '{{get_string('yes')}}',
                        className: 'btn waves-effect'
                    }
                },
                callback: function (result) {
                    if(result){
                        $.ajax({
                            url: '{{ url('/company/agent/upgrade') }}/'+id,
                            type: 'post',
                            data: {_token :token},
                            success:function(msg) {
                                toastr.success(msg);
                            },
                            error:function(msg){
                                toastr.error(msg.responseJSON);
                            }
                        });
                    }
                }
            });
        });
    });
    </script>
@endsection