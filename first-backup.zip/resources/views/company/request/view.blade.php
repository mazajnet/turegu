@extends('layouts.company')

@section('title')
    <title>{{get_string('view_tours') . ' - ' . get_setting('site_name', 'site')}}</title>
@endsection
@section('content')
@section('page_title')
    <h3 class="page-title mbot10">{{get_string('view_tours')}}</h3>
@endsection
<div class="col s12">
    @if($tours->count())
        <div class="table-responsive">
            <table class="table bordered striped">
                <thead class="thead-inverse">
                <tr>
                    <th>
                        <input type="checkbox" class="filled-in primary-color" id="select-all" />
                        <label for="select-all"></label>
                    </th>
                    <th>{{get_string('agent')}}</th>
                    <th>{{get_string('date')}}</th>
                    <th>{{get_string('seats')}}</th>
                    <th>{{get_string('payment_method')}}</th>
                    <th>{{get_string('status')}}</th>
                    <th>{{get_string('completed')}}</th>
                    <th class="icon-options">{{get_string('options')}}</th>
                </tr>
                </thead>
                <tbody>
                @foreach($tours as $tour)
                    <tr @if($tour->completed) class="disabled-style" @endif>
                        <td>
                            <input type="checkbox" class="filled-in primary-color" id="{{$tour->id}}" />
                            <label for="{{$tour->id}}"></label>
                        </td>
                        <td>@if($tour->viewTour->agent) {{ $tour->viewTour->agent->username }} @endif</td>
                        <td>@if($tour->viewTour) {{$tour->viewTour->start_date .' - '. $tour->viewTour->end_date}} @endif</td>
                        <td>{{$tour->seats}}</td>
                        <td>{{ $payment_methods[$tour->payment_method] }}</td>
                        <td>@if(!$tour->status) {{ get_string('pending') }} @elseif($tour->status == 1) {{ get_string('confirmed') }} @else {{ get_string('rejected') }} @endif</td>
                        <td class="booking-status">{{$tour->completed ? get_string('yes') : get_string('no')}}</td>
                        <td>
                            <div class="icon-options">
                                <a href="#" class="confirm-button" data-id="{{$tour->id}}"><i class="small material-icons color-primary">done</i></a>
                                <a href="#" class="reject-button" data-id="{{$tour->id}}"><i class="small material-icons color-red">close</i></a>
                                <a href="#user-modal" data-toggle="modal" class="user-info" data-id="{{$tour->id}}" title="{{get_string('user_info')}}"><i class="small material-icons color-blue">person</i></a>
                            </div>
                        </td>
                    </tr>
                @endforeach
                </tbody>
            </table>
        </div>
        {{$tours->links()}}
    @else
        <strong class="center-align">{{get_string('no_results')}}</strong>
    @endif
</div>
<input type="hidden" class="token" value="{{ csrf_token() }}">
@endsection

@section('footer')
    <div id="user-modal" class="modal not-summernote fade" role="dialog">
        <div class="modal-dialog">
            <!-- Modal content-->
            <div class="modal-content">
                <div class="modal-header">
                    <a href="#!" class="close" data-dismiss="modal" aria-label="Close"><i class="material-icons">clear</i></a>
                    <strong class="modal-title">{{get_string('user_info')}}</strong>
                </div>
                <div class="modal-body" id="user-details"></div>
                <div class="modal-footer">
                    <a href="#!" class="waves-effect btn btn-default" data-dismiss="modal">{{get_string('close')}}</a>
                </div>
            </div>
        </div>
    </div>
<script type="text/javascript">
    $(document).ready(function(){
        $("#user-modal").on('hidden.bs.modal', function () {
            $('#user-details').html('');
        });
        $('.user-info').click(function(e){
            e.preventDefault();
            var id = $(this).data('id');
            var token = $('.token').val();
            $.ajax({
                url: '{{ url('/company/request/user_details') }}/' + id,
                type: 'post',
                data: {_token: token, type: 0},
                success: function (msg) {
                    var first_name = (typeof msg.first_name !== 'undefined') ? msg.first_name : '';
                    var last_name = (typeof msg.last_name !== 'undefined') ? msg.last_name : '';
                    var phone = (typeof msg.phone !== 'undefined') ? msg.phone : '';
                    var email = (typeof msg.email !== 'undefined') ? msg.email : '';
                    $('#user-details').html('<span class="first-name"><span>{{ get_string('first_name') }}: </span>'+ first_name +'</span><span class="last-name"><span>{{ get_string('last_name') }}: </span>'+ last_name +'</span><span class="email"><span>{{ get_string('email') }}: </span>'+ email +'</span><span class="phone"><span>{{ get_string('phone') }}: </span>'+ phone +'</span>');
                },
                error: function (msg) {
                    toastr.error(msg.responseJSON);
                }
            });
        });

        $('.confirm-button').click(function(event){
            event.preventDefault();
            var id = $(this).data('id');
            var selector = $(this).parents('tr');
            var status = $('.booking-status', selector);
            var token = $('.token').val();
            if(!selector.hasClass('disabled-style')) {
                bootbox.confirm({
                    title: '{{get_string('confirm_action')}}',
                    message: '{{get_string('activate_booking_confirm')}}',
                    onEscape: true,
                    backdrop: true,
                    buttons: {
                        cancel: {
                            label: '{{get_string('no')}}',
                            className: 'btn waves-effect'
                        },
                        confirm: {
                            label: '{{get_string('yes')}}',
                            className: 'btn waves-effect'
                        }
                    },
                    callback: function (result) {
                        if (result) {
                            $.ajax({
                                url: '{{ url('/company/request/activate') }}/' + id,
                                type: 'post',
                                data: {_token: token, type: 0},
                                beforeSend: function(){
                                    $('.table').addClass('loading');
                                },
                                success: function (msg) {
                                    selector.addClass('disabled-style');
                                    status.html('{{get_string('yes')}}');
                                    toastr.success(msg);
                                    
                                    setTimeout(function(){
                                        $('.table').removeClass('loading');
                                        location.reload();
                                    }, 1200);
                                },
                                error: function (msg) {
                                    toastr.error(msg.responseJSON);
                                    $('.table').removeClass('loading');
                                }
                            });
                        }
                    }
                });
            }
        });

        $('.reject-button').click(function(event){
            event.preventDefault();
            var id = $(this).data('id');
            var selector = $(this).parents('tr');
            var status = $('.booking-status', selector);
            var token = $('.token').val();
            if(!selector.hasClass('disabled-style')) {
                bootbox.confirm({
                    title: '{{get_string('confirm_action')}}',
                    message: '{{get_string('reject_booking_confirm')}} <br/> <div id="reason" class="form-group"><textarea name="reason" class="form-control"></textarea></div>',
                    onEscape: true,
                    backdrop: true,
                    buttons: {
                        cancel: {
                            label: '{{get_string('no')}}',
                            className: 'btn waves-effect'
                        },
                        confirm: {
                            label: '{{get_string('yes')}}',
                            className: 'btn waves-effect'
                        }
                    },
                    callback: function (result) {
                        console.log(result, $('[name="reason"]').val() != '');
                        if (result) {
                            $.ajax({
                                url: '{{ url('/company/request/reject') }}/' + id,
                                type: 'post',
                                data: {_token: token, type: 0, reason: $('[name="reason"]').val()},
                                beforeSend: function(){
                                    $('.table').addClass('loading');
                                },
                                success: function (msg) {
                                    selector.addClass('disabled-style');
                                    status.html('{{get_string('yes')}}');
                                    toastr.success(msg);

                                    setTimeout(function(){
                                        $('.table').removeClass('loading');
                                        location.reload();
                                    }, 1200);
                                },
                                error: function (msg) {
                                    toastr.error(msg.responseJSON);
                                    $('.table').removeClass('loading');
                                }
                            });
                        }
                    }
                });
            }
        });

        $('.delete-button').click(function(event){
            event.preventDefault();
            var id = $(this).data('id');
            var selector = $(this).parents('tr');
            var token = $('.token').val();
            bootbox.confirm({
                title: '{{get_string('confirm_action')}}',
                message: '{{get_string('delete_confirm')}}',
                onEscape: true,
                backdrop: true,
                buttons: {
                    cancel: {
                        label: '{{get_string('no')}}',
                        className: 'btn waves-effect'
                    },
                    confirm: {
                        label: '{{get_string('yes')}}',
                        className: 'btn waves-effect'
                    }
                },
                callback: function (result) {
                    if(result){
                        $.ajax({
                            url: '{{ url('/company/request/delete') }}/'+id,
                            type: 'post',
                            data: {_token :token, type: 0},
                            success:function(msg) {
                                selector.remove();
                                toastr.success(msg);
                            },
                            error:function(msg){
                                toastr.error(msg.responseJSON);
                            }
                        });
                    }
                }
            });
        });


    });
</script>
@endsection