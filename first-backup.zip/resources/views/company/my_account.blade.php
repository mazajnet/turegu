@extends('layouts.company')

@section('title')
    <title>{{get_string('my_account') . ' - ' . get_setting('site_name', 'site')}}</title>
@endsection

@section('content')
@section('page_title')
    <h3 class="page-title mbot10">{{get_string('my_account')}}</h3>
@endsection
@if(Session::has('account_updated'))
    <div class="col s12">
        <div class="col s12 text-centered">
            <h5 class="color-primary">{{ get_string('account_updated') }}</h5>
        </div>
    </div>
@endif
<div class="col s12 mtop10">
    {!! Form::open(['method' => 'put', 'url' => route('company_my_account_update', Auth::user()->id), 'files' => 'true']) !!}
    <div class="col m6 s6">
        <div class="form-group {{$errors->has('username') ? 'has-error' : ''}}">
            {!! Form::text('username', $user->username, ['id' => 'username', 'class' => 'form-control', 'placeholder' => get_string('username')]) !!}
            {!! Form::label('username', get_string('username'))!!}
            @if($errors->has('username'))
                <span class="wrong-error">* {{$errors->first('username')}}</span>
            @endif
        </div>
    </div>
    <div class="col m6 s6">
        <div class="form-group {{$errors->has('email') ? 'has-error' : ''}}">
            {!! Form::email('email', $user->email, ['id' => 'email', 'class' => 'form-control', 'placeholder' => get_string('email_address')]) !!}
            {!! Form::label('email', get_string('email_address'))!!}
            @if($errors->has('email'))
                <span class="wrong-error">* {{$errors->first('email')}}</span>
            @endif
        </div>
    </div>
    <div class="col m6 s6 clearfix">
        <div class="form-group {{$errors->has('password') ? 'has-error' : ''}}">
            {!! Form::password('password', ['id' => 'password', 'class' => 'form-control', 'placeholder' => get_string('password')]) !!}
            {!! Form::label('password', get_string('password'))!!}
            @if($errors->has('password'))
                <span class="wrong-error">* {{$errors->first('password')}}</span>
            @endif
        </div>
    </div>
    <div class="col m6 s6">
        <div class="form-group {{$errors->has('password') ? 'has-error' : ''}}">
            {!! Form::password('password_confirmation', ['id' => 'password_confirmation', 'class' => 'form-control', 'placeholder' => get_string('password_confirmation')]) !!}
            {!! Form::label('password_confirmation', get_string('password_confirmation'))!!}
            @if($errors->has('password'))
                <span class="wrong-error">* {{$errors->first('password')}}</span>
            @endif
        </div>
    </div>



    <div class="col s12"><h3 class="page-title mtop20">{{ get_string('company') }}</h3></div>
    


    <div class="col m6 s6">
        <div class="form-group {{$errors->has('company') ? 'has-error' : ''}}">
            {!! Form::text('company', $user->company->company, ['id' => 'company', 'class' => 'form-control', 'placeholder' => get_string('company')]) !!}
            {!! Form::label('company', get_string('company'))!!}
            @if($errors->has('company'))
                <span class="wrong-error">* {{$errors->first('company')}}</span>
            @endif
        </div>
    </div>
    <div class="col m6 s12">
        <div class="form-group {{$errors->has('website') ? 'has-error' : ''}}">
            {!! Form::text('website', $user->company->website, ['class' => 'form-control', 'required', 'placeholder' => get_string('website')]) !!}
            {!! Form::label('website', get_string('website'))!!}
            @if($errors->has('website'))
                <span class="wrong-error">* {{$errors->first('website')}}</span>
            @endif
        </div>
    </div>
    <div class="col m6 s12">
        <div class="form-group {{$errors->has('contact_email') ? 'has-error' : ''}}">
            {!! Form::email('contact_email', $user->company->email, ['class' => 'form-control', 'required', 'placeholder' => get_string('contact') .' '. get_string('email_address')]) !!}
            {!! Form::label('contact_email', get_string('contact') .' '. get_string('email_address'))!!}
            @if($errors->has('contact_email'))
                <span class="wrong-error">* {{$errors->first('contact_email')}}</span>
            @endif
        </div>
    </div>
    <div class="col m6 s12">
        <div class="form-group {{$errors->has('contact_phone') ? 'has-error' : ''}}">
            {!! Form::text('contact_phone', $user->company->phone, ['id' => 'phone', 'class' => 'form-control', 'required', 'placeholder' => get_string('contact') .' '. get_string('phone')]) !!}
            {!! Form::label('contact_phone', get_string('contact') .' '. get_string('phone'))!!}
            @if($errors->has('contact_phone'))
                <span class="wrong-error">* {{$errors->first('contact_phone')}}</span>
            @endif
        </div>
    </div>
    
    <div class="row">
    <div class="col m6 s12">
        <div class="col s12">
            <div class="form-group {{$errors->has('location.address') ? 'has-error' : ''}}">
                {!! Form::text('location[address]', $user->company->location['address'], ['class' => 'form-control', 'required', 'placeholder' => get_string('address')]) !!}
                {!! Form::label('location[address]', get_string('address'))!!}
                @if($errors->has('location.address'))
                    <span class="wrong-error">* {{$errors->first('location.address')}}</span>
                @endif
            </div>
        </div>
        <div class="col s12">
            <div class="form-group {{$errors->has('location.city') ? 'has-error' : ''}}">
                {!! Form::text('location[city]', $user->company->location['city'], ['class' => 'form-control', 'required','placeholder' => get_string('city')]) !!}
                {!! Form::label('location[city]', get_string('city'))!!}
                @if($errors->has('location.city'))
                    <span class="wrong-error">* {{$errors->first('location.city')}}</span>
                @endif
            </div>
        </div>
        <div class="col s12">
            <div class="form-group {{$errors->has('location.town') ? 'has-error' : ''}}">
                {!! Form::text('location[town]', $user->company->location['town'], ['class' => 'form-control', 'required','placeholder' => get_string('town')]) !!}
                {!! Form::label('location[town]', get_string('town'))!!}
                @if($errors->has('location.town'))
                    <span class="wrong-error">* {{$errors->first('location.town')}}</span>
                @endif
            </div>
        </div>
        <div class="col s12">
            <div class="form-group {{$errors->has('location.zip') ? 'has-error' : ''}}">
                {!! Form::text('location[zip]', $user->company->location['zip'], ['class' => 'form-control', 'required','placeholder' => get_string('zip')]) !!}
                {!! Form::label('location[zip]', get_string('zip'))!!}
                @if($errors->has('location.zip'))
                    <span class="wrong-error">* {{$errors->first('location.zip')}}</span>
                @endif
            </div>
        </div>
        <div class="col m6 s12">
            <div class="form-group {{$errors->has('location.geo_lat') ? 'has-error' : ''}}">
                {!! Form::text('location[geo_lat]', $user->company->location['geo_lat'], ['class' => 'form-control', 'required','placeholder' => get_string('geo_lat')]) !!}
                {!! Form::label('location[geo_lat]', get_string('geo_lat'))!!}
                @if($errors->has('location.geo_lat'))
                    <span class="wrong-error">* {{$errors->first('location.geo_lat')}}</span>
                @endif
            </div>
        </div>
        <div class="col m6 s12">
            <div class="form-group {{$errors->has('location.geo_lon') ? 'has-error' : ''}}">
                {!! Form::text('location[geo_lon]', $user->company->location['geo_lon'], ['class' => 'form-control', 'required','placeholder' => get_string('geo_lon')]) !!}
                {!! Form::label('location[geo_lon]', get_string('geo_lon'))!!}
                @if($errors->has('location.geo_lon'))
                    <span class="wrong-error">* {{$errors->first('location.geo_lon')}}</span>
                @endif
            </div>
        </div>

    </div>
    <div class="col m6 s12">
        <div id="google-map"></div>
    </div>
    </div>

    <div class="col s12">
        <div class="input-group">
            <label class="input-group-btn">
                    <span class="btn btn-primary waves-effect">{{get_string('company_logo')}} <i class="material-icons small">add_circle</i>
                    {!! Form::file('avatar', ['id' => 'avatar', 'class' => 'hidden']) !!}
                    </span>
            </label>
            <input type="text" class="form-control" readonly>
        </div>
        @if($errors->has('logo'))
            <span class="wrong-error">* {{$errors->first('logo')}}</span>
        @endif
    </div>
    <div class="col clearfix l4 m4 s6 mtop20">
        <div class="form-group">
            <button class="btn waves-effect" type="submit" name="action">{{get_string('update_profile')}}</button>
        </div>
    </div>
    {!! Form::close() !!}
</div>
@endsection
@section('footer')
<script src="https://maps.googleapis.com/maps/api/js?key={{get_setting('google_map_key', 'site')}}&libraries=places"></script>

<script>
    // Google Map
    $(document).ready(function() {
        if(typeof google !== 'undefined' && google){
            var map = new google.maps.Map(document.getElementById('google-map'), {
                center:{
                    lat: {{ $user->company->location['geo_lat'] }}, 
                    lng: {{ $user->company->location['geo_lon'] }}
                },
                zoom:4
            });
            var marker = new google.maps.Marker({
                position: {
                    lat: {{ $user->company->location['geo_lat'] }},
                    lng: {{ $user->company->location['geo_lon'] }}
                },
                map: map,
                draggable: true
            });
            var infowindow = new google.maps.InfoWindow();
            var searchBox = document.getElementById('address-map');
            var autocomplete = new google.maps.places.Autocomplete(searchBox);

            autocomplete.bindTo('bounds', map);
            autocomplete.addListener('place_changed', function() {
                infowindow.close();
                marker.setVisible(false);
                var place = autocomplete.getPlace();
                if (!place.geometry) {
                    return;
                }

                // If the place has a geometry, then present it on a map.
                if (place.geometry.viewport) {
                    map.fitBounds(place.geometry.viewport);
                } else {
                    map.setCenter(place.geometry.location);
                    map.setZoom(15);
                }

                marker.setPosition(place.geometry.location);
                marker.setVisible(true);

                var address = '';
                if (place.address_components) {
                    address = [
                        (place.address_components[0] && place.address_components[0].short_name || ''),
                        (place.address_components[1] && place.address_components[1].short_name || ''),
                        (place.address_components[2] && place.address_components[2].short_name || '')
                    ].join(' ');
                }

                infowindow.setContent('<div><strong>' + place.name + '</strong><br>' + address);
                infowindow.open(map, marker);
            });

            google.maps.event.addListener(marker, 'position_changed', function () {
                var lat = marker.getPosition().lat();
                var lng = marker.getPosition().lng();
                $('[name="location[geo_lat]"]').val(lat);
                $('[name="location[geo_lon]"]').val(lng);
            });
        }
    });
</script>

@endsection
