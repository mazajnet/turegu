@if($projects->count())
    @foreach($projects as $project)
        <div class="col-md-6 col-sm-6 items-grid">
            <div class="item box-shadow">
                <div id="carousel--{{$project->id}}" class="main-image bg-overlay carousel slide" data-ride="carousel" data-interval="false">
                    @if(count($project->images))
                        <div class="carousel-inner" role="listbox">
                            <?php $c = 0; ?>
                            @foreach($project->images as $image)
                                <div class="carousel-item @if(!$c) active <?php $c++; ?> @endif">
                                    <img class="responsive-img" src="{{ URL::asset('images/data').'/'.$image->image }}"/>
                                </div>
                            @endforeach
                        </div>
                        <a class="carousel-control-prev" href="#carousel--{{$project->id}}" role="button" data-slide="prev">
                            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                            <span class="sr-only">{{$static_data['strings']['previous']}}</span>
                        </a>
                        <a class="carousel-control-next" href="#carousel--{{$project->id}}" role="button" data-slide="next">
                            <span class="carousel-control-next-icon" aria-hidden="true"></span>
                            <span class="sr-only">{{$static_data['strings']['next']}}</span>
                        </a>
                    @else
                        <div class="carousel-inner" role="listbox">
                            <div class="carousel-item active">
                                <img class="responsive-img" src="{{ URL::asset('images/').'/no_image.jpg' }}"/>
                            </div>
                        </div>
                    @endif
                </div>
                <div class="data">
                    <a href="{{url('/project').'/'.$project->alias}}"><h3 class="item-title primary-color">{{ $project->contentload->name }}</h3></a>
                    <div class="item-category">{{$project->location['address'].', '.$project->location['city'] .' - '. $project->location['country']}}</div>
                    <div class="item-category">{{$project->category->contentload->name.' - '.$project->ser_location->contentload->location}}</div>
                    @if($project->user)<div class="small-text">{{ $static_data['strings']['posted_by'] .': '. $project->user->username }}</div>@endif
                </div>
            </div>
        </div>
    @endforeach
@endif
@if($markers)
    <script type="text/javascript">
        var markers = [@foreach ($markers as $marker)[{{$marker['geo_lon']}}, {{$marker['geo_lat']}}], @endforeach],
                infoWindowContent = [@foreach ($projects as $project)[{"id" : "{{$project->id}}","alias":"{{ $project->alias }}","name":{!! json_encode($project->contentload->name) !!},"address":"{{ $project->location['address'] }}" ,"city":"{{ $project->location['city'] }}" ,"country":"{{ $project->location['country'] }}" ,"phone":"{{ $project->contact['tel1'] }}", "icon":"{{ $project->category->map_icon }}", "featured":"{{ $project->featured }}", "image":@if(count($project->images))"{{ $project->images[0]->image }}" @else "no_image.jpg" @endif}], @endforeach];
        for(i = 0; i < markers.length; i++ ) {
            addMarkerToMap(markers[i][0], markers[i][1], infoWindowContent[i], 'project');
        }
    </script>
@endif