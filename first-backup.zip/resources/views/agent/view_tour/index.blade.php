@extends('layouts.agent')

@section('title')
    <title>{{get_string('view_tours') . ' - ' . get_setting('site_name', 'site')}}</title>
@endsection
@section('content')
@section('page_title')
    <h3 class="page-title mbot10">{{get_string('view_tours')}}</h3>
@endsection
    <div class="col s12">
        @if($viewTours->count())
        <div class="table-responsive">
        <table class="table bordered striped">
            <thead class="thead-inverse">
            <tr>
                <th>
                    <input type="checkbox" class="filled-in primary-color" id="select-all" />
                    <label for="select-all"></label>
                </th>
                <th>{{get_string('agent')}}</th>
                <th>{{get_string('date')}}</th>
                <th>{{get_string('number_of_properties')}}</th>
                <th>{{get_string('number_of_days')}}</th>
                <th>{{get_string('price')}}</th>
            </tr>
            </thead>
            <tbody>
                @foreach($viewTours as $viewTour)
                    <tr>
                        <td>
                            <input type="checkbox" class="filled-in primary-color" id="{{$viewTour->id}}" />
                            <label for="{{$viewTour->id}}"></label>
                        </td>
                        <td>@if($viewTour->agent) {{$viewTour->agent->username}}  @else <i class="small material-icons color-red">clear</i> @endif</td>
                        <td>{{ $viewTour->start_date .' - '. $viewTour->end_date }}</td>
                        <td>{{ $viewTour->number_of_properties }} </td>
                        <td>{{ $viewTour->number_of_days }} </td>
                        <td>{{ get_setting('currency', 'site') }}{{ $viewTour->price }} </td>
                    </tr>
                @endforeach
            </tbody>
        </table>
        </div>
        {{$viewTours->links()}}
        @else
            <strong class="center-align">{{get_string('no_results')}}</strong>
        @endif
    </div>
@endsection