@extends('layouts.agent')

@section('title')
    <title>{{get_string('my_account') . ' - ' . get_setting('site_name', 'site')}}</title>
@endsection

@section('content')
@section('page_title')
    <h3 class="page-title mbot10">{{get_string('my_account')}}</h3>
@endsection
@if(Session::has('account_updated'))
    <div class="col s12">
        <div class="col s12 text-centered">
            <h5 class="color-primary">{{ get_string('account_updated') }}</h5>
        </div>
    </div>
@endif
<div class="col s12 mtop10">
    {!! Form::open(['method' => 'put', 'url' => route('agent_my_account_update', Auth::user()->id), 'files' => 'true']) !!}
    <div class="col m6 s6">
        <div class="form-group {{$errors->has('username') ? 'has-error' : ''}}">
            {!! Form::text('username', $user->username, ['id' => 'username', 'class' => 'form-control', 'placeholder' => get_string('username')]) !!}
            {!! Form::label('username', get_string('username'))!!}
            @if($errors->has('username'))
                <span class="wrong-error">* {{$errors->first('username')}}</span>
            @endif
        </div>
    </div>
    <div class="col m6 s6">
        <div class="form-group {{$errors->has('email') ? 'has-error' : ''}}">
            {!! Form::email('email', $user->email, ['id' => 'email', 'class' => 'form-control', 'placeholder' => get_string('email_address')]) !!}
            {!! Form::label('email', get_string('email_address'))!!}
            @if($errors->has('email'))
                <span class="wrong-error">* {{$errors->first('email')}}</span>
            @endif
        </div>
    </div>
    <div class="col m6 s6 clearfix">
        <div class="form-group {{$errors->has('password') ? 'has-error' : ''}}">
            {!! Form::password('password', ['id' => 'password', 'class' => 'form-control', 'placeholder' => get_string('password')]) !!}
            {!! Form::label('password', get_string('password'))!!}
            @if($errors->has('password'))
                <span class="wrong-error">* {{$errors->first('password')}}</span>
            @endif
        </div>
    </div>
    <div class="col m6 s6">
        <div class="form-group {{$errors->has('password') ? 'has-error' : ''}}">
            {!! Form::password('password_confirmation', ['id' => 'password_confirmation', 'class' => 'form-control', 'placeholder' => get_string('password_confirmation')]) !!}
            {!! Form::label('password_confirmation', get_string('password_confirmation'))!!}
            @if($errors->has('password'))
                <span class="wrong-error">* {{$errors->first('password')}}</span>
            @endif
        </div>
    </div>



    <div class="col s12"><h3 class="page-title mtop20">{{ get_string('agent') }}</h3></div>
    

    <div class="col m6 s12">
        <div class="form-group {{$errors->has('first_name') ? 'has-error' : ''}}">
            {!! Form::text('first_name', $user->agent->first_name, ['id' => 'first_name', 'readonly', 'class' => 'form-control', 'placeholder' => get_string('first_name')]) !!}
            {!! Form::label('first_name', get_string('first_name'))!!}
            @if($errors->has('first_name'))
                <span class="wrong-error">* {{$errors->first('first_name')}}</span>
            @endif
        </div>
    </div><div class="col m6 s12">
        <div class="form-group {{$errors->has('last_name') ? 'has-error' : ''}}">
            {!! Form::text('last_name', $user->agent->last_name, ['id' => 'last_name', 'readonly', 'class' => 'form-control', 'placeholder' => get_string('last_name')]) !!}
            {!! Form::label('last_name', get_string('last_name'))!!}
            @if($errors->has('last_name'))
                <span class="wrong-error">* {{$errors->first('last_name')}}</span>
            @endif
        </div>
    </div>
    <div class="col m6 s12">
        <div class="form-group {{$errors->has('position') ? 'has-error' : ''}}">
            {!! Form::text('position', $user->agent->position, ['id' => 'position', 'readonly', 'class' => 'form-control', 'placeholder' => get_string('position')]) !!}
            {!! Form::label('position', get_string('position'))!!}
            @if($errors->has('position'))
                <span class="wrong-error">* {{$errors->first('position')}}</span>
            @endif
        </div>
    </div>
    <div class="col m6 s12">
        <div class="form-group {{$errors->has('languages') ? 'has-error' : ''}}">
            {!! Form::text('languages', $user->agent->languages, ['class' => 'form-control', 'required', 'placeholder' => get_string('languages')]) !!}
            {!! Form::label('languages', get_string('languages'))!!}
            @if($errors->has('languages'))
                <span class="wrong-error">* {{$errors->first('languages')}}</span>
            @endif
        </div>
    </div>
    <div class="col m6 s12">
        <div class="form-group {{$errors->has('contact_email') ? 'has-error' : ''}}">
            {!! Form::email('contact_email', $user->agent->email, ['class' => 'form-control', 'required', 'placeholder' => get_string('contact') .' '. get_string('email_address')]) !!}
            {!! Form::label('contact_email', get_string('contact') .' '. get_string('email_address'))!!}
            @if($errors->has('contact_email'))
                <span class="wrong-error">* {{$errors->first('contact_email')}}</span>
            @endif
        </div>
    </div>
    <div class="col m6 s12">
        <div class="form-group {{$errors->has('contact_phone') ? 'has-error' : ''}}">
            {!! Form::text('contact_phone', $user->agent->phone, ['id' => 'phone', 'class' => 'form-control', 'required', 'placeholder' => get_string('contact') .' '. get_string('phone')]) !!}
            {!! Form::label('contact_phone', get_string('contact') .' '. get_string('phone'))!!}
            @if($errors->has('contact_phone'))
                <span class="wrong-error">* {{$errors->first('contact_phone')}}</span>
            @endif
        </div>
    </div>
    <div class="col s12">
        <div class="input-group">
            <label class="input-group-btn">
                    <span class="btn btn-primary waves-effect">{{get_string('agent_logo')}} <i class="material-icons small">add_circle</i>
                    {!! Form::file('avatar', ['id' => 'avatar', 'class' => 'hidden']) !!}
                    </span>
            </label>
            <input type="text" class="form-control" readonly>
        </div>
        @if($errors->has('logo'))
            <span class="wrong-error">* {{$errors->first('logo')}}</span>
        @endif
    </div>
    <div class="col clearfix l4 m4 s6 mtop20">
        <div class="form-group">
            <button class="btn waves-effect" type="submit" name="action">{{get_string('update_profile')}}</button>
        </div>
    </div>
    {!! Form::close() !!}
</div>
@endsection
