@extends('layouts.admin')

@section('title')
    <title>{{get_string('payment_settings') . ' - ' . get_setting('site_name', 'site')}}</title>
@endsection

@section('content')
@section('page_title')
    <h3 class="page-title mbot10">{{get_string('payment_settings')}}</h3>
@endsection
<div class="panel col s12">
    <div class="row">
        <div class="panel-heading">
            <ul class="nav nav-tabs">
                <li class="tab active"><a data-toggle="tab" href="#general_settings">{{get_string('general_and_packages')}}</a></li>
            </ul>
        </div>
        {!! Form::open(['url' => route('admin_payment_settings_update'), 'method' => 'post', 'id' => "payment_settings", 'class' => 'table-responsive', 'files' => 'true']) !!}
        <div class="panel-body">
            <div class="tab-content">
                <div id="general_settings" class="tab-pane active">
                    <div class="col l6 m6 s12">
                        <div class="form-group  {{$errors->has('show_price_menu') ? 'has-error' : ''}}">
                            {{Form::select('show_price_menu', ['0' => get_string('no'), '1' => get_string('yes')], get_setting('show_price_menu', 'payment'), ['class' => 'form-control'])}}
                            {{Form::label('show_price_menu', get_string('show_price_menu'))}}
                            @if($errors->has('show_price_menu'))
                                <span class="wrong-error">* {{$errors->first('show_price_menu')}}</span>
                            @endif
                        </div>
                    </div>
                    <div class="col l6 m6 s12">
                        <div class="form-group  {{$errors->has('show_add_points_menu') ? 'has-error' : ''}}">
                            {{Form::select('show_add_points_menu', ['0' => get_string('no'), '1' => get_string('yes')], get_setting('show_add_points_menu', 'payment'), ['class' => 'form-control'])}}
                            {{Form::label('show_add_points_menu', get_string('show_add_points_menu'))}}
                            @if($errors->has('show_add_points_menu'))
                                <span class="wrong-error">* {{$errors->first('show_add_points_menu')}}</span>
                            @endif
                        </div>
                    </div>
                    <div class="col s12">
                        <h3 class="page-title clearfix">{{ get_string('packages') }} ({{ $currency }})</h3>
                    </div>
                    <div class="col l6 m6 s12">
                        <div class="form-group  {{$errors->has('package_10') ? 'has-error' : ''}}">
                            {{Form::number('package_10', get_setting('package_10', 'payment'), ['class' => 'form-control', 'min' => 0, 'placeholder' => '10 '.get_string('points')])}}
                            {{Form::label('package_10', '10 '.get_string('points'))}}
                            @if($errors->has('package_10'))
                                <span class="wrong-error">* {{$errors->first('package_10')}}</span>
                            @endif
                        </div>
                    </div>
                    <div class="col l6 m6 s12">
                        <div class="form-group  {{$errors->has('package_30') ? 'has-error' : ''}}">
                            {{Form::number('package_30', get_setting('package_30', 'payment'), ['class' => 'form-control', 'min' => 0, 'placeholder' => '30 '.get_string('points')])}}
                            {{Form::label('package_30', '30 '.get_string('points'))}}
                            @if($errors->has('package_30'))
                                <span class="wrong-error">* {{$errors->first('package_30')}}</span>
                            @endif
                        </div>
                    </div>
                    <div class="col l6 m6 s12">
                        <div class="form-group  {{$errors->has('package_50') ? 'has-error' : ''}}">
                            {{Form::number('package_50', get_setting('package_50', 'payment'), ['class' => 'form-control', 'min' => 0, 'placeholder' => '50 '.get_string('points')])}}
                            {{Form::label('package_50', '50 '.get_string('points'))}}
                            @if($errors->has('package_50'))
                                <span class="wrong-error">* {{$errors->first('package_50')}}</span>
                            @endif
                        </div>
                    </div>
                    <div class="col l6 m6 s12">
                        <div class="form-group  {{$errors->has('package_100') ? 'has-error' : ''}}">
                            {{Form::number('package_100', get_setting('package_100', 'payment'), ['class' => 'form-control', 'min' => 0, 'placeholder' => '100 '.get_string('points')])}}
                            {{Form::label('package_100', '100 '.get_string('points'))}}
                            @if($errors->has('package_100'))
                                <span class="wrong-error">* {{$errors->first('package_100')}}</span>
                            @endif
                        </div>
                    </div>
                    <div class="col l6 m6 s12">
                        <div class="form-group  {{$errors->has('package_200') ? 'has-error' : ''}}">
                            {{Form::number('package_200', get_setting('package_200', 'payment'), ['class' => 'form-control', 'min' => 0, 'placeholder' => '200 '.get_string('points')])}}
                            {{Form::label('package_200', '200 '.get_string('points'))}}
                            @if($errors->has('package_200'))
                                <span class="wrong-error">* {{$errors->first('package_200')}}</span>
                            @endif
                        </div>
                    </div>
                    <div class="col s12">
                        <h3 class="page-title clearfix">{{ get_string('featured_items') }} ({{ get_string('points') }})</h3>
                    </div>
                    <div class="col l6 m6 s12">
                        <div class="form-group  {{$errors->has('points_featured_week') ? 'has-error' : ''}}">
                            {{Form::number('points_featured_week', get_setting('points_featured_week', 'payment'), ['class' => 'form-control', 'min' => 0, 'placeholder' => get_string('week_featured')])}}
                            {{Form::label('points_featured_week', get_string('week_featured'))}}
                            @if($errors->has('points_featured_week'))
                                <span class="wrong-error">* {{$errors->first('points_featured_week')}}</span>
                            @endif
                        </div>
                    </div>
                    <div class="col l6 m6 s12">
                        <div class="form-group  {{$errors->has('points_featured_month') ? 'has-error' : ''}}">
                            {{Form::number('points_featured_month', get_setting('points_featured_month', 'payment'), ['class' => 'form-control', 'min' => 0, 'placeholder' => get_string('month_featured')])}}
                            {{Form::label('points_featured_month', get_string('month_featured'))}}
                            @if($errors->has('points_featured_month'))
                                <span class="wrong-error">* {{$errors->first('points_featured_month')}}</span>
                            @endif
                        </div>
                    </div>
                    <div class="col l6 m6 s12">
                        <div class="form-group  {{$errors->has('points_featured_3months') ? 'has-error' : ''}}">
                            {{Form::number('points_featured_3months', get_setting('points_featured_3months', 'payment'), ['class' => 'form-control', 'min' => 0, 'placeholder' => get_string('3months_featured')])}}
                            {{Form::label('points_featured_3months', get_string('3months_featured'))}}
                            @if($errors->has('points_featured_3months'))
                                <span class="wrong-error">* {{$errors->first('points_featured_month')}}</span>
                            @endif
                        </div>
                    </div>
                </div>
            </div>
            <div class="col clearfix l4 m4 s12 mtop10">
                <div class="form-group">
                    <button class="btn waves-effect" type="submit" name="action">{{get_string('update')}}</button></div>
                </div>
            </div>
        {!! Form::close() !!}
        </div>
    </div>
</div>
@endsection
