@extends('layouts.admin')

@section('title')
    <title>{{get_string('memberships') . ' - ' . get_setting('site_name', 'site')}}</title>
@endsection

@section('content')
@section('page_title')
    <h3 class="page-title mbot10">{{get_string('memberships')}}</h3>
@endsection
<div class="panel col s12">
    <div class="row">
        <div class="panel-heading">
            <ul class="nav nav-tabs">
                <li class="tab active"><a data-toggle="tab" href="#general_settings">{{get_string('memberships')}}</a></li>
            </ul>
        </div>
        {!! Form::open(['url' => route('admin_memberships_update'), 'method' => 'post', 'id' => "memberships", 'class' => 'table-responsive']) !!}
        <div class="panel-body">
            <div class="tab-content">
                <div id="general_settings" class="tab-pane active">

                    
                    @foreach($memberships as $membership)
                    <div class="col s12">
                        <h3 class="page-title clearfix">{{ get_string('membership') }} - {{ get_string($membership->key) }}</h3>
                    </div>
                    <div class="col m4 s12">
                        <div class="form-group">
                            {{Form::number($membership->id.'[monthly]', $membership->monthly, ['class' => 'form-control', 'required', 'min' => 0, 'placeholder' => get_string('monthly').' - '.get_string('points')])}}
                            {{Form::label('monthly', get_string('monthly').' - '.get_string('points'))}}
                        </div>
                    </div>
                    <div class="col m4 s12">
                        <div class="form-group">
                            {{Form::number($membership->id.'[agents]', $membership->agents, ['class' => 'form-control', 'required', 'min' => 0, 'placeholder' => get_string('agents')])}}
                            {{Form::label('agents', get_string('agents'))}}
                        </div>
                    </div>
                    <div class="col m4 s12">
                        <div class="form-group ">
                            {{Form::number($membership->id.'[listings]', $membership->listings, ['class' => 'form-control', 'required', 'min' => 0, 'placeholder' => get_string('listings')])}}
                            {{Form::label('listings', get_string('listings'))}}
                        </div>
                    </div>
                    <div class="col m4 s12">
                        <div class="form-group ">
                            {{Form::number($membership->id.'[listing_duration]', $membership->listing_duration, ['class' => 'form-control', 'required', 'min' => 0, 'placeholder' => get_string('listing_duration').' - '.get_string('months')])}}
                            {{Form::label('listing_duration', get_string('listing_duration').' - '.get_string('months'))}}
                        </div>
                    </div>
                    <div class="col m4 s12">
                        <div class="form-group ">
                            {{Form::select($membership->id.'[projects]', [0 => get_string('no'), 1 => get_string('yes')], $membership->projects, ['class' => 'form-control', 'required', 'placeholder' => get_string('projects')])}}
                            {{Form::label('projects', get_string('projects'))}}
                        </div>
                    </div>
                    <div class="col m4 s12">
                        <div class="form-group ">
                            {{Form::select($membership->id.'[private_tour]', [0 => get_string('no'), 1 => get_string('yes')], $membership->private_tour, ['class' => 'form-control', 'required', 'placeholder' => get_string('private_tour')])}}
                            {{Form::label('private_tour', get_string('private_tour'))}}
                        </div>
                    </div>
                    <div class="col m4 s12">
                        <div class="form-group ">
                            {{Form::select($membership->id.'[view_tour]', [0 => get_string('no'), 1 => get_string('yes')], $membership->view_tour, ['class' => 'form-control', 'required', 'placeholder' => get_string('view_tour')])}}
                            {{Form::label('view_tour', get_string('view_tour'))}}
                        </div>
                    </div>
                    <div class="col m4 s12">
                        <div class="form-group ">
                            {{Form::select($membership->id.'[property_request]', [0 => get_string('no'), 1 => get_string('yes')], $membership->property_request, ['class' => 'form-control', 'required', 'placeholder' => get_string('property_requests')])}}
                            {{Form::label('property_requests', get_string('property_requests'))}}
                        </div>
                    </div>
                    <div class="col m4 s12">
                        <div class="form-group ">
                            {{Form::select($membership->id.'[search_company]', [0 => get_string('no'), 1 => get_string('yes')], $membership->search_company, ['class' => 'form-control', 'required', 'placeholder' => get_string('search_company')])}}
                            {{Form::label('search_company', get_string('search_company'))}}
                        </div>
                    </div>
                    <div class="col m4 s12">
                        <div class="form-group ">
                            {{Form::select($membership->id.'[home_logo]', [0 => get_string('no'), 1 => get_string('yes')], $membership->home_logo, ['class' => 'form-control', 'required', 'placeholder' => get_string('home_logo')])}}
                            {{Form::label('home_logo', get_string('home_logo'))}}
                        </div>
                    </div>
                    @endforeach

                </div>
            </div>
            <div class="col clearfix l4 m4 s12 mtop10">
                <div class="form-group">
                    <button class="btn waves-effect" type="submit" name="action">{{get_string('update')}}</button></div>
                </div>
            </div>
        {!! Form::close() !!}
        </div>
    </div>
</div>
@endsection
