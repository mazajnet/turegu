@extends('layouts.admin')

@section('title')
    <title>{{get_string('packages') . ' - ' . get_setting('site_name', 'site')}}</title>
@endsection

@section('content')
@section('page_title')
    <h3 class="page-title mbot10">{{get_string('packages')}}</h3>
@endsection
<div class="panel col s12">
    <div class="row">
        <div class="panel-heading">
            <ul class="nav nav-tabs">
                <li class="tab active"><a data-toggle="tab" href="#general_settings">{{get_string('packages')}}</a></li>
            </ul>
        </div>
        {!! Form::open(['url' => route('admin_packages_update'), 'method' => 'post', 'id' => "packages", 'class' => 'table-responsive']) !!}
        <div class="panel-body">
            <div class="tab-content">
                <div id="general_settings" class="tab-pane active">

                    
                    @foreach($packages as $package)
                    <div class="col s12">
                        <h3 class="page-title clearfix">{{ get_string('package') }} - #{{ $package->id }}</h3>
                    </div>
                    <div class="col m4 s12">
                        <div class="form-group  {{$errors->has('points') ? 'has-error' : ''}}">
                            {{Form::number($package->id.'[points]', $package->points, ['class' => 'form-control', 'required', 'min' => 0, 'placeholder' => get_string('points')])}}
                            {{Form::label('points', get_string('points'))}}
                            @if($errors->has('points'))
                                <span class="wrong-error">* {{$errors->first('points')}}</span>
                            @endif
                        </div>
                    </div>
                    <div class="col m4 s12">
                        <div class="form-group  {{$errors->has('cost') ? 'has-error' : ''}}">
                            {{Form::number($package->id.'[cost]', $package->cost, ['class' => 'form-control', 'required', 'min' => 0, 'placeholder' => get_string('cost').' - '.get_setting('currency', 'site')])}}
                            {{Form::label('cost', get_string('cost').' - '.get_setting('currency', 'site'))}}
                            @if($errors->has('cost'))
                                <span class="wrong-error">* {{$errors->first('cost')}}</span>
                            @endif
                        </div>
                    </div>
                    <div class="col m4 s12">
                        <div class="form-group  {{$errors->has('bonus') ? 'has-error' : ''}}">
                            {{Form::number($package->id.'[bonus]', $package->bonus, ['class' => 'form-control', 'required', 'min' => 0, 'placeholder' => get_string('bonus').' '.get_string('points')])}}
                            {{Form::label('bonus', get_string('bonus').' '.get_string('points'))}}
                            @if($errors->has('bonus'))
                                <span class="wrong-error">* {{$errors->first('bonus')}}</span>
                            @endif
                        </div>
                    </div>
                    @endforeach

                </div>
            </div>
            <div class="col clearfix l4 m4 s12 mtop10">
                <div class="form-group">
                    <button class="btn waves-effect" type="submit" name="action">{{get_string('update')}}</button></div>
                </div>
            </div>
        {!! Form::close() !!}
        </div>
    </div>
</div>
@endsection
