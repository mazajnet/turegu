@extends('layouts.admin')

@section('title')
    <title>{{get_string('bannerType') . ' - ' . get_setting('site_name', 'site')}}</title>
@endsection

@section('content')
@section('page_title')
    <h3 class="page-title mbot10">{{get_string('bannerType')}}</h3>
@endsection
<div class="panel col s12">
    <div class="row">
        <div class="panel-heading">
            <ul class="nav nav-tabs">
                <li class="tab active"><a data-toggle="tab" href="#general_settings">{{get_string('bannerType')}}</a></li>
            </ul>
        </div>
        {!! Form::open(['url' => route('admin_bannerTypes_update'), 'method' => 'post', 'id' => "bannerType", 'class' => 'table-responsive']) !!}
        <div class="panel-body">
            <div class="tab-content">
                <div id="general_settings" class="tab-pane active">

                    
                    @foreach($bannerTypes as $bannerType)
                    <div class="col s12">
                        <h3 class="page-title clearfix">{{ get_string($bannerType->key) }}</h3>
                    </div>
                    <div class="col m3 s6">
                        <div class="form-group  {{$errors->has('weekly') ? 'has-error' : ''}}">
                            {{Form::number($bannerType->id.'[weekly]', $bannerType->weekly, ['class' => 'form-control', 'required', 'min' => 0, 'placeholder' => get_string('weekly').' - '.get_string('points')])}}
                            {{Form::label('weekly', get_string('weekly').' - '.get_string('points'))}}
                            @if($errors->has('weekly'))
                                <span class="wrong-error">* {{$errors->first('weekly')}}</span>
                            @endif
                        </div>
                    </div>
                    <div class="col m3 s6">
                        <div class="form-group  {{$errors->has('monthly') ? 'has-error' : ''}}">
                            {{Form::number($bannerType->id.'[monthly]', $bannerType->monthly, ['class' => 'form-control', 'required', 'min' => 0, 'placeholder' => get_string('monthly').' - '.get_string('points')])}}
                            {{Form::label('monthly', get_string('monthly').' - '.get_string('points'))}}
                            @if($errors->has('monthly'))
                                <span class="wrong-error">* {{$errors->first('monthly')}}</span>
                            @endif
                        </div>
                    </div>
                    <div class="col m3 s6">
                        <div class="form-group  {{$errors->has('yearly') ? 'has-error' : ''}}">
                            {{Form::number($bannerType->id.'[yearly]', $bannerType->yearly, ['class' => 'form-control', 'required', 'min' => 0, 'placeholder' => get_string('yearly').' - '.get_string('points')])}}
                            {{Form::label('yearly', get_string('yearly').' - '.get_string('points'))}}
                            @if($errors->has('yearly'))
                                <span class="wrong-error">* {{$errors->first('yearly')}}</span>
                            @endif
                        </div>
                    </div>
                    <div class="col m3 s6">
                        <div class="form-group  {{$errors->has('maximum') ? 'has-error' : ''}}">
                            {{Form::number($bannerType->id.'[maximum]', $bannerType->maximum, ['class' => 'form-control', 'required', 'min' => 0, 'placeholder' => get_string('maximum')])}}
                            {{Form::label('maximum', get_string('maximum'))}}
                            @if($errors->has('maximum'))
                                <span class="wrong-error">* {{$errors->first('maximum')}}</span>
                            @endif
                        </div>
                    </div>
                    @endforeach

                </div>
            </div>
            <div class="col clearfix l4 m4 s12 mtop10">
                <div class="form-group">
                    <button class="btn waves-effect" type="submit" name="action">{{get_string('update')}}</button></div>
                </div>
            </div>
        {!! Form::close() !!}
        </div>
    </div>
</div>
@endsection
