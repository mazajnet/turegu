@extends('layouts.admin')

@section('title')
<title>{{get_string('dashboard') . ' - ' . get_setting('site_name', 'site')}}</title>
@endsection

    @section('page_title')
        <h3 class="page-title mbot10">{{get_string('dashboard')}}</h3>
    @endsection
        @section('content')
            <div class="row mbot0">
                <div class="col s12">
                    <div class="col l3 m6 s12">
                        <div class="card">
                            <div class="card-content no-padding">
                                <div class="blue-card card-stats-body waves-effect">
                                    <div class="stats-icon right-align">
                                        <i class="medium material-icons">payment</i>
                                    </div>
                                    <div class="stats-text left-align">
                                        <strong class="counter">{{ $data['new_properties'] }}</strong><br>
                                        <span>{{get_string('new_listings')}}</span>
                                    </div>
                                </div>
                            </div><!--end .card-body -->
                        </div>
                    </div>
                    <div class="col l3 m6 s12">
                        <div class="card">
                            <div class="card-content no-padding">
                                <div class="blue-card card-stats-body waves-effect">
                                    <div class="stats-icon right-align">
                                        <i class="medium material-icons">thumb_up</i>
                                    </div>
                                    <div class="stats-text left-align">
                                        <strong class="counter">{{ $data['new_bookings'] }}</strong><br>
                                        <span>{{get_string('new_bookings')}}</span>
                                    </div>
                                </div>
                            </div><!--end .card-body -->
                        </div>
                    </div>
                    <div class="col l3 m6 s12">
                        <div class="card">
                            <div class="card-content no-padding">
                                <div class="blue-card card-stats-body waves-effect">
                                    <div class="stats-icon right-align">
                                        <i class="medium material-icons">supervisor_account</i>
                                    </div>
                                    <div class="stats-text left-align">
                                        <strong class="counter">{{ $data['new_members'] }}</strong><br>
                                        <span>{{get_string('new_members')}}</span>
                                    </div>
                                </div>
                            </div><!--end .card-body -->
                        </div>
                    </div>
                    <div class="col l3 m6 s12">
                        <div class="card">
                            <div class="card-content no-padding">
                                <div class="blue-card card-stats-body waves-effect">
                                    <div class="stats-icon right-align">
                                        <i class="medium material-icons">info_outline</i>
                                    </div>
                                    <div class="stats-text left-align">
                                        <strong class="counter">{{ $data['new_visits'] }}</strong><br>
                                        <span>{{get_string('visits_today')}}</span>
                                    </div>
                                </div>
                            </div><!--end .card-body -->
                        </div>
                    </div>
                </div>
            </div>
            <div class="col s12">
                <h3 class="page-title">{{get_string('latest_purchases')}}</h3>
                @if(count($purchases))
                    <div class="table-responsive">
                    <table id="latest-purchases" class="responsive-table bordered striped">
                        <thead class="thead-inverse">
                        <tr>
                            <th>#</th>
                            <th>{{get_string('user')}}</th>
                            <th>{{get_string('points_purchased')}}</th>
                            <th>{{get_string('price')}}</th>
                            <th>{{get_string('transaction')}}</th>
                            <th>{{get_string('date_of_purchase')}}</th>
                        </tr>
                        </thead>
                        <tbody>
                        @foreach($purchases as $purchase)
                            <tr>
                                <td>
                                    <input type="checkbox" class="filled-in primary-color" id="{{$purchase->id}}" />
                                    <label for="{{$purchase->id}}"></label>
                                </td>
                                <td>@if($purchase->user){{ $purchase->user->username }} @endif</td>
                                <td>{{ $purchase->points }}</td>
                                <td>{{ $purchase->price }} {{ $currency }}</td>
                                <td>{{ $purchase->transaction }}</td>
                                <td>{{ date(get_setting('dateformat', 'site'), strtotime($purchase->created_at)) }}</td>
                            </tr>
                        @endforeach
                        </tbody>
                    </table>
                    </div>
                @else
                    <strong class="center-align">{{get_string('no_results')}}</strong>
                @endif
            </div>
@endsection

@section('footer')
    <script src="{{URL::asset('assets/js/plugins/chart.min.js')}}"></script>
    <script>
        $(document).ready(function($) {
            $('.counter').counterUp({
                delay: 10,
                time: 1000
            });
        });
    </script>
@endsection
