@extends('layouts.admin')

@section('title')
    <title>{{get_string('ads') . ' - ' . get_setting('site_name', 'site')}}</title>
@endsection
@section('content')
@section('page_title')
    <h3 class="page-title mbot10">{{get_string('ads')}}</h3>
@endsection
<div class="col s12">
    @if($ads->count())
        <div class="table-responsive">
            <table class="table bordered striped">
                <thead class="thead-inverse">
                <tr>
                    <th>
                        <input type="checkbox" class="filled-in primary-color" id="select-all" />
                        <label for="select-all"></label>
                    </th>
                    <th>{{get_string('company')}}</th>
                    <th>{{get_string('adType')}}</th>
                    <th>{{get_string('property')}} / {{ get_string('project') }}</th>
                    <th>{{get_string('payment_method')}}</th>
                    <th>{{get_string('total')}}</th>
                    <th>{{get_string('start_date')}}</th>
                    <th>{{get_string('expires')}}</th>
                </tr>
                </thead>
                <tbody>
                @foreach($ads as $ad)
                    <tr class="{{ $ad->completed ? 'disabled-style' : '' }}">
                        <td>
                            <input type="checkbox" class="filled-in primary-color" id="{{$ad->id}}" />
                            <label for="{{$ad->id}}"></label>
                        </td>
                        <td>@if($ad->company){{ $ad->company->username }}@endif</td>
                        <td>{{ $ad->type ? get_string($ad->type->key) : ''}}</td>
                        <td>@if($ad->property_id && $ad->property) {{ $ad->property->contentDefault->name }} @elseif($ad->project_id && $ad->project) {{ $ad->project->contentDefault->name }} @else X @endif</td>
                        <td>{{ $ad->payment_method }}</td>
                        <td>{{ $ad->payment_method == 'Points' ? '' : get_setting('currency', 'site') }}{{ $ad->total }}</td>
                        <td>{{ $ad->created_at->format('Y-m-d') }}</td>
                        <td>{{ $ad->expiresAt }}</td>
                    </tr>
                @endforeach
                </tbody>
            </table>
        </div>
        {{$ads->links()}}
    @else
        <strong class="center-align">{{get_string('no_results')}}</strong>
    @endif
</div>
<input type="hidden" class="token" value="{{ csrf_token() }}">
@endsection