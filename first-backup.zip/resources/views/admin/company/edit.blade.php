@extends('layouts.admin')

@section('title')
    <title>{{get_string('edit_company') . ' - ' . get_setting('site_name', 'site')}}</title>
@endsection

@section('content')
@section('page_title')
    <h3 class="page-title mbot10">{{get_string('edit_company')}}</h3>
@endsection
<div class="col s12 mtop10">
    {!! Form::open(['method' => 'post', 'url' => route('admin_company_update', $owner->id), 'files' => 'true']) !!}
    {!! Form::hidden('user_id', $owner->user_id) !!}
    <div class="col l4 m4 s6">
        <div class="form-group {{$errors->has('username') ? 'has-error' : ''}}">
            {!! Form::text('username', $owner->user->username, ['id' => 'username', 'class' => 'form-control', 'placeholder' => get_string('username')]) !!}
            {!! Form::label('username', get_string('username'))!!}
            @if($errors->has('username'))
                <span class="wrong-error">* {{$errors->first('username')}}</span>
            @endif
        </div>
    </div>
    <div class="col l4 m4 s6">
        <div class="form-group {{$errors->has('email') ? 'has-error' : ''}}">
            {!! Form::email('email', $owner->user->email, ['id' => 'email', 'class' => 'form-control', 'placeholder' => get_string('email_address')]) !!}
            {!! Form::label('email', get_string('email_address'))!!}
            @if($errors->has('email'))
                <span class="wrong-error">* {{$errors->first('email')}}</span>
            @endif
        </div>
    </div>
    <div class="col l4 m4 s6">
        <div class="form-group {{$errors->has('points') ? 'has-error' : ''}}">
            {!! Form::text('points', $owner->points, ['id' => 'points', 'class' => 'form-control', 'placeholder' => get_string('points')]) !!}
            {!! Form::label('points', get_string('points'))!!}
            @if($errors->has('points'))
                <span class="wrong-error">* {{$errors->first('points')}}</span>
            @endif
        </div>
    </div>
    <div class="col l4 m4 s6">
        <div class="form-group {{$errors->has('membership_id') ? 'has-error' : ''}}">
            {!! Form::select('membership_id', $memberships, $owner->membership_id, ['id' => 'membership_id', 'class' => 'form-control', 'placeholder' => get_string('membership')]) !!}
            {!! Form::label('membership_id', get_string('membership'))!!}
            @if($errors->has('membership_id'))
                <span class="wrong-error">* {{$errors->first('membership_id')}}</span>
            @endif
        </div>
    </div>
    
    <div class="col l4 m4 s6">
        <div class="form-group {{$errors->has('password') ? 'has-error' : ''}}">
            {!! Form::password('password', ['id' => 'password', 'class' => 'form-control', 'placeholder' => get_string('password')]) !!}
            {!! Form::label('password', get_string('password'))!!}
            @if($errors->has('password'))
                <span class="wrong-error">* {{$errors->first('password')}}</span>
            @endif
        </div>
    </div>
    <div class="col l4 m4 s6">
        <div class="form-group {{$errors->has('password') ? 'has-error' : ''}}">
            {!! Form::password('password_confirmation', ['id' => 'password_confirmation', 'class' => 'form-control', 'placeholder' => get_string('password_confirmation')]) !!}
            {!! Form::label('password_confirmation', get_string('password_confirmation'))!!}
            @if($errors->has('password'))
                <span class="wrong-error">* {{$errors->first('password')}}</span>
            @endif
        </div>
    </div>
    <div class="clearfix col m6 s6">
        <img class="responsive-img featured-img" src="{{ $owner->logo }}"  style="display: block"/>
        <a href="#!" class="delete-featured-image btn waves-effect btn-red mtop10 mbot10" data-id="2"><i class="material-icons color-white">delete</i>{{ get_string('delete_image') }}</a>
        <div class="clearfix input-group">
                <label class="input-group-btn">
                            <span class="btn btn-primary waves-effect">{{get_string('profile_picture')}} <i class="material-icons small">add_circle</i>
                                {!! Form::file('logo', ['id' => 'logo', 'class' => 'hidden']) !!}
                            </span>
                </label>
                <input type="text" class="form-control" readonly>
            </div>
        @if($errors->has('logo'))
                <span class="wrong-error">* {{$errors->first('logo')}}</span>
            @endif
            <span class="field-info">{{get_string('max_dimension_300')}}</span>
    </div>
    <div class="col clearfix  s12">
        <div class="form-group">
            <button class="btn waves-effect" type="submit" name="action">{{get_string('update_profile')}}</button>
        </div>
    </div>
    {!! Form::close() !!}
</div>
@endsection

@section('footer')
    <script type="text/javascript">
        $('.delete-featured-image').click(function(event){
            event.preventDefault();
            var id = $(this).data('id');
            var token = $('[name="_token"]').val();
            bootbox.confirm({
                title: '{{get_string('confirm_action')}}',
                message: '{{get_string('delete_featured_image')}}',
                onEscape: true,
                backdrop: true,
                buttons: {
                    cancel: {
                        label: '{{get_string('no')}}',
                        className: 'btn waves-effect'
                    },
                    confirm: {
                        label: '{{get_string('yes')}}',
                        className: 'btn waves-effect'
                    }
                },
                callback: function (result) {
                    if(result){
                        $.ajax({
                            url: '{{ url('/admin/company/deleteImage') }}/'+id,
                            type: 'post',
                            data: {_token :token},
                            success:function(msg) {
                                $('.featured-img').attr('src', '{{ URL::asset('images/company/no_image.jpg')}}');
                                toastr.success(msg);
                            },
                            error:function(msg){
                                toastr.error(msg.responseJSON);
                            }
                        });
                    }
                }
            });
        });
    </script>
@endsection