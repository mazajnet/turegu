@extends('layouts.admin')

@section('title')
    <title>{{get_string('banners') . ' - ' . get_setting('site_name', 'site')}}</title>
@endsection
@section('content')
@section('page_title')
    <h3 class="page-title mbot10">{{get_string('banners')}}</h3>
@endsection
<div class="col s12">
    @if($banners->count())
        <div class="table-responsive">
            <table class="table bordered striped">
                <thead class="thead-inverse">
                <tr>
                    <th>
                        <input type="checkbox" class="filled-in primary-color" id="select-all" />
                        <label for="select-all"></label>
                    </th>
                    <th>{{get_string('company')}}</th>
                    <th>{{get_string('bannerType')}}</th>
                    <th>{{get_string('payment_method')}}</th>
                    <th>{{get_string('total')}}</th>
                    <th>{{get_string('start_date')}}</th>
                    <th>{{get_string('expires')}}</th>
                </tr>
                </thead>
                <tbody>
                @foreach($banners as $banner)
                    <tr class="{{ $banner->completed ? 'disabled-style' : '' }}">
                        <td>
                            <input type="checkbox" class="filled-in primary-color" id="{{$banner->id}}" />
                            <label for="{{$banner->id}}"></label>
                        </td>
                        <td>@if($banner->company){{ $banner->company->username }}@endif</td>
                        <td>{{ $banner->type ? get_string($banner->type->key) : ''}}</td>
                        <td>{{ $banner->payment_method }}</td>
                        <td>{{ $banner->payment_method == 'Points' ? '' : get_setting('currency', 'site') }}{{ $banner->total }}</td>
                        <td>{{ $banner->created_at->format('Y-m-d') }}</td>
                        <td>{{ $banner->expiresAt }}</td>
                    </tr>
                @endforeach
                </tbody>
            </table>
        </div>
        {{$banners->links()}}
    @else
        <strong class="center-align">{{get_string('no_results')}}</strong>
    @endif
</div>
<input type="hidden" class="token" value="{{ csrf_token() }}">
@endsection