<!DOCTYPE html>
<html lang="en">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0"/>

    @yield('title')

    <!-- CSS  -->
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=PT+Sans:400,500,600,700&amp;subset=cyrillic,cyrillic-ext,latin-ext" rel="stylesheet">
    <link href="{{ URL::asset('assets/css/plugins/backend_materialize.min.css')}}" rel="stylesheet">
    <link href="{{ URL::asset('assets/css/plugins/jquery-ui.min.css')}}" rel="stylesheet">
    <link href="{{ URL::asset('assets/css/plugins/toast.min.css')}}" rel="stylesheet">
    <link href="{{ URL::asset('assets/css/plugins/summernote.min.css')}}" rel="stylesheet">
    <link href="{{ URL::asset('assets/css/plugins/dropzone.min.css')}}" rel="stylesheet">
    <link href="{{ URL::asset('assets/css/plugins/colorpicker.css')}}" rel="stylesheet">
    <link href="{{ URL::asset('assets/css/backend_style.css')}}" rel="stylesheet">
    @yield('style')

</head>
<body class="mtop20">
<div class="cover"></div>
    <div class="container header-container z-depth-1">
        <div class="row no-pad-bot mbot0">
            <nav>
                <div id="header-left" class="col l10 m12 s12 header-col">
                    <div id="logo" class="col s6 m6">
                        <p class="date-text">{{date('l, jS \of F Y')}}</p>
                        <a href="{{route('admin_dashboard')}}" class="brand-logo">{{get_string('booksi')}}<span>{{get_string('cms')}}</span></a>
                    </div>
                    <div id="navigation">
                        <ul class="hide-on-med-and-down clearfix">
                            <li class="{{ setActive('admin/dashboard') }}"><a href="{{route('admin_dashboard')}}">{{get_string('dashboard')}}</a></li>
                            <li class="{{ setActive('admin/property') }}"><a href="{{route('admin.property.index')}}">{{get_string('properties')}}</a></li>
                            <li class="{{ setActive('admin/project') }}"><a href="{{route('admin.project.index')}}">{{get_string('projects')}}</a></li>
                            @if(get_setting('projects_allowed', 'project'))<li class="{{ setActive('admin/project') }}"><a href="{{route('admin.project.index')}}">{{get_string('projects')}}</a></li>@endif
                            <li class="{{ setActive('admin/taxonomy') }}">
                                <a href="#">{{get_string('taxonomy')}}<i class="material-icons tiny">arrow_drop_down</i></a>
                                    <ul class="sub-menu">
                                    <li><a href="{{route('admin.taxonomy.property-type.index')}}">{{get_string('property_types')}}</a></li>
                                    <li><a href="{{route('admin.taxonomy.project-type.index')}}">{{get_string('project_types')}}</a></li>
                                    <li><a href="{{route('admin.taxonomy.project-unit-type.index')}}">{{get_string('project_unit_types')}}</a></li>
                                    <li><a href="{{route('admin.taxonomy.contract-type.index')}}">{{get_string('contract_types')}}</a></li>
                                </ul>
                            </li>
                            <li class="{{ setActive('admin/location') }}">
                                <a href="#">{{get_string('location')}}<i class="material-icons tiny">arrow_drop_down</i></a>
                                    <ul class="sub-menu">
                                    <li><a href="{{route('admin.location.country.index')}}">{{get_string('countries')}}</a></li>
                                    <li><a href="{{route('admin.location.province.index')}}">{{get_string('provinces')}}</a></li>
                                    <li><a href="{{route('admin.location.city.index')}}">{{get_string('cities')}}</a></li>
                                </ul>
                            </li>
                            <li class="{{ setActive('admin/selectable') }}">
                                <a href="#">{{get_string('selectable')}}<i class="material-icons tiny">arrow_drop_down</i></a>
                                    <ul class="sub-menu">
                                    <li><a href="{{route('admin_selectable_propertyFeature')}}">{{get_string('propertyFeatures')}}</a></li>
                                    <li><a href="{{route('admin_selectable_projectFeature')}}">{{get_string('projectFeatures')}}</a></li>
                                    <li><a href="{{route('admin_selectable_orientation')}}">{{get_string('orientations')}}</a></li>
                                    <li><a href="{{route('admin_selectable_view')}}">{{get_string('views')}}</a></li>
                                    <li><a href="{{route('admin_selectable_wallMaterial')}}">{{get_string('wallMaterials')}}</a></li>
                                    <li><a href="{{route('admin_selectable_flooringMaterial')}}">{{get_string('flooringMaterials')}}</a></li>
                                    <li><a href="{{route('admin_selectable_kitchenMaterial')}}">{{get_string('kitchenMaterials')}}</a></li>
                                    <li><a href="{{route('admin_selectable_paymentOption')}}">{{get_string('paymentOptions')}}</a></li>
                                </ul>
                            </li>
                            <li class="{{ setActive('admin/owner') }} {{ setActive('admin/faq') }}">
                                <a href="#">{{get_string('companies')}}<i class="material-icons tiny">arrow_drop_down</i>
                                </a>
                                <ul class="sub-menu">
                                    <li><a href="{{ route('admin_company') }}">{{get_string('companies')}}</a></li>
                                    <li><a href="{{ route('admin_company_purchase') }}">{{get_string('purchases')}}</a></li>
                                    <li><a href="{{ route('admin.faq.index') }}">{{get_string('faq')}}</a></li>
                                </ul>
                            </li>
                            <li class="{{ setActive('admin/review') }}"><a href="{{route('admin_review')}}">{{get_string('reviews')}}</a></li>
                            <li class="{{ setActive('admin/page') }}"><a href="{{route('admin.page.index')}}">{{get_string('pages')}}</a></li>
                            <li class="{{ setActive('admin/blog') }}"><a href="{{route('admin.blog.index')}}">{{get_string('blog')}}</a></li>
                            <li class="{{ setActive('admin/user') }}"><a href="{{route('admin_users')}}">{{get_string('users')}}</a></li>
                            <li class="{{ setActive('admin/ad') }}"><a href="{{route('admin_ads')}}">{{get_string('ads')}}</a></li>
                            <li class="{{ setActive('admin/banner') }}"><a href="{{route('admin_banners')}}">{{get_string('banners')}}</a></li>
                            <li class="{{ setActive('admin/settings') }}">
                                <a href="#">{{get_string('settings')}}<i class="material-icons tiny">arrow_drop_down</i>
                                </a>
                                <ul class="sub-menu">
                                    <li><a href="{{route('admin_site_settings')}}">{{get_string('site_settings')}}</a></li>
                                    <!-- <li><a href="{{route('admin_user_settings')}}">{{get_string('user_settings')}}</a></li>
                                    <li><a href="{{route('admin_design_settings')}}">{{get_string('design_settings')}}</a></li> -->
                                    <li><a href="{{route('admin_translator')}}">{{get_string('translator')}}</a></li>
                                    <li><a href="{{route('admin_language_settings')}}">{{get_string('lang_settings')}}</a></li>
                                    <!-- <li><a href="{{route('admin_payment_settings')}}">{{get_string('payment_settings')}}</a></li> -->
                                    <li><a href="{{route('admin_packages')}}">{{get_string('packages')}}</a></li>
                                    <li><a href="{{route('admin_memberships')}}">{{get_string('memberships')}}</a></li>
                                    <li><a href="{{route('admin_bannerTypes')}}">{{get_string('bannerTypes')}}</a></li>
                                    <li><a href="{{route('admin_adTypes')}}">{{get_string('adTypes')}}</a></li>
                                    <li><a href="{{route('admin_currency')}}">{{get_string('currencies')}}</a></li>
                                </ul>
                            </li>
                        </ul>
                    </div>
                    <div class="col s6 show-on-small">
                        <ul id="slide-out" class="side-nav">
                            <li class="{{ setActive('admin/dashboard') }}"><a href="{{route('admin_dashboard')}}">{{get_string('dashboard')}}</a></li>
                            <li class="{{ setActive('admin/property') }}"><a href="{{route('admin.property.index')}}">{{get_string('properties')}}</a></li>
                            <li class="{{ setActive('admin/projects') }}"><a href="{{route('admin.project.index')}}">{{get_string('projects')}}</a></li>
                            <li class="no-padding">
                                <ul class="collapsible collapsible-accordion">
                                    <li>
                                        <a class="collapsible-header {{ setActive('admin/taxonomy') }}" href="#">{{get_string('taxonomy')}}<i class="material-icons tiny">arrow_drop_down</i></a>
                                        <div class="collapsible-body">
                                            <ul>
                                                <li><a href="{{route('admin.taxonomy.property-type.index')}}">{{get_string('property_types')}}</a></li>
                                                <li><a href="{{route('admin.taxonomy.project-unit-type.index')}}">{{get_string('project_unit_types')}}</a></li>
                                                <li><a href="{{route('admin.taxonomy.project-type.index')}}">{{get_string('project_types')}}</a></li>
                                                <li><a href="{{route('admin.taxonomy.contract-type.index')}}">{{get_string('contract_types')}}</a></li>
                                            </ul>
                                        </div>
                                    </li>
                                </ul>
                            </li>
                            <li class="no-padding">
                                <ul class="collapsible collapsible-accordion">
                                    <li>
                                        <a class="collapsible-header {{ setActive('admin/location') }}" href="#">{{get_string('location')}}<i class="material-icons tiny">arrow_drop_down</i></a>
                                        <div class="collapsible-body">
                                            <ul>
                                                <li><a href="{{route('admin.location.country.index')}}">{{get_string('countries')}}</a></li>
                                                <li><a href="{{route('admin.location.province.index')}}">{{get_string('province')}}</a></li>
                                                <li><a href="{{route('admin.location.city.index')}}">{{get_string('cities')}}</a></li>
                                            </ul>
                                        </div>
                                    </li>
                                </ul>
                            </li>
                            <li class="no-padding">
                                <ul class="collapsible collapsible-accordion">
                                    <li>
                                        <a class="collapsible-header {{ setActive('admin/selectable') }}" href="#">{{get_string('selectable')}}<i class="material-icons tiny">arrow_drop_down</i></a>
                                        <div class="collapsible-body">
                                            <ul>
                                                <li><a href="{{route('admin_selectable_propertyFeature')}}">{{get_string('propertyFeatures')}}</a></li>
                                                <li><a href="{{route('admin_selectable_projectFeature')}}">{{get_string('projectFeatures')}}</a></li>
                                                <li><a href="{{route('admin_selectable_orientation')}}">{{get_string('orientations')}}</a></li>
                                                <li><a href="{{route('admin_selectable_view')}}">{{get_string('views')}}</a></li>
                                                <li><a href="{{route('admin_selectable_wallMaterial')}}">{{get_string('wallMaterials')}}</a></li>
                                                <li><a href="{{route('admin_selectable_flooringMaterial')}}">{{get_string('flooringMaterials')}}</a></li>
                                                <li><a href="{{route('admin_selectable_kitchenMaterial')}}">{{get_string('kitchenMaterials')}}</a></li>
                                                <li><a href="{{route('admin_selectable_paymentOption')}}">{{get_string('paymentOptions')}}</a></li>
                                            </ul>
                                        </div>
                                    </li>
                                </ul>
                            </li>
                            <li class="no-padding">
                                <ul class="collapsible collapsible-accordion">
                                    <li>
                                        <a class="collapsible-header {{ setActive('admin/owner') }}" href="#">{{get_string('companies')}}<i class="material-icons tiny">arrow_drop_down</i></a>
                                        <div class="collapsible-body">
                                            <ul>
                                                <li><a href="{{ route('admin_company') }}">{{get_string('companies')}}</a></li>
                                                <li><a href="{{ route('admin_company_purchase') }}">{{get_string('purchases')}}</a></li>
                                                <li><a href="{{ route('admin.faq.index') }}">{{get_string('faq')}}</a></li>
                                            </ul>
                                        </div>
                                    </li>
                                </ul>
                            </li>
                            <li class="{{ setActive('admin/review') }}"><a href="{{route('admin_review')}}">{{get_string('property')}}</a></li>
                            <li class="{{ setActive('admin/page') }}"><a href="{{route('admin.page.index')}}">{{get_string('pages')}}</a></li>
                            <li class="{{ setActive('admin/blog') }}"><a href="{{route('admin.blog.index')}}">{{get_string('blog')}}</a></li>
                            <li class="{{ setActive('admin/user') }}"><a href="{{route('admin_users')}}">{{get_string('users')}}</a></li>
                            <li class="no-padding">
                                <ul class="collapsible collapsible-accordion">
                                    <li>
                                        <a class="collapsible-header {{ setActive('admin/settings') }}" href="#">{{get_string('settings')}}<i class="material-icons tiny">arrow_drop_down</i></a>
                                        <div class="collapsible-body">
                                            <ul>
                                                <li><a href="{{route('admin_site_settings')}}">{{get_string('site_settings')}}</a></li>
                                                <!-- <li><a href="{{route('admin_user_settings')}}">{{get_string('user_settings')}}</a></li>
                                                <li><a href="{{route('admin_design_settings')}}">{{get_string('design_settings')}}</a></li> -->
                                                <li><a href="{{route('admin_translator')}}">{{get_string('translator')}}</a></li>
                                                <li><a href="{{route('admin_language_settings')}}">{{get_string('lang_settings')}}</a></li>
                                               <!--  <li><a href="{{route('admin_payment_settings')}}">{{get_string('payment_settings')}}</a></li> -->
                                                <li><a href="{{route('admin_packages')}}">{{get_string('packages')}}</a></li>
                                                <li><a href="{{route('admin_memberships')}}">{{get_string('memberships')}}</a></li>
                                                <li><a href="{{route('admin_bannerTypes')}}">{{get_string('bannerTypes')}}</a></li>
                                                <li><a href="{{route('admin_adTypes')}}">{{get_string('adTypes')}}</a></li>
                                                <li><a href="{{route('admin_currency')}}">{{get_string('currencies')}}</a></li>
                                            </ul>
                                        </div>
                                    </li>
                                </ul>
                            </li>
                            <li class="no-padding">
                                <ul class="collapsible collapsible-accordion">
                                    <li>
                                        <a class="collapsible-header {{ setActive('admin/my_account') }}" href="#">{{get_string('my_account')}}<i class="material-icons tiny">arrow_drop_down</i></a>
                                        <div class="collapsible-body">
                                            <ul>
                                                <li class="{{ setActive('admin/my_account') }}"><a href="{{route('admin_my_account')}}">{{get_string('my_account')}}</a></li>
                                                <li><a href="{{route('admin_logout')}}">{{get_string('logout')}}</a></li>
                                            </ul>
                                        </div>
                                    </li>
                                </ul>
                            </li>
                            <li><a href="#">{{get_string('my_website')}}</a></li>
                        </ul>
                        <a href="#" data-activates="slide-out" class="button-collapse menu-button"><i class="material-icons">menu</i></a>
                    </div>
                </div>
                <div id="header-right" class="col s2 header-col hide-on-med-and-down">
                    <div class="user-box">
                        @if(Auth::user()->admin)
                        <div class="user-img">
                            <img src="{{ Auth::user()->admin->avatar}}" alt="user-img" title="{{Auth::user()->username}}" class="responsive-img">
                        </div>
                        @endif
                        <div class="user-icons">
                                <span class="user-name">{{Auth::user()->username}}</span>
                                <span class="user-role">{{Auth::user()->role->role}}</span>
                                <a href="{{config('app.url')}}" title="{{get_string('my_website')}}"><i class="material-icons tiny color-white">input</i></a>
                                <a href="{{route('admin_my_account')}}" title="{{get_string('my_account')}}"><i class="material-icons tiny color-white">settings</i></a>
                                <a href="{{route('admin_logout')}}" title="{{get_string('logout')}}"><i class="material-icons tiny color-red">power_settings_new</i></a>
                        </div>
                    </div>
                </div>
            </nav>
        </div>
    </div>
    <div class="container home-container z-depth-1">
        <div class="row mbot0">
            <div class="col s12">
    @yield('page_title')
            </div>
    @yield('content')
        </div>
    </div>
    <div class="container footer-container">
        <div class="row">
            <div class="col s12">
                <p> {{ get_string('copyright') . date('Y') . ' ' . get_string('rights_reserved') . get_setting('site_name', 'site')}} | {!! get_string('powered_by')  !!}</p>
            </div>
        </div>
    </div>
<!--  Scripts-->
<script src="{{URL::asset('assets/js/plugins/jquery.min.js')}}"></script>
<script type="text/javascript">
    window.paceOptions = {
        ajax: false,
        restartOnRequestAfter: false,
    };
</script>
<script src="{{URL::asset('assets/js/plugins/backend_bootstrap.min.js')}}"></script>
<script src="{{URL::asset('assets/js/plugins/backend_plugins.min.js')}}"></script>
<script src="{{URL::asset('assets/js/plugins/waypoints.min.js')}}"></script>
<script src="{{URL::asset('assets/js/plugins/waves.min.js')}}"></script>
<script src="{{URL::asset('assets/js/plugins/toast.min.js')}}"></script>
<script src="{{URL::asset('assets/js/plugins/jquery-ui.min.js')}}"></script>
<script src="{{URL::asset('assets/js/plugins/counter.min.js')}}"></script>
<script src="{{URL::asset('assets/js/plugins/summernote.min.js')}}"></script>
<script src="{{URL::asset('assets/js/plugins/dropzone.min.js')}}"></script>
<script src="{{URL::asset('assets/js/plugins/colorpicker.min.js')}}"></script>
<script src="{{URL::asset('assets/js/plugins/bootbox.min.js')}}"></script>
<script src="{{URL::asset('assets/js/backend_init.js')}}"></script>

<script type="text/javascript">
    // Mobile Menu
$('.button-collapse').sideNav({
    menuWidth: 300,
    edge: 'right',
    closeOnClick: true,
    draggable: true
});
</script>
    @yield('footer')
</body>
</html>
