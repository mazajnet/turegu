<?php

return [

    'text_something_happened'       => 'Something Happened. Please try again!',
    'text_image_uploaded'           => 'Image Successfully Uploaded!',
    'text_image_deleted'            => 'Image Successfully Deleted!',
    'text_remove'                   => 'Remove',
    'text_big_image'                => 'Max allowed size is 1MB',

];