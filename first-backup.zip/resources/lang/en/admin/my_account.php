<?php

return [

    'text_title'                    => 'My Account',
    'text_my_account'               => 'My Account',
    'text_email_address'            => 'Email Address',
    'text_username'                 => 'Username',
    'text_password'                 => 'New Password',
    'text_password_confirmation'    => 'Password Confirmation',
    'text_first_name'               => 'First Name',
    'text_last_name'                => 'Last Name',
    'text_address'                  => 'Address',
    'text_city'                     => 'City',
    'text_state'                    => 'State',
    'text_country'                  => 'Country',
    'text_zip'                      => 'Zip',
    'text_profile_picture'          => 'Upload Picture',
    'text_update_profile'           => 'Update Your Profile',
    'text_select_picture'           => 'Select Profile Picture',
    'text_max_dimension'            => '* Maximum dimension: 300x300'

];