<?php

return [

  /*
  |--------------------------------------------------------------------------
  | Main Config File
  |--------------------------------------------------------------------------
  |
  | This is where we store all config files needed in the application.
  | Configurations like keys, options, settings that are present through
  | the application can be found here.
  */

    'timezone' => 'Europe/London',


];