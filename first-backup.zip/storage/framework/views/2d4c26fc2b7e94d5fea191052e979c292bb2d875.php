<?php $__env->startSection('title'); ?>
    <title><?php echo e(get_string('view_tours') . ' - ' . get_setting('site_name', 'site')); ?></title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<?php $__env->startSection('page_title'); ?>
    <h3 class="page-title mbot10"><?php echo e(get_string('view_tours')); ?></h3>
<?php $__env->stopSection(); ?>
    <div class="col s12">
        <?php if($viewTours->count()): ?>
        <div class="table-responsive">
        <table class="table bordered striped">
            <thead class="thead-inverse">
            <tr>
                <th>
                    <input type="checkbox" class="filled-in primary-color" id="select-all" />
                    <label for="select-all"></label>
                </th>
                <th><?php echo e(get_string('agent')); ?></th>
                <th><?php echo e(get_string('date')); ?></th>
                <th><?php echo e(get_string('number_of_properties')); ?></th>
                <th><?php echo e(get_string('number_of_days')); ?></th>
                <th><?php echo e(get_string('price')); ?></th>
            </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $viewTours; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $viewTour): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                    <tr>
                        <td>
                            <input type="checkbox" class="filled-in primary-color" id="<?php echo e($viewTour->id); ?>" />
                            <label for="<?php echo e($viewTour->id); ?>"></label>
                        </td>
                        <td><?php if($viewTour->agent): ?> <?php echo e($viewTour->agent->username); ?>  <?php else: ?> <i class="small material-icons color-red">clear</i> <?php endif; ?></td>
                        <td><?php echo e($viewTour->start_date .' - '. $viewTour->end_date); ?></td>
                        <td><?php echo e($viewTour->number_of_properties); ?> </td>
                        <td><?php echo e($viewTour->number_of_days); ?> </td>
                        <td><?php echo e(get_setting('currency', 'site')); ?><?php echo e($viewTour->price); ?> </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
            </tbody>
        </table>
        </div>
        <?php echo e($viewTours->links()); ?>

        <?php else: ?>
            <strong class="center-align"><?php echo e(get_string('no_results')); ?></strong>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.agent', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>