

<?php $__env->startSection('title'); ?>
    <title><?php echo e(get_string('ads') . ' - ' . get_setting('site_name', 'site')); ?></title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<?php $__env->startSection('page_title'); ?>
    <h3 class="page-title mbot10"><?php echo e(get_string('ads')); ?></h3>
<?php $__env->stopSection(); ?>
<?php if(Session::has('ad_msg')): ?>
<div class="col s12">
    <div class="col s12 text-centered">
        <h5 class="color-red"><?php echo e(Session::get('ad_msg')); ?></h5>
    </div>
</div>
<?php endif; ?>
<?php if(Session::has('ad_success_msg')): ?>
<div class="col s12">
    <div class="col s12 text-centered">
        <h5 class="color-primary"><?php echo e(Session::get('ad_success_msg')); ?></h5>
    </div>
</div>
<?php endif; ?>
<div class="col l12 m12 s12 right right-align mbot10">
    <a href="#create-modal" data-toggle="modal" class="add-button btn waves-effect"> <?php echo e(get_string('property_ad')); ?> <i class="material-icons small">add_circle</i></a>
    <a href="#create-modal-project" data-toggle="modal" class="add-button btn waves-effect"> <?php echo e(get_string('project_ad')); ?> <i class="material-icons small">add_circle</i></a>
</div>
<div class="col s12">
    <?php if(!$errors->isEmpty()): ?>
        <span class="wrong-error">* <?php echo e(get_string('validation_error')); ?></span>
    <?php endif; ?>
    <?php if($ads->count()): ?>
        <div class="table-responsive">
            <table class="table bordered striped">
                <thead class="thead-inverse">
                <tr>
                    <th>
                        <input type="checkbox" class="filled-in primary-color" id="select-all" />
                        <label for="select-all"></label>
                    </th>
                    <th><?php echo e(get_string('company')); ?></th>
                    <th><?php echo e(get_string('adType')); ?></th>
                    <th><?php echo e(get_string('property')); ?> / <?php echo e(get_string('project')); ?></th>
                    <th><?php echo e(get_string('payment_method')); ?></th>
                    <th><?php echo e(get_string('total')); ?></th>
                    <th><?php echo e(get_string('start_date')); ?></th>
                    <th><?php echo e(get_string('expires')); ?></th>
                    <th><?php echo e(get_string('options')); ?></th>
                </tr>
                </thead>
                <tbody>
                <?php $now = \Carbon\Carbon::now(); ?>
                <?php $__currentLoopData = $ads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ad): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                    <tr class="<?php echo e($ad->completed ? 'disabled-style' : ''); ?>">
                        <td>
                            <input type="checkbox" class="filled-in primary-color" id="<?php echo e($ad->id); ?>" />
                            <label for="<?php echo e($ad->id); ?>"></label>
                        </td>
                        <td><?php if($ad->company): ?><?php echo e($ad->company->username); ?><?php endif; ?></td>
                        <td><?php echo e($ad->type ? get_string($ad->type->key) : ''); ?></td>
                        <td><?php if($ad->property_id && $ad->property): ?> <?php echo e($ad->property->contentDefault->name); ?> <?php elseif($ad->project_id && $ad->project): ?> <?php echo e($ad->project->contentDefault->name); ?> <?php else: ?> X <?php endif; ?></td>
                        <td><?php echo e($ad->payment_method); ?></td>
                        <td><?php echo e($ad->payment_method == 'Points' ? '' : get_setting('currency', 'site')); ?><?php echo e($ad->total); ?></td>
                        <td><?php echo e($ad->created_at->format('Y-m-d')); ?></td>
                        <td <?php if($now->gt(\Carbon\Carbon::createFromFormat('Y-m-d', $ad->expiresAt))): ?> style="color: red;" <?php endif; ?>><?php echo e($ad->expiresAt); ?></td>

                        <td>
                            <a href="#" class="extend-button" data-id="<?php echo e($ad->id); ?>"><i class="small material-icons ">av_timer</i></a>
                            <?php if($ad->property_id): ?> <a href="#" class="update-button" data-id="<?php echo e($ad->id); ?>"><i class="small material-icons primary-color">mode_edit</i></a> <?php else: ?> <a href="#" class="update-project-button" data-id="<?php echo e($ad->id); ?>"><i class="small material-icons primary-color">mode_edit</i></a> <?php endif; ?>
                            <a href="#" class="delete-button" data-id="<?php echo e($ad->id); ?>" data-type-id="<?php echo e($ad->type->id); ?>"><i class="small material-icons color-red">delete</i></a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                </tbody>
            </table>
        </div>
        <?php echo e($ads->links()); ?>

    <?php else: ?>
        <strong class="center-align"><?php echo e(get_string('no_results')); ?></strong>
    <?php endif; ?>
</div>

<input type="hidden" class="token" value="<?php echo e(csrf_token()); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>

<div id="create-modal" class="modal not-summernote fade" role="dialog">
    <div class="modal-dialog">
        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <a href="#!" class="close" data-dismiss="modal" aria-label="Close"><i class="material-icons">clear</i></a>
                <strong class="modal-title"><?php echo e(get_string('create_ad')); ?></strong>
            </div>
            <?php echo Form::open(['method' => 'post', 'url' => route('company_create_property_ad')]); ?>

            <div class="modal-body">
                <div class="row mbot0">
                    <div class="col s12">
                        <div class="form-group">
                            <?php echo e(Form::select('ad_type_id', $aT, null, ['class' => 'form-control', 'required', 'placeholder' => get_string('adType')])); ?>

                            <?php echo e(Form::label('ad_type_id', get_string('adType'))); ?>

                        </div>
                    </div>
                    <div class="col s12">
                        <div class="form-group">
                            <?php echo e(Form::select('term', [0 => get_string('week'), 1 => get_string('month'), 2 => get_string('year')], null, ['class' => 'extend-terms form-control', 'required', 'placeholder' => get_string('select_term')])); ?>

                            <?php echo e(Form::label('term', get_string('select_term'))); ?>

                        </div>
                    </div>
                    <div class="col s12">
                        <div class="form-group">
                            <?php echo e(Form::select('property_id', $properties, null, ['class' => 'form-control', 'required', 'placeholder' => get_string('property')])); ?>

                            <?php echo e(Form::label('property_id', get_string('property'))); ?>

                        </div>
                    </div>
                </div>
                <span class="field-info">* <?php echo e(get_string('fill_all_fields')); ?></span>
            </div>
            <div class="modal-footer">
                <a href="#!" class="waves-effect btn btn-default" data-dismiss="modal"><?php echo e(get_string('close')); ?></a>
                <button type="submit" name="action" class="waves-effect btn btn-default"><?php echo e(get_string('create')); ?></button>
            </div>
            <?php echo Form::close(); ?>

        </div>
    </div>
</div>

<div id="create-modal-project" class="modal not-summernote fade" role="dialog">
    <div class="modal-dialog">
        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <a href="#!" class="close" data-dismiss="modal" aria-label="Close"><i class="material-icons">clear</i></a>
                <strong class="modal-title"><?php echo e(get_string('create_ad')); ?></strong>
            </div>
            <?php echo Form::open(['method' => 'post', 'url' => route('company_create_project_ad')]); ?>

            <div class="modal-body">
                <div class="row mbot0">
                    <div class="col s12">
                        <div class="form-group">
                            <?php echo e(Form::select('ad_type_id', $aT, null, ['class' => 'form-control', 'required', 'placeholder' => get_string('adType')])); ?>

                            <?php echo e(Form::label('ad_type_id', get_string('adType'))); ?>

                        </div>
                    </div>
                    <div class="col s12">
                        <div class="form-group">
                            <?php echo e(Form::select('term', [0 => get_string('week'), 1 => get_string('month'), 2 => get_string('year')], null, ['class' => 'extend-terms form-control', 'required', 'placeholder' => get_string('select_term')])); ?>

                            <?php echo e(Form::label('term', get_string('select_term'))); ?>

                        </div>
                    </div>
                    <div class="col s12">
                        <div class="form-group">
                            <?php echo e(Form::select('project_id', $projects, null, ['class' => 'form-control', 'required', 'placeholder' => get_string('project')])); ?>

                            <?php echo e(Form::label('project_id', get_string('project'))); ?>

                        </div>
                    </div>
                </div>
                <span class="field-info">* <?php echo e(get_string('fill_all_fields')); ?></span>
            </div>
            <div class="modal-footer">
                <a href="#!" class="waves-effect btn btn-default" data-dismiss="modal"><?php echo e(get_string('close')); ?></a>
                <button type="submit" name="action" class="waves-effect btn btn-default"><?php echo e(get_string('create')); ?></button>
            </div>
            <?php echo Form::close(); ?>

        </div>
    </div>
</div>

<div id="update-modal" class="modal not-summernote fade" role="dialog">
    <div class="modal-dialog">
        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <a href="#!" class="close" data-dismiss="modal" aria-label="Close"><i class="material-icons">clear</i></a>
                <strong class="modal-title"><?php echo e(get_string('edit_ad')); ?></strong>
            </div>
            <?php echo Form::open(['method' => 'post', 'url' => route('company_edit_property_ad')]); ?>

            <div class="modal-body">
                <div class="row mbot0">
                    <div class="col s12">
                        <div class="form-group">
                            <?php echo e(Form::select('property_id', $properties, null, ['class' => 'form-control', 'required', 'placeholder' => get_string('property')])); ?>

                            <?php echo e(Form::label('property_id', get_string('property'))); ?>

                        </div>
                    </div>
                </div>
                <?php echo e(Form::hidden('ad_id', null)); ?>

                <span class="field-info">* <?php echo e(get_string('fill_all_fields')); ?></span>
            </div>
            <div class="modal-footer">
                <a href="#!" class="waves-effect btn btn-default" data-dismiss="modal"><?php echo e(get_string('close')); ?></a>
                <button type="submit" name="action" class="waves-effect btn btn-default"><?php echo e(get_string('update')); ?></button>
            </div>
            <?php echo Form::close(); ?>

        </div>
    </div>
</div>

<div id="update-modal-project" class="modal not-summernote fade" role="dialog">
    <div class="modal-dialog">
        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <a href="#!" class="close" data-dismiss="modal" aria-label="Close"><i class="material-icons">clear</i></a>
                <strong class="modal-title"><?php echo e(get_string('edit_ad')); ?></strong>
            </div>
            <?php echo Form::open(['method' => 'post', 'url' => route('company_edit_project_ad')]); ?>

            <div class="modal-body">
                <div class="row mbot0">
                    <div class="col s12">
                        <div class="form-group">
                            <?php echo e(Form::select('project_id', $projects, null, ['class' => 'form-control', 'required', 'placeholder' => get_string('project')])); ?>

                            <?php echo e(Form::label('project_id', get_string('project'))); ?>

                        </div>
                    </div>
                </div>
                <?php echo e(Form::hidden('ad_id', null)); ?>

                <span class="field-info">* <?php echo e(get_string('fill_all_fields')); ?></span>
            </div>
            <div class="modal-footer">
                <a href="#!" class="waves-effect btn btn-default" data-dismiss="modal"><?php echo e(get_string('close')); ?></a>
                <button type="submit" name="action" class="waves-effect btn btn-default"><?php echo e(get_string('update')); ?></button>
            </div>
            <?php echo Form::close(); ?>

        </div>
    </div>
</div>


<div id="extend-modal" class="modal not-summernote fade" role="dialog">
    <div class="modal-dialog">
        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <a href="#!" class="close" data-dismiss="modal" aria-label="Close"><i class="material-icons">clear</i></a>
                <strong class="modal-title"><?php echo e(get_string('extend_ad')); ?></strong>
            </div>
            <?php echo Form::open(['method' => 'post', 'url' => route('company_extend_ad')]); ?>

            <div class="modal-body">
                <div class="row mbot0">
                    <div class="col s12">
                        <div class="form-group">
                            <?php echo e(Form::select('term', [0 => get_string('week'), 1 => get_string('month'), 2 => get_string('year')], null, ['class' => 'extend-terms form-control', 'required', 'placeholder' => get_string('select_term')])); ?>

                            <?php echo e(Form::label('term', get_string('select_term'))); ?>

                        </div>
                    </div>
                </div>
                <?php echo e(Form::hidden('ad_id', null)); ?>

                <span class="field-info">* <?php echo e(get_string('fill_all_fields')); ?></span>
            </div>
            <div class="modal-footer">
                <a href="#!" class="waves-effect btn btn-default" data-dismiss="modal"><?php echo e(get_string('close')); ?></a>
                <button type="submit" name="action" class="waves-effect btn btn-default"><?php echo e(get_string('update')); ?></button>
            </div>
            <?php echo Form::close(); ?>

        </div>
    </div>
</div>

<?php echo e(csrf_field()); ?>

<script>

    $(document).ready(function() {

        $('.extend-button').click(function(e){
            e.preventDefault();
            $('[name="ad_id"]').val($(this).data('id'));
            $('#extend-modal').modal('show');
        });

        $('.update-button').click(function(e){
            e.preventDefault();
            $('[name="ad_id"]').val($(this).data('id'));
            $('#update-modal').modal('show');
        });

        $('.update-project-button').click(function(e){
            e.preventDefault();
            $('[name="ad_id"]').val($(this).data('id'));
            $('#update-modal-project').modal('show');
        });


        $('.delete-button').click(function(event){
            event.preventDefault();
            var id = $(this).data('id');
            var selector = $(this).parents('tr');
            var token = $('[name=_token]').val();
            bootbox.confirm({
                title: '<?php echo e(get_string('confirm_action')); ?>',
                message: '<?php echo e(get_string('delete_confirm')); ?>',
                onEscape: true,
                backdrop: true,
                buttons: {
                    cancel: {
                        label: '<?php echo e(get_string('no')); ?>',
                        className: 'btn waves-effect'
                    },
                    confirm: {
                        label: '<?php echo e(get_string('yes')); ?>',
                        className: 'btn waves-effect'
                    }
                },
                callback: function (result) {
                    if(result){
                        $.ajax({
                            url: '<?php echo e(url('/company/ad')); ?>/'+id,
                            type: 'post',
                            data: {_method: 'delete', _token :token},
                            success:function(msg) {
                                selector.remove();
                                toastr.success(msg);
                            },
                            error:function(msg){
                                toastr.error(msg.responseJSON);
                            }
                        });
                    }
                }
            });
        });

    });

</script>

<?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.company', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>