

<?php $__env->startSection('title'); ?>
<title><?php echo e(get_string('dashboard') . ' - ' . get_setting('site_name', 'site')); ?></title>
<?php $__env->stopSection(); ?>

    <?php $__env->startSection('page_title'); ?>
        <h3 class="page-title mbot10"><?php echo e(get_string('dashboard')); ?></h3>
    <?php $__env->stopSection(); ?>
        <?php $__env->startSection('content'); ?>
            <div class="row mbot0">
                <div class="col s12">
                    <div class="col l3 m6 s12">
                        <div class="card">
                            <div class="card-content no-padding">
                                <div class="blue-card card-stats-body waves-effect">
                                    <div class="stats-icon right-align">
                                        <i class="medium material-icons">payment</i>
                                    </div>
                                    <div class="stats-text left-align">
                                        <strong class="counter"><?php echo e($data['new_properties']); ?></strong><br>
                                        <span><?php echo e(get_string('new_listings')); ?></span>
                                    </div>
                                </div>
                            </div><!--end .card-body -->
                        </div>
                    </div>
                    <div class="col l3 m6 s12">
                        <div class="card">
                            <div class="card-content no-padding">
                                <div class="blue-card card-stats-body waves-effect">
                                    <div class="stats-icon right-align">
                                        <i class="medium material-icons">thumb_up</i>
                                    </div>
                                    <div class="stats-text left-align">
                                        <strong class="counter"><?php echo e($data['new_bookings']); ?></strong><br>
                                        <span><?php echo e(get_string('new_bookings')); ?></span>
                                    </div>
                                </div>
                            </div><!--end .card-body -->
                        </div>
                    </div>
                    <div class="col l3 m6 s12">
                        <div class="card">
                            <div class="card-content no-padding">
                                <div class="blue-card card-stats-body waves-effect">
                                    <div class="stats-icon right-align">
                                        <i class="medium material-icons">supervisor_account</i>
                                    </div>
                                    <div class="stats-text left-align">
                                        <strong class="counter"><?php echo e($data['new_members']); ?></strong><br>
                                        <span><?php echo e(get_string('new_members')); ?></span>
                                    </div>
                                </div>
                            </div><!--end .card-body -->
                        </div>
                    </div>
                    <div class="col l3 m6 s12">
                        <div class="card">
                            <div class="card-content no-padding">
                                <div class="blue-card card-stats-body waves-effect">
                                    <div class="stats-icon right-align">
                                        <i class="medium material-icons">info_outline</i>
                                    </div>
                                    <div class="stats-text left-align">
                                        <strong class="counter"><?php echo e($data['new_visits']); ?></strong><br>
                                        <span><?php echo e(get_string('visits_today')); ?></span>
                                    </div>
                                </div>
                            </div><!--end .card-body -->
                        </div>
                    </div>
                </div>
            </div>
            <div class="col s12">
                <h3 class="page-title"><?php echo e(get_string('latest_purchases')); ?></h3>
                <?php if(count($purchases)): ?>
                    <div class="table-responsive">
                    <table id="latest-purchases" class="responsive-table bordered striped">
                        <thead class="thead-inverse">
                        <tr>
                            <th>#</th>
                            <th><?php echo e(get_string('user')); ?></th>
                            <th><?php echo e(get_string('points_purchased')); ?></th>
                            <th><?php echo e(get_string('price')); ?></th>
                            <th><?php echo e(get_string('transaction')); ?></th>
                            <th><?php echo e(get_string('date_of_purchase')); ?></th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $purchases; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $purchase): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                            <tr>
                                <td>
                                    <input type="checkbox" class="filled-in primary-color" id="<?php echo e($purchase->id); ?>" />
                                    <label for="<?php echo e($purchase->id); ?>"></label>
                                </td>
                                <td><?php if($purchase->user): ?><?php echo e($purchase->user->username); ?> <?php endif; ?></td>
                                <td><?php echo e($purchase->points); ?></td>
                                <td><?php echo e($purchase->price); ?> <?php echo e($currency); ?></td>
                                <td><?php echo e($purchase->transaction); ?></td>
                                <td><?php echo e(date(get_setting('dateformat', 'site'), strtotime($purchase->created_at))); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                        </tbody>
                    </table>
                    </div>
                <?php else: ?>
                    <strong class="center-align"><?php echo e(get_string('no_results')); ?></strong>
                <?php endif; ?>
            </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
    <script src="<?php echo e(URL::asset('assets/js/plugins/chart.min.js')); ?>"></script>
    <script>
        $(document).ready(function($) {
            $('.counter').counterUp({
                delay: 10,
                time: 1000
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>