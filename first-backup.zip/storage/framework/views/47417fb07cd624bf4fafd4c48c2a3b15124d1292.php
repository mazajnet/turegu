

<?php $__env->startSection('title'); ?>
    <title><?php echo e(get_string('edit_unit') . ' - ' . get_setting('site_name', 'site')); ?></title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php $__env->startSection('page_title'); ?>
    <h3 class="page-title mbot10"><?php echo e(get_string('edit_unit')); ?></h3>
<?php $__env->stopSection(); ?>
<div class="col s12">
    <?php if(!$errors->isEmpty()): ?>
        <span class="wrong-error">* <?php echo e(get_string('validation_error')); ?></span>
    <?php endif; ?>
    <?php echo Form::open(['method' => 'patch', 'url' => route('company_project_unit_update', [$id, $unit->id]), 'files' => 'true']); ?>

    <div class="panel">
        <div class="panel-heading">
            <ul class="nav nav-tabs">
                <li class="tab active"><a href="#content-panel" data-toggle="tab"><?php echo e(get_string('content')); ?></a></li>
                <li class="tab"><a href="#data-panel" data-toggle="tab"><?php echo e(get_string('data')); ?></a></li>
                <li class="tab"><a href="#media-panel" data-toggle="tab"><?php echo e(get_string('media')); ?></a></li>
            </ul>
        </div>
        <div class="panel-body">
            <div class="tab-content">
                <div id="content-panel" class="tab-pane active">
                    <div class="panel">
                        <div class="panel-heading">
                            <ul class="nav nav-tabs">
                                <?php $__currentLoopData = $languages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $language): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                    <li class="tab <?php echo e($language->default ? 'active' : ''); ?>"><a href="#lang<?php echo e($language->id); ?>" data-parent="#content" data-toggle="tab"><img src="<?php echo e($language->flag); ?>"/><span><?php echo e($language->language); ?></span></a></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                            </ul>
                        </div>
                        <div class="panel-body">
                            <div class="tab-content">
                                <?php $__currentLoopData = $languages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $language): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                    <div id="lang<?php echo e($language->id); ?>" class="tab-pane <?php echo e($language->default ? 'active' : ''); ?>">
                                        <div class="col s12">
                                            <div class="form-group  <?php echo e($errors->has('name.'.$language->id.'') ? 'has-error' : ''); ?>">
                                                <?php echo e(Form::text('name['.$language->id.']', $unit->content($language->id)->name, ['class' => 'form-control', 'placeholder' => get_string('unit')])); ?>

                                                <?php echo e(Form::label('name['.$language->id.']', get_string('unit'))); ?>

                                                <?php if($errors->has('name.'.$language->id.'')): ?>
                                                    <span class="wrong-error">* <?php echo e($errors->first('name.'.$language->id.'')); ?></span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                        <div class="col s12">
                                            <?php echo e(Form::textarea('description['.$language->id.']', $unit->content($language->id)->description, ['class' => 'hidden desc-content'])); ?>

                                            <?php if($errors->has('description.'.$language->id.'')): ?>
                                                <span class="wrong-error">* <?php echo e($errors->first('description.'.$language->id.'')); ?></span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                            </div>
                        </div>
                    </div>
                </div>
                <div id="data-panel" class="tab-pane">
                    <div class="col s6">
                        <div class="form-group  <?php echo e($errors->has('unit_type_id') ? 'has-error' : ''); ?>">
                            <?php echo e(Form::select('project_unit_type_id', $unit_types, $unit->project_unit_type_id, ['class' => 'category-select form-control', 'placeholder' => get_string('project_unit_types')])); ?>

                            <?php echo e(Form::label('project_unit_type_id', get_string('project_unit_types'))); ?>

                            <?php if($errors->has('unit_type_id')): ?>
                                <span class="wrong-error">* <?php echo e($errors->first('unit_type_id')); ?></span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="col s6">
                        <div class="form-group  <?php echo e($errors->has('price') ? 'has-error' : ''); ?>">
                            <?php echo e(Form::number('price', $unit->price, ['class' => 'category-select form-control', 'min' => 0, 'step' => 1, 'placeholder' => get_string('price')])); ?>

                            <?php echo e(Form::label('price', get_string('price'))); ?>

                            <?php if($errors->has('price')): ?>
                                <span class="wrong-error">* <?php echo e($errors->first('price')); ?></span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="col l6 m6 s12">
                        <div class="form-group  <?php echo e($errors->has('area.feet') ? 'has-error' : ''); ?>">
                            <?php echo e(Form::text('area[feet]', $unit->area['feet'], ['class' => 'feet-area form-control', 'placeholder' => get_string('property_size')])); ?>

                            <?php echo e(Form::label('area[feet]', get_string('property_size').' feet')); ?>

                            <?php if($errors->has('area.feet')): ?>
                                <span class="wrong-error">* <?php echo e($errors->first('area.feet')); ?></span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="col l6 m6 s12">
                        <div class="form-group  <?php echo e($errors->has('area.m2') ? 'has-error' : ''); ?>">
                            <?php echo e(Form::text('area[m2]', $unit->area['m2'], ['class' => 'm2-area form-control', 'placeholder' => get_string('property_size')])); ?>

                            <?php echo e(Form::label('area[m2]', get_string('property_size').' m2')); ?>

                            <?php if($errors->has('area.m2')): ?>
                                <span class="wrong-error">* <?php echo e($errors->first('area.m2')); ?></span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="col s12 clearfix">
                        <h5 class="section-title"><?php echo e(get_string('property_info')); ?></h5>
                    </div>  
                    <div class="col l6 m6 s12">
                        <div class="form-group  <?php echo e($errors->has('property_info.rooms') ? 'has-error' : ''); ?>">
                            <?php echo e(Form::text('property_info[rooms]', $unit->unit_info['unit_rooms'], ['class' => 'form-control', 'placeholder' => get_string('property_rooms')])); ?>

                            <?php echo e(Form::label('property_info[rooms]', get_string('property_rooms'))); ?>

                            <?php if($errors->has('property_info.rooms')): ?>
                                <span class="wrong-error">* <?php echo e($errors->first('property_info.rooms')); ?></span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="col l6 m6 s12">
                        <div class="form-group  <?php echo e($errors->has('property_info.bedrooms') ? 'has-error' : ''); ?>">
                            <?php echo e(Form::text('property_info[bedrooms]', $unit->unit_info['unit_bedrooms'], ['class' => 'form-control', 'placeholder' => get_string('property_bedrooms')])); ?>

                            <?php echo e(Form::label('property_info[bedrooms]', get_string('property_bedrooms'))); ?>

                            <?php if($errors->has('property_info.bedrooms')): ?>
                                <span class="wrong-error">* <?php echo e($errors->first('property_info.bedrooms')); ?></span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="col l6 m6 s12">
                        <div class="form-group  <?php echo e($errors->has('property_info.bathrooms') ? 'has-error' : ''); ?>">
                            <?php echo e(Form::text('property_info[bathrooms]', $unit->unit_info['unit_bathrooms'], ['class' => 'form-control', 'placeholder' => get_string('property_bathrooms')])); ?>

                            <?php echo e(Form::label('property_info[bathrooms]', get_string('property_bathrooms'))); ?>

                            <?php if($errors->has('property_info.bathrooms')): ?>
                                <span class="wrong-error">* <?php echo e($errors->first('property_info.bathrooms')); ?></span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="col l6 m6 s12">
                        <div class="form-group  <?php echo e($errors->has('property_info.garages') ? 'has-error' : ''); ?>">
                            <?php echo e(Form::text('property_info[garages]', $unit->unit_info['unit_garages'], ['class' => 'form-control', 'placeholder' => get_string('property_garages')])); ?>

                            <?php echo e(Form::label('property_info[garages]', get_string('property_garages'))); ?>

                            <?php if($errors->has('property_info.garages')): ?>
                                <span class="wrong-error">* <?php echo e($errors->first('property_info.garages')); ?></span>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <div id="media-panel" class="tab-pane">

                     <div class="col l12 m12 s12">
                        <div id="file-dropzone" class="dropzone">
                            <div class="dz-message"><?php echo e(get_string('upload_images')); ?><br/><i class="material-icons medium">cloud_upload</i>
                            </div>
                            <div class="fallback">
                            </div>
                        </div>
                    </div>

                    <div class="col s12">
                        <div class="input-group <?php echo e($errors->has('plans') ? 'has-error' : ''); ?>">
                            <label class="input-group-btn">
                            <span class="btn btn-primary waves-effect"><?php echo e(get_string('plans')); ?> <i class="material-icons small">add_circle</i>
                                <?php echo Form::file('plans[]', ['id' => 'plans', 'class' => 'hidden', 'multiple']); ?>

                            </span>
                            </label>
                            <input type="text" class="form-control" readonly>
                        </div>
                        <?php if($errors->has('plans')): ?>
                            <span class="wrong-error">* <?php echo e($errors->first('plans')); ?></span>
                        <?php endif; ?>
                        <span class="field-info"><?php echo e(get_string('select_plans')); ?></span>
                    </div>

                    <div class="hidden-fields hidden">
                    </div>

                </div>
            </div>
            <div class="col clearfix s12 mtop10">
                <div class="form-group">
                    <button class="btn waves-effect" type="submit" name="action"><?php echo e(get_string('edit_unit')); ?></button>
                    <a href="<?php echo e(route('company_project_units', $id)); ?>" class="btn waves-effect"><?php echo e(get_string('back')); ?></a>
                </div>
            </div>
            <?php echo e(Form::hidden('company_id', Auth::user()->id)); ?>

            <?php echo e(Form::hidden('project_id', $id)); ?>

            <?php echo Form::close(); ?>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
    <script src="https://maps.googleapis.com/maps/api/js?key=<?php echo e(get_setting('google_map_key', 'site')); ?>&libraries=places"></script>
    <script>
        $(document).ready(function(){
            $('.desc-content').summernote({
                height: 200,
                maxwidth: false,
                minwidth: false,
                placeholder: '<?php echo e(get_string('enter_project_content')); ?>',
                disableDragAndDrop: true,
                toolbar: [
                    ["style", ["style"]],
                    ["font", ["bold", "underline", "clear"]],
                    ["color", ["color"]],
                    ["para", ["ul", "ol", "paragraph"]],
                ],callbacks: {
                    onPaste: function (e) {
                        var bufferText = ((e.originalEvent || e).clipboardData || window.clipboardData).getData('Text');
                        e.preventDefault();
                        document.execCommand('insertText', false, bufferText);
                    }
                }
            });

            $(this).on('input', '.feet-area', function() {
                if($(this).val() != '' ) $('.m2-area').val(parseFloat($(this).val()) * 0.092903);
                if($(this).val() == '' ) $('.m2-area').val('');
            });

            $(this).on('input', '.m2-area', function() {
                if($(this).val() != '' ) $('.feet-area').val(parseFloat($(this).val()) * 10.7639);
                if($(this).val() == '' ) $('.feet-area').val('');
            });

            
        });

        Dropzone.autoDiscover = false;
        $(document).ready(function(){
            var fileDropzone = $('#file-dropzone');
            $(fileDropzone).dropzone({
                url: '<?php echo e(url('/image_handler/upload')); ?>',
                paramsName: 'image',
                params: {_token: $('[name=_token]').val()},
                maxFilesize: 100,
                uploadMultiple: false,
                addRemoveLinks: true,
                maxfilesize: 1,
                parallelUploads: 1,
                maxFiles: 6,
                init: function() {

                    <?php if($unit->images): ?>
                        <?php $__currentLoopData = $unit->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                            var mockFile = { name: '<?php echo e($image->image); ?>', size: 100000 };
                            this.emit("addedfile", mockFile);
                            this.createThumbnailFromUrl(mockFile, '/images/data/<?php echo e($image->image); ?>');
                            this.emit("success", mockFile);
                        $('.hidden-fields').append('<input type="hidden" name="images[]" value="<?php echo e($image->image); ?>">');
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                    <?php endif; ?>

                    this.on('success', function(file, json) {
                        var selector = file._removeLink;
                        $(selector).attr('data-dz-remove', json.data);
                        $('.hidden-fields').append('<input type="hidden" name="images[]" value="'+ json.data +'">');
                    });

                    this.on('addedfile', function(file) {

                    });

                    this.on("removedfile", function(file) {
                        var selector = file._removeLink;
                        var data = $(selector).attr('data-dz-remove');
                        if(!data){
                            data = file.name;
                            $.ajax({
                                type: 'POST',
                                url: '<?php echo e(url('/image_handler/deleteBase')); ?>',
                                data: {data: data, _token: $('[name=_token]').val(), type: 'unit', id: '<?php echo e($unit->id); ?>'},
                                dataType: 'html',
                                success: function(msg){
                                    $('.hidden-fields').find('[value="'+ data +'"]').remove();
                                }
                            });
                        }else{
                            $.ajax({
                                type: 'POST',
                                url: '<?php echo e(url('/image_handler/delete')); ?>',
                                data: {data: data, _token: $('[name=_token]').val()},
                                dataType: 'html',
                                success: function(msg){
                                    $('.hidden-fields').find('[value="'+ data +'"]').remove();
                                }
                            });
                        }
                    });
                }
            });
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.company', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>