

<?php $__env->startSection('title'); ?>
    <title><?php echo e(get_string('translator') . ' - ' . get_setting('site_name', 'site')); ?></title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<?php $__env->startSection('page_title'); ?>
    <h3 class="page-title mbot10"><?php echo e(get_string('translator')); ?></h3>
<?php $__env->stopSection(); ?>
<div class="col s12">
    <?php if(!$errors->isEmpty()): ?>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
            <span class="wrong-error pull-left">* <?php echo e($error); ?> </span>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
    <?php endif; ?>
    <div class="pull-right">
        <a href="#add-modal" data-toggle="modal" class="add-button btn waves-effect"> <?php echo e(get_string('add_string')); ?> <i class="material-icons small">add_circle</i></a>
        <a href="<?php echo e(route('strings_export')); ?>"class="btn waves-effect"><i class="material-icons small">file_download</i></a>
        <a href="#import-modal" data-toggle="modal" class="import-strings btn waves-effect"><i class="material-icons">file_upload</i></a>
    </div>
        <div class="table-responsive">
        <?php if(Session::has('error')): ?>
            <p class="wrong-error"><?php echo e(get_string('something_happened')); ?></p>
        <?php endif; ?>
        <table id="data-table" class="table bordered striped">
            <thead class="thead-inverse">
            <tr>
                <th>#</th>
                <th><?php echo e(get_string('key')); ?></th>
                <th><?php echo e(get_string('string')); ?></th>
                <th class="icon-options"><?php echo e(get_string('options')); ?></th>
            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $strings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $string): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                <tr>
                    <td><?php echo e($string->id); ?></td>
                    <td><?php echo e($string->key); ?></td>
                    <td class="string-content"><?php echo e($string->string); ?></td>
                    <td>
                        <a class="edit-button" data-toggle="modal"  data-key="<?php echo e($string->key); ?>" href="#update-modal" title="<?php echo e(get_string('edit_string')); ?>"><i class="small material-icons color-primary">mode_edit</i></a>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
    <div id="add-modal" class="modal not-summernote fade" role="dialog">
        <div class="modal-dialog">
            <!-- Modal content-->
            <div class="modal-content">
                <div class="modal-header">
                    <a href="#!" class="close" data-dismiss="modal" aria-label="Close"><i class="material-icons">clear</i></a>
                    <strong class="modal-title"><?php echo e(get_string('edit_string')); ?></strong>
                </div>
                <?php echo Form::open(['method' => 'post', 'url' => route('admin_create_string')]); ?>

                <div class="modal-body">
                    <div class="row mbot0">
                        <div class="col s6">
                            <div class="form-group">
                                <?php echo e(Form::text('key', null, ['class' => 'form-control', 'placeholder' => get_string('enter_string_key')])); ?>

                                <?php echo e(Form::label('key', get_string('key'))); ?>

                            </div>
                        </div>
                        <?php $condition = 0; ?>
                        <?php $__currentLoopData = $languages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $language): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                            <?php if ($language->code == 'en') $condition = 1; ?>
                            <div class="col s6">
                                <div class="form-group">
                                    <?php echo e(Form::text('string['.$language->code.']', null, ['class' => 'form-control', 'placeholder' => $language->language])); ?>

                                    <?php echo e(Form::label('string['.$language->code.']', $language->language)); ?>

                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                        <?php if(!$condition): ?>
                            <div class="col s6">
                                <div class="form-group">
                                    <?php echo e(Form::text('string[en]', null, ['class' => 'form-control', 'placeholder' => get_string('english')])); ?>

                                    <?php echo e(Form::label('string[en]', get_string('english'))); ?>

                                </div>
                            </div>
                        <?php endif; ?>
                    </div>
                    <span class="field-info">* <?php echo e(get_string('fill_all_fields_strings')); ?></span>
                    <span id="error-form" class="wrong-error"></span>
                </div>
                <div class="modal-footer">
                    <a href="#!" class="waves-effect btn btn-default" data-dismiss="modal"><?php echo e(get_string('close')); ?></a>
                    <button type="submit" href="#" class="waves-effect btn btn-default"><?php echo e(get_string('create')); ?></button>
                </div>
                <?php echo Form::close(); ?>

            </div>
        </div>
    </div>
    <div id="update-modal" class="modal not-summernote fade" role="dialog">
        <div class="modal-dialog">
            <!-- Modal content-->
            <div class="modal-content">
                <div class="modal-header">
                    <a href="#!" class="close" data-dismiss="modal" aria-label="Close"><i class="material-icons">clear</i></a>
                    <strong class="modal-title"><?php echo e(get_string('edit_string')); ?></strong>
                </div>
                <?php echo Form::open(['method' => 'post']); ?>

                <div class="modal-body">
                    <div class="row mbot0">
                        <?php echo e(Form::hidden('key', null, ['id' => 'string_key'])); ?>

                        <?php $__currentLoopData = $languages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $language): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                            <div class="col s6">
                                <div class="form-group">
                                    <?php echo e(Form::text('string['.$language->code.']', null, ['class' => 'form-control', 'id' => 'update_id_'.$language->code, 'placeholder' => $language->language])); ?>

                                    <?php echo e(Form::label('string['.$language->code.']', $language->language)); ?>

                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                    </div>
                    <span class="field-info">* <?php echo e(get_string('fill_all_fields_strings')); ?></span>
                    <span id="error-form" class="wrong-error"></span>
                </div>
                <div class="modal-footer">
                    <a href="#!" class="waves-effect btn btn-default" data-dismiss="modal"><?php echo e(get_string('close')); ?></a>
                    <a href="#" class="update-string-form waves-effect btn btn-default"><?php echo e(get_string('update')); ?></a>
                </div>
                <?php echo Form::close(); ?>

            </div>
        </div>
    </div>
    <div id="import-modal" class="modal not-summernote fade" role="dialog">
        <div class="modal-dialog">
            <!-- Modal content-->
            <div class="modal-content">
                <div class="modal-header">
                    <a href="#!" class="close" data-dismiss="modal" aria-label="Close"><i class="material-icons">clear</i></a>
                    <strong class="modal-title"><?php echo e(get_string('import')); ?></strong>
                </div>
                <?php echo Form::open(['method' => 'post','url' => route('strings_import'), 'id' => 'import-form', 'files' => true]); ?>

                <div class="col l6 m6 s12">
                    <div class="input-group <?php echo e($errors->has('file') ? 'has-error' : ''); ?>">
                        <label class="input-group-btn">
                            <span class="btn btn-primary waves-effect"><?php echo e(get_string('select_file')); ?> <i class="material-icons small">file_upload</i>
                                <?php echo Form::file('file', ['id' => 'file', 'required', 'class' => 'hidden']); ?>

                            </span>
                        </label>
                        <input type="text" name="helper-text" class="form-control" readonly>
                    </div>
                    <span class="field-info"><?php echo e(get_string('select_exported_file_only')); ?></span>
                </div>
                <div class="modal-footer">
                    <a href="#!" class="waves-effect btn btn-default" data-dismiss="modal"><?php echo e(get_string('close')); ?></a>
                    <a href="#" class="import-button waves-effect btn btn-default" data-dismiss="modal"><?php echo e(get_string('import')); ?></a>
                </div>
                <?php echo Form::close(); ?>

            </div>
        </div>
    </div>
    <script src="<?php echo e(URL::asset('assets/js/plugins/datatables.min.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('assets/js/plugins/datatables-bootstrap.min.js')); ?>"></script>
<script type="text/javascript">
    $(document).ready(function(){

        var selector;
        $('.edit-button').click(function(e){
            e.preventDefault();
            selector = $(this).parents('tr');
            $('[id^="update_id_"]').val('');
            var key = $(this).data('key');
            $('#string_key').val(key);
            var token = $('[name="_token"]').val();
            $.ajax({
                url: '<?php echo e(url('admin/settings/translator/getString')); ?>/' + key,
                type: 'post',
                data: {_token: token},
                success: function(data){
                    $.each(data, function(index){
                       $('#update_id_' + data[index].code).val(data[index].string);
                    });
                },
                error: function(data){
                    toastr.error(msg.responseJSON);
                }
            });
        });

        $('.update-string-form').click(function(e){
            e.preventDefault();
            var data = {};
            <?php $__currentLoopData = $languages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $language): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                data.<?php echo e($language->code); ?> = $('#update_id_<?php echo e($language->code); ?>').val();
            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
            var token = $('[name="_token"]').val();
            var key = $('#string_key').val();
            $.ajax({
                url: '<?php echo e(url('admin/settings/translator/updateString')); ?>',
                type: 'post',
                data: {data: data, key: key, _token: token},
                success: function(msg){
                    $('#update-modal').modal('toggle');
                    if(typeof data.en !== 'undefined'){
                        $('.string-content', selector).html(data.en);
                    }
                },
                error: function(data){
                    $('#error-form').html('<?php echo e(get_string('please_check_default_language')); ?>').css('display', 'block');
                }
            });
        });

        $('.import-button').click(function(e){
            e.preventDefault();
            var formData = new FormData($("#import-form")[0]);
            var token = $('[name="_token"]').val();
            // formData.append("file", $('[name="file"]')[0].files[0]);
            $.ajax({
                headers: {
                    'X-CSRF-TOKEN': token
                },
                beforeSend: function(){
                    $('.table').addClass('loading');
                },
                url: '<?php echo e(route('strings_import')); ?>',
                type: 'post',
                data: formData,
                processData: false,
                contentType: false,
                success: function(data){
                    toastr.success(data);
                    $('.table').removeClass('loading');
                    setTimeout(function(){location.reload();}, 2000);
                },
                error: function(data){
                    $('.table').removeClass('loading');
                    toastr.error(data.responseJSON);
                }
            });
        });

        $('#data-table').DataTable({
            language: {
                search: "_INPUT_",
                searchPlaceholder: "<?php echo e(get_string('search_key_here')); ?>",
                "paginate": {
                    "first":      "<?php echo e(get_string('first')); ?>",
                    "last":       "<?php echo e(get_string('last')); ?>",
                    "next":       "<?php echo e(get_string('next')); ?>",
                    "previous":   "<?php echo e(get_string('previous')); ?>"
                },
            }
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>