<?php $__env->startSection('title'); ?>
    <title><?php echo e(get_string('memberships') . ' - ' . get_setting('site_name', 'site')); ?></title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php $__env->startSection('page_title'); ?>
    <h3 class="page-title mbot10"><?php echo e(get_string('memberships')); ?></h3>
<?php $__env->stopSection(); ?>
<div class="panel col s12">
    <div class="row">
        <div class="panel-heading">
            <ul class="nav nav-tabs">
                <li class="tab active"><a data-toggle="tab" href="#general_settings"><?php echo e(get_string('memberships')); ?></a></li>
            </ul>
        </div>
        <?php echo Form::open(['url' => route('admin_memberships_update'), 'method' => 'post', 'id' => "memberships", 'class' => 'table-responsive']); ?>

        <div class="panel-body">
            <div class="tab-content">
                <div id="general_settings" class="tab-pane active">

                    
                    <?php $__currentLoopData = $memberships; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $membership): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                    <div class="col s12">
                        <h3 class="page-title clearfix"><?php echo e(get_string('membership')); ?> - <?php echo e(get_string($membership->key)); ?></h3>
                    </div>
                    <div class="col m4 s12">
                        <div class="form-group">
                            <?php echo e(Form::number($membership->id.'[monthly]', $membership->monthly, ['class' => 'form-control', 'required', 'min' => 0, 'placeholder' => get_string('monthly').' - '.get_string('points')])); ?>

                            <?php echo e(Form::label('monthly', get_string('monthly').' - '.get_string('points'))); ?>

                        </div>
                    </div>
                    <div class="col m4 s12">
                        <div class="form-group">
                            <?php echo e(Form::number($membership->id.'[agents]', $membership->agents, ['class' => 'form-control', 'required', 'min' => 0, 'placeholder' => get_string('agents')])); ?>

                            <?php echo e(Form::label('agents', get_string('agents'))); ?>

                        </div>
                    </div>
                    <div class="col m4 s12">
                        <div class="form-group ">
                            <?php echo e(Form::number($membership->id.'[listings]', $membership->listings, ['class' => 'form-control', 'required', 'min' => 0, 'placeholder' => get_string('listings')])); ?>

                            <?php echo e(Form::label('listings', get_string('listings'))); ?>

                        </div>
                    </div>
                    <div class="col m4 s12">
                        <div class="form-group ">
                            <?php echo e(Form::number($membership->id.'[listing_duration]', $membership->listing_duration, ['class' => 'form-control', 'required', 'min' => 0, 'placeholder' => get_string('listing_duration').' - '.get_string('months')])); ?>

                            <?php echo e(Form::label('listing_duration', get_string('listing_duration').' - '.get_string('months'))); ?>

                        </div>
                    </div>
                    <div class="col m4 s12">
                        <div class="form-group ">
                            <?php echo e(Form::select($membership->id.'[projects]', [0 => get_string('no'), 1 => get_string('yes')], $membership->projects, ['class' => 'form-control', 'required', 'placeholder' => get_string('projects')])); ?>

                            <?php echo e(Form::label('projects', get_string('projects'))); ?>

                        </div>
                    </div>
                    <div class="col m4 s12">
                        <div class="form-group ">
                            <?php echo e(Form::select($membership->id.'[private_tour]', [0 => get_string('no'), 1 => get_string('yes')], $membership->private_tour, ['class' => 'form-control', 'required', 'placeholder' => get_string('private_tour')])); ?>

                            <?php echo e(Form::label('private_tour', get_string('private_tour'))); ?>

                        </div>
                    </div>
                    <div class="col m4 s12">
                        <div class="form-group ">
                            <?php echo e(Form::select($membership->id.'[view_tour]', [0 => get_string('no'), 1 => get_string('yes')], $membership->view_tour, ['class' => 'form-control', 'required', 'placeholder' => get_string('view_tour')])); ?>

                            <?php echo e(Form::label('view_tour', get_string('view_tour'))); ?>

                        </div>
                    </div>
                    <div class="col m4 s12">
                        <div class="form-group ">
                            <?php echo e(Form::select($membership->id.'[property_request]', [0 => get_string('no'), 1 => get_string('yes')], $membership->property_request, ['class' => 'form-control', 'required', 'placeholder' => get_string('property_requests')])); ?>

                            <?php echo e(Form::label('property_requests', get_string('property_requests'))); ?>

                        </div>
                    </div>
                    <div class="col m4 s12">
                        <div class="form-group ">
                            <?php echo e(Form::select($membership->id.'[search_company]', [0 => get_string('no'), 1 => get_string('yes')], $membership->search_company, ['class' => 'form-control', 'required', 'placeholder' => get_string('search_company')])); ?>

                            <?php echo e(Form::label('search_company', get_string('search_company'))); ?>

                        </div>
                    </div>
                    <div class="col m4 s12">
                        <div class="form-group ">
                            <?php echo e(Form::select($membership->id.'[home_logo]', [0 => get_string('no'), 1 => get_string('yes')], $membership->home_logo, ['class' => 'form-control', 'required', 'placeholder' => get_string('home_logo')])); ?>

                            <?php echo e(Form::label('home_logo', get_string('home_logo'))); ?>

                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>

                </div>
            </div>
            <div class="col clearfix l4 m4 s12 mtop10">
                <div class="form-group">
                    <button class="btn waves-effect" type="submit" name="action"><?php echo e(get_string('update')); ?></button></div>
                </div>
            </div>
        <?php echo Form::close(); ?>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>