<?php $__env->startSection('title'); ?>
    <title><?php echo e(get_string('agents') . ' - ' . get_setting('site_name', 'site')); ?></title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<?php $__env->startSection('page_title'); ?>
    <h3 class="page-title mbot10"><?php echo e(get_string('agents')); ?></h3>
<?php $__env->stopSection(); ?>
<div class="col l12 m12 s12 right right-align mbot10">
    <a href="#user-modal" data-toggle="modal" class="add-button btn waves-effect"> <?php echo e(get_string('create_agent')); ?> <i class="material-icons small">add_circle</i></a>
</div>
<div class="col s12">
    <?php if(Session::has('maximum_agents')): ?>
        <span class="wrong-error">* <?php echo e(get_string('maximum_agents')); ?></span>
    <?php endif; ?>
    <?php if(!$errors->isEmpty()): ?>
        <span class="wrong-error">* <?php echo e(get_string('validation_error')); ?></span>
    <?php endif; ?>
    <?php if($users->count()): ?>
        <div class="table-responsive">
            <table class="table bordered striped">
                <thead class="thead-inverse">
                <tr>
                    <th>
                        <input type="checkbox" class="filled-in primary-color" id="select-all" />
                        <label for="select-all"></label>
                    </th>
                    <th><?php echo e(get_string('username')); ?></th>
                    <th><?php echo e(get_string('email')); ?></th>
                    <th><?php echo e(get_string('first_name')); ?></th>
                    <th><?php echo e(get_string('last_name')); ?></th>
                    <th><?php echo e(get_string('subadmin')); ?></th>
                    <th class="icon-options"><?php echo e(get_string('options')); ?></th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                    <tr>
                        <td>
                            <input type="checkbox" class="filled-in primary-color" id="<?php echo e($user->id); ?>" />
                            <label for="<?php echo e($user->id); ?>"></label>
                        </td>
                        <td><?php echo e($user->username); ?></td>
                        <td><?php echo e($user->email); ?></td>
                        <td><?php echo e($user->agent->first_name); ?></td>
                        <td><?php echo e($user->agent->last_name); ?></td>
                        <td><?php echo e($user->agent->is_subadmin ? get_string('yes') : get_string('no')); ?></td>
                        <td>
                            <div class="icon-options">
                                <a href="#" class="delete-button" data-id="<?php echo e($user->id); ?>" title="<?php echo e(get_string('delete_user')); ?>"><i class="small material-icons color-red">delete</i></a>
                                <?php if(!$user->agent->is_subadmin): ?>
                                    <a href="#" class="upgrade-button" data-id="<?php echo e($user->id); ?>" title="<?php echo e(get_string('upgrade_user')); ?>"><i class="small material-icons color-blue">add_box</i></a>
                                <?php endif; ?>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                </tbody>
            </table>
        </div>
        <?php echo e($users->links()); ?>

    <?php else: ?>
        <strong class="center-align clearfix"><?php echo e(get_string('no_results')); ?></strong>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
<!-- Modal -->
<div id="user-modal" class="modal not-summernote fade" role="dialog">
    <div class="modal-dialog">
        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <a href="#!" class="close" data-dismiss="modal" aria-label="Close"><i class="material-icons">clear</i></a>
                <strong class="modal-title"><?php echo e(get_string('create_agent')); ?></strong>
            </div>
            <div class="modal-body">
                <?php echo Form::open(['method' => 'post', 'url' => route('company_agent_create'), 'id' => 'user-form']); ?>

                <?php echo e(Form::input('hidden', 'id', null, ['class' => 'hidden', 'id' => 'user_id'])); ?>

                <div class="row mbot0">
                    <div class="col l6 s12">
                        <div class="form-group  <?php echo e($errors->has('first_name') ? 'has-error' : ''); ?>">
                            <?php echo e(Form::text('first_name', null, [ 'id' => 'user-first-name', 'class' => 'form-control', 'placeholder' => get_string('first_name')])); ?>

                            <?php echo e(Form::label('first_name', get_string('first_name'))); ?>

                            <?php if($errors->has('first_name')): ?>
                                <span class="wrong-error">* <?php echo e($errors->first('first_name')); ?></span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="col l6 s12">
                        <div class="form-group  <?php echo e($errors->has('last_name') ? 'has-error' : ''); ?>">
                            <?php echo e(Form::text('last_name', null, [ 'id' => 'user-last-name', 'class' => 'form-control', 'placeholder' => get_string('last_name')])); ?>

                            <?php echo e(Form::label('last_name', get_string('last_name'))); ?>

                            <?php if($errors->has('last_name')): ?>
                                <span class="wrong-error">* <?php echo e($errors->first('last_name')); ?></span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="col l6 s12 clearfix">
                        <div class="form-group  <?php echo e($errors->has('email') ? 'has-error' : ''); ?>">
                            <?php echo e(Form::text('email', null, [ 'id' => 'user-email', 'required', 'class' => 'form-control', 'placeholder' => get_string('email')])); ?>

                            <?php echo e(Form::label('email', get_string('email'))); ?>

                            <?php if($errors->has('email')): ?>
                                <span class="wrong-error">* <?php echo e($errors->first('email')); ?></span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="col l6 s12">
                        <div class="form-group  <?php echo e($errors->has('username') ? 'has-error' : ''); ?>">
                            <?php echo e(Form::text('username', null, [ 'id' => 'user-username', 'required', 'class' => 'form-control', 'placeholder' => get_string('username')])); ?>

                            <?php echo e(Form::label('username', get_string('username'))); ?>

                            <?php if($errors->has('username')): ?>
                                <span class="wrong-error">* <?php echo e($errors->first('username')); ?></span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="col l6 s12">
                        <div class="form-group  <?php echo e($errors->has('contact_phone') ? 'has-error' : ''); ?>">
                            <?php echo e(Form::text('contact_phone', null, [ 'id' => 'user-last-name', 'class' => 'form-control', 'placeholder' => get_string('contact') .' '. get_string('phone')])); ?>

                            <?php echo e(Form::label('contact_phone', get_string('contact') .' '. get_string('phone'))); ?>

                            <?php if($errors->has('contact_phone')): ?>
                                <span class="wrong-error">* <?php echo e($errors->first('contact_phone')); ?></span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="col l6 s12">
                        <div class="form-group  <?php echo e($errors->has('contact_email') ? 'has-error' : ''); ?>">
                            <?php echo e(Form::text('contact_email', null, [ 'id' => 'user-contact_email', 'class' => 'form-control', 'placeholder' => get_string('contact') .' '. get_string('email')])); ?>

                            <?php echo e(Form::label('contact_email', get_string('contact') .' '. get_string('email'))); ?>

                            <?php if($errors->has('contact_email')): ?>
                                <span class="wrong-error">* <?php echo e($errors->first('contact_email')); ?></span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="col s12">
                        <div class="form-group  <?php echo e($errors->has('position') ? 'has-error' : ''); ?>">
                            <?php echo e(Form::text('position', null, [ 'id' => 'user-position', 'required', 'class' => 'form-control', 'placeholder' => get_string('position')])); ?>

                            <?php echo e(Form::label('position', get_string('position'))); ?>

                            <?php if($errors->has('position')): ?>
                                <span class="wrong-error">* <?php echo e($errors->first('position')); ?></span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <?php echo Form::hidden('is_subadmin', 0); ?>

                    <?php echo Form::hidden('image', 'no_image.jpg'); ?>

                    <?php echo Form::hidden('user_id', Auth::user()->id); ?>

                </div>
            </div>
            <div class="modal-footer">
                <a href="#!" class="waves-effect btn btn-default" data-dismiss="modal"><?php echo e(get_string('close')); ?></a>
                <button type="submit" name="action" class="update-lang-form waves-effect btn btn-default"><?php echo e(get_string('update')); ?></button>
            </div>
            <?php echo Form::close(); ?>

        </div>
    </div>
</div>
<script>
    $(document).ready(function(){

        $('.delete-button').click(function(event){
            event.preventDefault();
            var id = $(this).data('id');
            var selector = $(this).parents('tr');
            var token = $('[name=_token]').val();
            bootbox.confirm({
                title: '<?php echo e(get_string('confirm_action')); ?>',
                message: '<?php echo e(get_string('delete_confirm')); ?>',
                onEscape: true,
                backdrop: true,
                buttons: {
                    cancel: {
                        label: '<?php echo e(get_string('no')); ?>',
                        className: 'btn waves-effect'
                    },
                    confirm: {
                        label: '<?php echo e(get_string('yes')); ?>',
                        className: 'btn waves-effect'
                    }
                },
                callback: function (result) {
                    if(result){
                        $.ajax({
                            url: '<?php echo e(url('/company/agent/destroy')); ?>/'+id,
                            type: 'post',
                            data: {_token :token},
                            success:function(msg) {
                                selector.remove();
                                toastr.success(msg);
                            },
                            error:function(msg){
                                toastr.error(msg.responseJSON);
                            }
                        });
                    }
                }
            });
        });

        $('.upgrade-button').click(function(event){
            event.preventDefault();
            var id = $(this).data('id');
            var selector = $(this).parents('tr');
            var token = $('[name=_token]').val();
            bootbox.confirm({
                title: '<?php echo e(get_string('confirm_action')); ?>',
                message: '<?php echo e(get_string('upgrade_user_confirm')); ?>',
                onEscape: true,
                backdrop: true,
                buttons: {
                    cancel: {
                        label: '<?php echo e(get_string('no')); ?>',
                        className: 'btn waves-effect'
                    },
                    confirm: {
                        label: '<?php echo e(get_string('yes')); ?>',
                        className: 'btn waves-effect'
                    }
                },
                callback: function (result) {
                    if(result){
                        $.ajax({
                            url: '<?php echo e(url('/company/agent/upgrade')); ?>/'+id,
                            type: 'post',
                            data: {_token :token},
                            success:function(msg) {
                                toastr.success(msg);
                            },
                            error:function(msg){
                                toastr.error(msg.responseJSON);
                            }
                        });
                    }
                }
            });
        });
    });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.company', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>