

<?php $__env->startSection('title'); ?>
    <title><?php echo e(get_string('edit_property') . ' - ' . get_setting('site_name', 'site')); ?></title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php $__env->startSection('page_title'); ?>
    <h3 class="page-title mbot10"><?php echo e(get_string('edit_property')); ?></h3>
<?php $__env->stopSection(); ?>
<div class="col s12">
    <?php if(!$errors->isEmpty()): ?>
     <span class="wrong-error">* <?php echo e(get_string('validation_error')); ?></span>
    <?php endif; ?>
    <?php echo Form::open(['method' => 'patch', 'url' => route('agent.property.update', $property->id), 'files' => 'true']); ?>

    <div class="panel">
        <div class="panel-heading">
            <ul class="nav nav-tabs">
                <li class="tab active"><a href="#content-panel" data-toggle="tab"><?php echo e(get_string('content')); ?></a></li>
                    <li class="tab"><a href="#location-panel" data-toggle="tab"><?php echo e(get_string('location')); ?></a></li>
                    <li class="tab"><a href="#data-panel" data-toggle="tab"><?php echo e(get_string('data')); ?></a></li>
                    <li class="tab"><a href="#property-panel" data-toggle="tab"><?php echo e(get_string('property')); ?></a></li>
                    <li class="tab"><a href="#media-panel" data-toggle="tab"><?php echo e(get_string('media')); ?></a></li>
                    <!-- <li class="tab"><a href="#meta-panel" data-toggle="tab"><?php echo e(get_string('meta')); ?></a></li> -->
            </ul>
        </div>
        <div class="panel-body">
            <div class="tab-content">
                <div id="content-panel" class="tab-pane active">
                    <div class="panel">
                        <div class="panel-heading">
                            <ul class="nav nav-tabs">
                                <?php $__currentLoopData = $languages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $language): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                    <li class="tab <?php echo e($language->default ? 'active' : ''); ?>"><a href="#lang<?php echo e($language->id); ?>" data-parent="#content" data-toggle="tab"><img src="<?php echo e($language->flag); ?>"/><span><?php echo e($language->language); ?></span></a></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                            </ul>
                        </div>
                        <div class="panel-body">
                            <div class="tab-content">
                                <?php $__currentLoopData = $languages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $language): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                    <div id="lang<?php echo e($language->id); ?>" class="tab-pane <?php echo e($language->default ? 'active' : ''); ?>">
                                        <div class="col s12">
                                            <div class="form-group  <?php echo e($errors->has('name.'.$language->id.'') ? 'has-error' : ''); ?>">
                                                <?php echo e(Form::text('name['.$language->id.']',  $property->content($language->id)->name, ['class' => 'form-control', 'placeholder' => get_string('name')])); ?>

                                                <?php echo e(Form::label('name['.$language->id.']', get_string('name'))); ?>

                                                <?php if($errors->has('name.'.$language->id.'')): ?>
                                                    <span class="wrong-error">* <?php echo e($errors->first('name.'.$language->id.'')); ?></span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                        <div class="col s12">
                                            <?php echo e(Form::textarea('description['.$language->id.']', $property->content($language->id)->description, ['class' => 'hidden desc-content'])); ?>

                                            <?php if($errors->has('description.'.$language->id.'')): ?>
                                                <span class="wrong-error">* <?php echo e($errors->first('description.'.$language->id.'')); ?></span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                            </div>
                        </div>
                    </div>
                </div>
                <div id="location-panel" class="tab-pane">
                    <div class="col m4 s6">
                        <div class="form-group  <?php echo e($errors->has('country_id') ? 'has-error' : ''); ?>">
                            <?php echo e(Form::select('country_id', $countries, $property->country_id, ['class' => 'country-select form-control', 'placeholder' => get_string('country')])); ?>

                            <?php if($errors->has('country_id')): ?>
                                <span class="wrong-error">* <?php echo e($errors->first('country_id')); ?></span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="col m4 s6">
                        <div class="form-group  <?php echo e($errors->has('province_id') ? 'has-error' : ''); ?>">
                            <?php echo e(Form::select('province_id', $provinces, $property->province_id, ['class' => 'province-select form-control', 'placeholder' => get_string('province')])); ?>

                            <?php if($errors->has('province_id')): ?>
                                <span class="wrong-error">* <?php echo e($errors->first('province_id')); ?></span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="col m4 s6">
                        <div class="form-group  <?php echo e($errors->has('city_id') ? 'has-error' : ''); ?>">
                            <?php echo e(Form::select('city_id', $cities, $property->city_id, ['class' => 'city-select form-control', 'placeholder' => get_string('city')])); ?>

                            <?php if($errors->has('city_id')): ?>
                                <span class="wrong-error">* <?php echo e($errors->first('city_id')); ?></span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="col s12">
                        <div class="row mbot0">
                            <div class="col l6 m12 s12">
                                <div class="row mbot0">
                                    <div class="col l12 m12 s12">
                                        <div class="form-group  <?php echo e($errors->has('address') ? 'has-error' : ''); ?>">
                                            <?php echo e(Form::text('address', $property->address, ['class' => 'form-control', 'placeholder' => get_string('address')])); ?>

                                            <?php echo e(Form::label('address', get_string('address'))); ?>

                                            <?php if($errors->has('address')): ?>
                                                <span class="wrong-error">* <?php echo e($errors->first('address')); ?></span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="col l12 m12 s12">
                                        <div class="form-group  <?php echo e($errors->has('zip') ? 'has-error' : ''); ?>">
                                            <?php echo e(Form::text('zip', $property->zip, ['class' => 'form-control', 'placeholder' => get_string('zip')])); ?>

                                            <?php echo e(Form::label('zip', get_string('zip'))); ?>

                                            <?php if($errors->has('zip')): ?>
                                                <span class="wrong-error">* <?php echo e($errors->first('zip')); ?></span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="col l12 m12 s12">
                                        <div class="form-group">
                                            <?php echo e(Form::text('geo_lng', $property->geo_lng, ['class' => 'form-control', 'placeholder' => get_string('geo_lon'), 'readonly'])); ?>

                                            <?php echo e(Form::label('geo_lng', get_string('geo_lon'))); ?>

                                        </div>
                                    </div>
                                    <div class="col l12 m12 s12">
                                        <div class="form-group">
                                            <?php echo e(Form::text('geo_lat', $property->geo_lat, ['class' => 'form-control', 'placeholder' => get_string('geo_lat'), 'readonly'])); ?>

                                            <?php echo e(Form::label('geo_lat', get_string('geo_lat'))); ?>

                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col l6 m12 s12">
                                <div class="form-group  <?php echo e(($errors->has('location.geo_lon') || ($errors->has('location.geo_lon')))  ? 'has-error' : ''); ?>">
                                    <?php echo e(Form::text('marker', null, ['class' => 'form-control autocomplete', 'id' => 'address-map', 'placeholder' => get_string('drop_marker')])); ?>

                                    <?php echo e(Form::label('marker', get_string('drop_marker'))); ?>

                                    <?php if($errors->has('geo_lng') || $errors->has('geo_lat')): ?>
                                        <span class="wrong-error">* <?php echo e(get_string('google_address_required')); ?> </span>
                                    <?php endif; ?>
                                </div>
                                <div id="google-map">
                                </div>
                                <span class="field-info"><?php echo e(get_string('drag_marker')); ?></span>
                            </div>
                        </div>
                    </div>
                </div>
                <div id="media-panel" class="tab-pane">
                    <div class="col l12 m12 s12">
                        <div id="file-dropzone" class="dropzone">
                            <div class="dz-message"><?php echo e(get_string('upload_images')); ?><br/><i class="material-icons medium">cloud_upload</i>
                            </div>
                            <div class="fallback">
                            </div>
                        </div>
                    </div>
                    <div class="col s12">
                        <div class="form-group  <?php echo e($errors->has('video') ? 'has-error' : ''); ?>">
                            <?php echo e(Form::text('video', $property->video, ['class' => 'form-control', 'placeholder' => get_string('video_id')])); ?>

                            <?php echo e(Form::label('video', get_string('video_id'))); ?>

                            <?php if($errors->has('video')): ?>
                                <span class="wrong-error">* <?php echo e($errors->first('video')); ?></span>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="col s12">
                        <div class="input-group <?php echo e($errors->has('plans') ? 'has-error' : ''); ?>">
                            <label class="input-group-btn">
                            <span class="btn btn-primary waves-effect"><?php echo e(get_string('plans')); ?> <i class="material-icons small">add_circle</i>
                                <?php echo Form::file('plans[]', ['id' => 'plans', 'class' => 'hidden', 'multiple']); ?>

                            </span>
                            </label>
                            <input type="text" class="form-control" readonly>
                        </div>
                        <?php if($errors->has('plans')): ?>
                            <span class="wrong-error">* <?php echo e($errors->first('plans')); ?></span>
                        <?php endif; ?>
                        <span class="field-info"><?php echo e(get_string('select_plans')); ?></span>
                    </div>


                    <div class="hidden-fields hidden">
                    </div>
                </div>
                <div id="data-panel" class="tab-pane">
                    <div class="col s12 clearfix">
                        <h5 class="section-title"><?php echo e(get_string('general')); ?></h5>
                    </div>
                    <div class="col s6">
                        <div class="form-group  <?php echo e($errors->has('contract_type_id') ? 'has-error' : ''); ?>">
                            <?php echo e(Form::select('contract_type_id', $contract_types, $property->contract_type_id, ['class' => 'category-select form-control', 'placeholder' => get_string('contract_type')])); ?>

                            <?php if($errors->has('contract_type_id')): ?>
                                <span class="wrong-error">* <?php echo e($errors->first('contract_type_id')); ?></span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="col s6">
                        <div class="form-group  <?php echo e($errors->has('property_type_id') ? 'has-error' : ''); ?>">
                            <?php echo e(Form::select('property_type_id', $property_types, $property->property_type_id, ['class' => 'category-select form-control', 'placeholder' => get_string('property_type')])); ?>

                            <?php if($errors->has('property_type_id')): ?>
                                <span class="wrong-error">* <?php echo e($errors->first('property_type_id')); ?></span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <!-- <div class="col  s12 well checkbox-grid">
                        <p><?php echo e(get_string('paymentOptions')); ?></p>
                        <?php $__currentLoopData = $payment_options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $paymentOption): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                            <div class="col s2">
                                <div class="form-group">
                                    <input type="checkbox" name="payment_options[]" <?php if(old('payment_options') && in_array_r($paymentOption->id, old('payment_options'))): ?> checked <?php endif; ?> value="<?php echo e($paymentOption->id); ?>" class="filled-in primary-color" id="po-<?php echo e($paymentOption->id); ?>" />
                                    <label for="po-<?php echo e($paymentOption->id); ?>"></label>
                                    <span class="checkbox-label"><?php echo e($paymentOption->paymentOption[$default_language->id]); ?></span>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                    </div> -->
                    <div class="col  s12 well checkbox-grid">
                        <p><?php echo e(get_string('choose_features')); ?></p>
                        <?php $__currentLoopData = $features; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $feature): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                            <div class="col s2">
                                <div class="form-group">
                                    <input type="checkbox" name="features[]" <?php if((old('features') && in_array_r($feature->id, old('features'))) || ($property->features && in_array($feature->id, $property->features))): ?> checked <?php endif; ?> value="<?php echo e($feature->id); ?>" class="filled-in primary-color" id="<?php echo e($feature->id); ?>" />
                                    <label for="<?php echo e($feature->id); ?>"></label>
                                    <span class="checkbox-label"><?php echo e($feature->feature[$default_language->id]); ?></span>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                    </div>
                    <div class="col  s12 well checkbox-grid">
                        <p><?php echo e(get_string('views')); ?></p>
                        <?php $__currentLoopData = $views; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $view): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                            <div class="col s2">
                                <div class="form-group">
                                    <input type="checkbox" name="views[]" <?php if((old('views') && in_array_r($view->id, old('views'))) || ($property->views && in_array($view->id, $property->views))): ?> checked <?php endif; ?> value="<?php echo e($view->id); ?>" class="filled-in primary-color" id="view-<?php echo e($view->id); ?>" />
                                    <label for="view-<?php echo e($view->id); ?>"></label>
                                    <span class="checkbox-label"><?php echo e($view->view[$default_language->id]); ?></span>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                    </div>
                    <div class="col  s12 well checkbox-grid">
                        <p><?php echo e(get_string('orientations')); ?></p>
                        <?php $__currentLoopData = $orientations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $orientation): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                            <div class="col s2">
                                <div class="form-group">
                                    <input type="checkbox" name="orientations[]" <?php if((old('orientations') && in_array_r($orientation->id, old('orientations'))) || ($property->orientations && in_array($orientation->id, $property->orientations))): ?> checked <?php endif; ?>  value="<?php echo e($orientation->id); ?>" class="filled-in primary-color" id="orientation-<?php echo e($orientation->id); ?>" />
                                    <label for="orientation-<?php echo e($orientation->id); ?>"></label>
                                    <span class="checkbox-label"><?php echo e($orientation->orientation[$default_language->id]); ?></span>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                    </div>
                    <div class="col s6">
                        <div class="form-group  <?php echo e($errors->has('kitchen_appliances') ? 'has-error' : ''); ?>">
                            <?php echo e(Form::select('kitchen_appliances', [0 => get_string('no'), 1 => get_string('yes')], $property->kitchen_appliances, ['class' => 'category-select form-control', 'placeholder' => get_string('kitchen_appliances')])); ?>

                            <?php if($errors->has('kitchen_appliances')): ?>
                                <span class="wrong-error">* <?php echo e($errors->first('kitchen_appliances')); ?></span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="col s6">
                        <div class="form-group  <?php echo e($errors->has('built_in_wardrobe') ? 'has-error' : ''); ?>">
                            <?php echo e(Form::select('built_in_wardrobe', [0 => get_string('no'), 1 => get_string('yes')], $property->built_in_wardrobe, ['class' => 'category-select form-control', 'placeholder' => get_string('built_in_wardrobe')])); ?>

                            <?php if($errors->has('built_in_wardrobe')): ?>
                                <span class="wrong-error">* <?php echo e($errors->first('built_in_wardrobe')); ?></span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="col  s12 well checkbox-grid">
                        <p><?php echo e(get_string('kitchenMaterials')); ?></p>
                        <?php $__currentLoopData = $kitchen_materials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kitchen_material): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                            <div class="col s2">
                                <div class="form-group">
                                    <input type="checkbox" name="kitchen_materials[]" <?php if((old('kitchen_materials') && in_array_r($kitchen_material->id, old('kitchen_materials'))) || ($property->kitchen_materials && in_array($kitchen_material->id, $property->kitchen_materials))): ?> checked <?php endif; ?>  value="<?php echo e($kitchen_material->id); ?>" class="filled-in primary-color" id="km-<?php echo e($kitchen_material->id); ?>" />
                                    <label for="km-<?php echo e($kitchen_material->id); ?>"></label>
                                    <span class="checkbox-label"><?php echo e($kitchen_material->kitchenMaterial[$default_language->id]); ?></span>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                    </div>
                    <div class="col  s12 well checkbox-grid">
                        <p><?php echo e(get_string('wallMaterials')); ?></p>
                        <?php $__currentLoopData = $wall_materials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $wall_material): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                            <div class="col s2">
                                <div class="form-group">
                                    <input type="checkbox" name="wall_materials[]" <?php if((old('wall_materials') && in_array_r($wall_material->id, old('wall_materials'))) || ($property->wall_materials && in_array($wall_material->id, $property->wall_materials))): ?> checked <?php endif; ?> value="<?php echo e($wall_material->id); ?>" class="filled-in primary-color" id="wm-<?php echo e($wall_material->id); ?>" />
                                    <label for="wm-<?php echo e($wall_material->id); ?>"></label>
                                    <span class="checkbox-label"><?php echo e($wall_material->wallMaterial[$default_language->id]); ?></span>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                    </div>
                    <div class="col  s12 well checkbox-grid">
                        <p><?php echo e(get_string('flooringMaterials')); ?></p>
                        <?php $__currentLoopData = $flooring_materials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $flooring_material): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                            <div class="col s2">
                                <div class="form-group">
                                    <input type="checkbox" name="flooring_materials[]" <?php if((old('flooring_materials') && in_array_r($flooring_material->id, old('flooring_materials'))) || ($property->flooring_materials && in_array($flooring_material->id, $property->flooring_materials))): ?> checked <?php endif; ?> value="<?php echo e($flooring_material->id); ?>" class="filled-in primary-color" id="fm-<?php echo e($flooring_material->id); ?>" />
                                    <label for="fm-<?php echo e($flooring_material->id); ?>"></label>
                                    <span class="checkbox-label"><?php echo e($flooring_material->flooringMaterial[$default_language->id]); ?></span>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                    </div>
                </div>
                <div id="property-panel" class="tab-pane">
                    <div class="col s12 clearfix">
                        <h5 class="section-title"><?php echo e(get_string('property_info')); ?></h5>
                    </div>
                    <div class="col l6 m6 s12">
                        <div class="form-group  <?php echo e($errors->has('area.feet') ? 'has-error' : ''); ?>">
                            <?php echo e(Form::text('area[feet]', $property->area['feet'], ['class' => 'feet-area form-control', 'placeholder' => get_string('property_size')])); ?>

                            <?php echo e(Form::label('area[feet]', get_string('property_size').' feet')); ?>

                            <?php if($errors->has('area.feet')): ?>
                                <span class="wrong-error">* <?php echo e($errors->first('area.feet')); ?></span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="col l6 m6 s12">
                        <div class="form-group  <?php echo e($errors->has('area.m2') ? 'has-error' : ''); ?>">
                            <?php echo e(Form::text('area[m2]', $property->area['m2'], ['class' => 'm2-area form-control', 'placeholder' => get_string('property_size')])); ?>

                            <?php echo e(Form::label('area[m2]', get_string('property_size').' m2')); ?>

                            <?php if($errors->has('area.m2')): ?>
                                <span class="wrong-error">* <?php echo e($errors->first('area.m2')); ?></span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="col l6 m6 s12">
                        <div class="form-group  <?php echo e($errors->has('property_info.rooms') ? 'has-error' : ''); ?>">
                            <?php echo e(Form::text('property_info[rooms]', $property->property_info['rooms'], ['class' => 'form-control', 'placeholder' => get_string('property_rooms')])); ?>

                            <?php echo e(Form::label('property_info[rooms]', get_string('property_rooms'))); ?>

                            <?php if($errors->has('property_info.rooms')): ?>
                                <span class="wrong-error">* <?php echo e($errors->first('property_info.rooms')); ?></span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="col l6 m6 s12">
                        <div class="form-group  <?php echo e($errors->has('property_info.bedrooms') ? 'has-error' : ''); ?>">
                            <?php echo e(Form::text('property_info[bedrooms]', $property->property_info['bedrooms'], ['class' => 'form-control', 'placeholder' => get_string('property_bedrooms')])); ?>

                            <?php echo e(Form::label('property_info[bedrooms]', get_string('property_bedrooms'))); ?>

                            <?php if($errors->has('property_info.bedrooms')): ?>
                                <span class="wrong-error">* <?php echo e($errors->first('property_info.bedrooms')); ?></span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="col l6 m6 s12">
                        <div class="form-group  <?php echo e($errors->has('property_info.bathrooms') ? 'has-error' : ''); ?>">
                            <?php echo e(Form::text('property_info[bathrooms]', $property->property_info['bathrooms'], ['class' => 'form-control', 'placeholder' => get_string('property_bathrooms')])); ?>

                            <?php echo e(Form::label('property_info[bathrooms]', get_string('property_bathrooms'))); ?>

                            <?php if($errors->has('property_info.bathrooms')): ?>
                                <span class="wrong-error">* <?php echo e($errors->first('property_info.bathrooms')); ?></span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="col l6 m6 s12">
                        <div class="form-group  <?php echo e($errors->has('property_info.garages') ? 'has-error' : ''); ?>">
                            <?php echo e(Form::text('property_info[garages]', $property->property_info['garages'], ['class' => 'form-control', 'placeholder' => get_string('property_garages')])); ?>

                            <?php echo e(Form::label('property_info[garages]', get_string('property_garages'))); ?>

                            <?php if($errors->has('property_info.garages')): ?>
                                <span class="wrong-error">* <?php echo e($errors->first('property_info.garages')); ?></span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="col l6 m6 s12">
                        <div class="form-group  <?php echo e($errors->has('year_built') ? 'has-error' : ''); ?>">
                            <?php echo e(Form::text('year_built', $property->year_built, ['class' => 'form-control', 'placeholder' => get_string('year_built')])); ?>

                            <?php echo e(Form::label('year_built', get_string('year_built'))); ?>

                            <?php if($errors->has('year_built')): ?>
                                <span class="wrong-error">* <?php echo e($errors->first('year_built')); ?></span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="col s12 clearfix">
                        <h5 class="section-title"><?php echo e(get_string('property_prices')); ?></h5>
                    </div>
                    <div class="col l6 m6 s12">
                        <div class="form-group  <?php echo e($errors->has('price') ? 'has-error' : ''); ?>">
                            <?php echo e(Form::text('price', $property->price, ['class' => 'form-control', 'placeholder' => get_string('price')])); ?>

                            <?php echo e(Form::label('price', get_string('price'))); ?>

                            <?php if($errors->has('price')): ?>
                                <span class="wrong-error">* <?php echo e($errors->first('price')); ?></span>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col clearfix s12 mtop10">
                <div class="form-group">
                    <button class="btn waves-effect" type="submit" name="action"><?php echo e(get_string('update')); ?></button>
                    <a href="<?php echo e(route('agent.property.index')); ?>" class="btn waves-effect"><?php echo e(get_string('property_all')); ?></a>
                </div>
            </div>
            <?php echo e(Form::hidden('agent_id', Auth::user()->id)); ?>

            <?php echo e(Form::hidden('company_id', $property->company_id ?: 0)); ?>

            <?php echo Form::close(); ?>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
    <script src="https://maps.googleapis.com/maps/api/js?key=<?php echo e(get_setting('google_map_key', 'site')); ?>&libraries=places"></script>
    <script>
        $(document).ready(function(){
            $('.desc-content').summernote({
                height: 200,
                maxwidth: false,
                minwidth: false,
                placeholder: '<?php echo e(get_string('enter_property_content')); ?>',
                disableDragAndDrop: true,
                toolbar: [
                    ["style", ["style"]],
                    ["font", ["bold", "underline", "clear"]],
                    ["color", ["color"]],
                    ["para", ["ul", "ol", "paragraph"]],
                ],callbacks: {
                    onPaste: function (e) {
                        var bufferText = ((e.originalEvent || e).clipboardData || window.clipboardData).getData('Text');
                        e.preventDefault();
                        document.execCommand('insertText', false, bufferText);
                    }
                }
            });

            $(this).on('input', '.feet-area', function() {
                if($(this).val() != '' ) $('.m2-area').val(parseFloat($(this).val()) * 0.092903);
                if($(this).val() == '' ) $('.m2-area').val('');
            });

            $(this).on('input', '.m2-area', function() {
                if($(this).val() != '' ) $('.feet-area').val(parseFloat($(this).val()) * 10.7639);
                if($(this).val() == '' ) $('.feet-area').val('');
            });

            $(this).on('click change', '.country-select', function() {
                if(!(this.selectedIndex == -1)) getProvincesByCountry($(this).val());
            });

            $(this).on('click change', '.province-select', function() {
                if(!(this.selectedIndex == -1)) getCitiesByProvince($(this).val());                    
            });
        });

        function getProvincesByCountry(id) {
            $.ajax({
                url: '<?php echo e(route('agent_property_get_provinces')); ?>',
                type: 'post',
                data: {_token: $('[name="_token"]').val(), country_id: id},
                success: function (data){
                    var html = '<option value=""><?php echo e(get_string('province')); ?></option>';
                    $.each(data, function(key, value){
                        html += '<option value="' + key + '">'+ value +'</option>';
                    });

                    $('.province-select').html(html);
                }   
            });
        }

        function getCitiesByProvince(id) {
            $.ajax({
                url: '<?php echo e(route('agent_property_get_cities')); ?>',
                type: 'post',
                data: {_token: $('[name="_token"]').val(), province_id: id},
                success: function (data){
                    var html = '<option value=""><?php echo e(get_string('city')); ?></option>';
                    $.each(data, function(key, value){
                        html += '<option value="' + key + '">'+ value +'</option>';
                    });

                    $('.city-select').html(html);
                }   
            });
        }

        Dropzone.autoDiscover = false;
        $(document).ready(function(){
            var fileDropzone = $('#file-dropzone');
            $(fileDropzone).dropzone({
                url: '<?php echo e(url('/image_handler/upload')); ?>',
                paramsName: 'image',
                params: {_token: $('[name=_token]').val()},
                maxFilesize: 100,
                uploadMultiple: false,
                addRemoveLinks: true,
                maxfilesize: 1,
                parallelUploads: 1,
                maxFiles: 6,
                init: function() {

                    <?php if($property->images): ?>
                        <?php $__currentLoopData = $property->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                            var mockFile = { name: '<?php echo e($image->image); ?>', size: 100000 };
                            this.emit("addedfile", mockFile);
                            this.createThumbnailFromUrl(mockFile, '/images/data/<?php echo e($image->image); ?>');
                            this.emit("success", mockFile);
                        $('.hidden-fields').append('<input type="hidden" name="images[]" value="<?php echo e($image->image); ?>">');
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                    <?php endif; ?>

                    this.on('success', function(file, json) {
                        var selector = file._removeLink;
                        $(selector).attr('data-dz-remove', json.data);
                        $('.hidden-fields').append('<input type="hidden" name="images[]" value="'+ json.data +'">');
                    });

                    this.on('addedfile', function(file) {

                    });

                    this.on("removedfile", function(file) {
                        var selector = file._removeLink;
                        var data = $(selector).attr('data-dz-remove');
                        if(!data){
                            data = file.name;
                            $.ajax({
                                type: 'POST',
                                url: '<?php echo e(url('/image_handler/deleteBase')); ?>',
                                data: {data: data, _token: $('[name=_token]').val(), type: 'property', id: '<?php echo e($property->id); ?>'},
                                dataType: 'html',
                                success: function(msg){
                                    $('.hidden-fields').find('[value="'+ data +'"]').remove();
                                }
                            });
                        }else{
                            $.ajax({
                                type: 'POST',
                                url: '<?php echo e(url('/image_handler/delete')); ?>',
                                data: {data: data, _token: $('[name=_token]').val()},
                                dataType: 'html',
                                success: function(msg){
                                    $('.hidden-fields').find('[value="'+ data +'"]').remove();
                                }
                            });
                        }
                    });
                }
            });
        });

        // Google Map
        $(document).ready(function() {
            if(typeof google !== 'undefined' && google){
                var map = new google.maps.Map(document.getElementById('google-map'), {
                    center:{
                        lat: <?php echo e($property->geo_lng); ?>,
                        lng: <?php echo e($property->geo_lat); ?>

                    },
                    zoom: 10
                });
                var marker = new google.maps.Marker({
                    position: {
                        lat: <?php echo e($property->geo_lng); ?>,
                        lng: <?php echo e($property->geo_lat); ?>

                    },
                    map: map,
                    draggable: true
                });
                var infowindow = new google.maps.InfoWindow();
                var searchBox = document.getElementById('address-map');
                var autocomplete = new google.maps.places.Autocomplete(searchBox);

                autocomplete.bindTo('bounds', map);
                autocomplete.addListener('place_changed', function() {
                    infowindow.close();
                    marker.setVisible(false);
                    var place = autocomplete.getPlace();
                    if (!place.geometry) {
                        return;
                    }

                    // If the place has a geometry, then present it on a map.
                    if (place.geometry.viewport) {
                        map.fitBounds(place.geometry.viewport);
                    } else {
                        map.setCenter(place.geometry.location);
                        map.setZoom(15);
                    }

                    marker.setPosition(place.geometry.location);
                    marker.setVisible(true);

                    var address = '';
                    if (place.address_components) {
                        address = [
                            (place.address_components[0] && place.address_components[0].short_name || ''),
                            (place.address_components[1] && place.address_components[1].short_name || ''),
                            (place.address_components[2] && place.address_components[2].short_name || '')
                        ].join(' ');
                    }

                    infowindow.setContent('<div><strong>' + place.name + '</strong><br>' + address);
                    infowindow.open(map, marker);
                });

                google.maps.event.addListener(marker, 'position_changed', function () {
                    var lat = marker.getPosition().lat();
                    var lng = marker.getPosition().lng();
                    $('[name="geo_lng"]').val(lat);
                    $('[name="geo_lat"]').val(lng);
                });
                $('a[href$="location-panel"]').click(function(){
                    var currCenter = map.getCenter();
                    setTimeout(function(){
                        google.maps.event.trigger($("#google-map")[0], 'resize');
                        map.setCenter(currCenter);
                    }, 50);
                });
            }
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.agent', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>