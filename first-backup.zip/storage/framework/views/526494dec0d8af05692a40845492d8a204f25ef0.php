

<?php $__env->startSection('title'); ?>
    <title><?php echo e(get_string('adType') . ' - ' . get_setting('site_name', 'site')); ?></title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php $__env->startSection('page_title'); ?>
    <h3 class="page-title mbot10"><?php echo e(get_string('adType')); ?></h3>
<?php $__env->stopSection(); ?>
<div class="panel col s12">
    <div class="row">
        <div class="panel-heading">
            <ul class="nav nav-tabs">
                <li class="tab active"><a data-toggle="tab" href="#general_settings"><?php echo e(get_string('adType')); ?></a></li>
            </ul>
        </div>
        <?php echo Form::open(['url' => route('admin_adTypes_update'), 'method' => 'post', 'id' => "adType", 'class' => 'table-responsive']); ?>

        <div class="panel-body"> 
            <div class="tab-content">
                <div id="general_settings" class="tab-pane active">

                    
                    <?php $__currentLoopData = $adTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $adType): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                    <div class="col s12">
                        <h3 class="page-title clearfix"><?php echo e(get_string($adType->key)); ?></h3>
                    </div>
                    <div class="col m3 s6">
                        <div class="form-group  <?php echo e($errors->has('weekly') ? 'has-error' : ''); ?>">
                            <?php echo e(Form::number($adType->id.'[weekly]', $adType->weekly, ['class' => 'form-control', 'required', 'min' => 0, 'placeholder' => get_string('weekly').' - '.get_string('points')])); ?>

                            <?php echo e(Form::label('weekly', get_string('weekly').' - '.get_string('points'))); ?>

                            <?php if($errors->has('weekly')): ?>
                                <span class="wrong-error">* <?php echo e($errors->first('weekly')); ?></span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="col m3 s6">
                        <div class="form-group  <?php echo e($errors->has('monthly') ? 'has-error' : ''); ?>">
                            <?php echo e(Form::number($adType->id.'[monthly]', $adType->monthly, ['class' => 'form-control', 'required', 'min' => 0, 'placeholder' => get_string('monthly').' - '.get_string('points')])); ?>

                            <?php echo e(Form::label('monthly', get_string('monthly').' - '.get_string('points'))); ?>

                            <?php if($errors->has('monthly')): ?>
                                <span class="wrong-error">* <?php echo e($errors->first('monthly')); ?></span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="col m3 s6">
                        <div class="form-group  <?php echo e($errors->has('yearly') ? 'has-error' : ''); ?>">
                            <?php echo e(Form::number($adType->id.'[yearly]', $adType->yearly, ['class' => 'form-control', 'required', 'min' => 0, 'placeholder' => get_string('yearly').' - '.get_string('points')])); ?>

                            <?php echo e(Form::label('yearly', get_string('yearly').' - '.get_string('points'))); ?>

                            <?php if($errors->has('yearly')): ?>
                                <span class="wrong-error">* <?php echo e($errors->first('yearly')); ?></span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="col m3 s6">
                        <div class="form-group  <?php echo e($errors->has('maximum') ? 'has-error' : ''); ?>">
                            <?php echo e(Form::number($adType->id.'[maximum]', $adType->maximum, ['class' => 'form-control', 'required', 'min' => 0, 'placeholder' => get_string('maximum')])); ?>

                            <?php echo e(Form::label('maximum', get_string('maximum'))); ?>

                            <?php if($errors->has('maximum')): ?>
                                <span class="wrong-error">* <?php echo e($errors->first('maximum')); ?></span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>

                </div>
            </div>
            <div class="col clearfix l4 m4 s12 mtop10">
                <div class="form-group">
                    <button class="btn waves-effect" type="submit" name="action"><?php echo e(get_string('update')); ?></button></div>
                </div>
            </div>
        <?php echo Form::close(); ?>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>