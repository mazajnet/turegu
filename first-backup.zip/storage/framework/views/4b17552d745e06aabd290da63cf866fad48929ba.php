

<?php $__env->startSection('title'); ?>
<title><?php echo e(get_string('dashboard') . ' - ' . get_setting('site_name', 'site')); ?></title>
<?php $__env->stopSection(); ?>

    <?php $__env->startSection('page_title'); ?>
        <h3 class="page-title mbot10"><?php echo e(get_string('dashboard')); ?></h3>
    <?php $__env->stopSection(); ?>
    <?php $__env->startSection('content'); ?>
        <div class="row mbot0">
            <?php if(Session::has('payment_status')): ?> <?php $status = Session::get('payment_status'); ?>
                <div class="col s12">
                    <div class="col s12 text-centered">
                        <h5 class="<?php if(!$status['status']): ?> color-red <?php else: ?> color-primary <?php endif; ?>"><?php echo e($status['msg']); ?></h5>
                    </div>
                </div>
            <?php endif; ?>
            <div class="col s12">
                <div class="col l3 m6 s12">
                    <div class="card">
                        <div class="card-content no-padding">
                            <div class="blue-card card-stats-body waves-effect">
                                <div class="stats-icon right-align">
                                    <i class="medium material-icons">home</i>
                                </div>
                                <div class="stats-text left-align">
                                    <strong class="counter"><?php echo e($data['properties']); ?></strong><br>
                                    <span><?php echo e(get_string('properties')); ?></span>
                                </div>
                            </div>
                        </div><!--end .card-body -->
                    </div>
                </div>
                <div class="col l3 m6 s12">
                    <div class="card">
                        <div class="card-content no-padding">
                            <div class="blue-card card-stats-body waves-effect">
                                <div class="stats-icon right-align">
                                    <i class="medium material-icons">home</i>
                                </div>
                                <div class="stats-text left-align">
                                    <strong class="counter"><?php echo e($data['projects']); ?></strong><br>
                                    <span><?php echo e(get_string('projects')); ?></span>
                                </div>
                            </div>
                        </div><!--end .card-body -->
                    </div>
                </div>
                <div class="col l3 m6 s12">
                    <div class="card">
                        <div class="card-content no-padding">
                            <div class="blue-card card-stats-body waves-effect">
                                <div class="stats-icon right-align">
                                    <i class="medium material-icons">business_center</i>
                                </div>
                                <div class="stats-text left-align">
                                    <strong class="counter"><?php echo e($data['view_tour']); ?></strong><br>
                                    <span><?php echo e(get_string('view_tours')); ?></span>
                                </div>
                            </div>
                        </div><!--end .card-body -->
                    </div>
                </div>
                <div class="col l3 m6 s12">
                    <div class="card">
                        <div class="card-content no-padding">
                            <div class="blue-card card-stats-body waves-effect">
                                <div class="stats-icon right-align">
                                    <i class="medium material-icons">business_center</i>
                                </div>
                                <div class="stats-text left-align">
                                    <strong class="counter"><?php echo e($data['private_tour']); ?></strong><br>
                                    <span><?php echo e(get_string('private_tours')); ?></span>
                                </div>
                            </div>
                        </div><!--end .card-body -->
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php $__env->stopSection(); ?>
<?php $__env->startSection('footer'); ?>
    <script>
        $(document).ready(function() {
            $('.counter').counterUp({
                delay: 10,
                time: 1000
            });
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.agent', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>