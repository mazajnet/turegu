

<?php $__env->startSection('title'); ?>
    <title><?php echo e(get_string('edit_project') . ' - ' . get_setting('site_name', 'site')); ?></title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('style'); ?>
    <link href="<?php echo e(URL::asset('assets/css/plugins/backend_jquery-ui.min.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<?php $__env->startSection('page_title'); ?>
    <h3 class="page-title mbot10"><?php echo e(get_string('edit_project')); ?></h3>
<?php $__env->stopSection(); ?>
<div class="col s12">
    <?php if(!$errors->isEmpty()): ?>
        <span class="wrong-error">* <?php echo e(get_string('validation_error')); ?></span>
    <?php endif; ?>
    <?php echo Form::open(['method' => 'patch', 'url' => route('company.project.update', $project->id), 'files' => 'true']); ?>

    <div class="panel">
        <div class="panel-heading">
            <ul class="nav nav-tabs">
               <li class="tab active"><a href="#content-panel" data-toggle="tab"><?php echo e(get_string('content')); ?></a></li>
                <li class="tab"><a href="#location-panel" data-toggle="tab"><?php echo e(get_string('location')); ?></a></li>
                <li class="tab"><a href="#data-panel" data-toggle="tab"><?php echo e(get_string('data')); ?></a></li>
                <li class="tab"><a href="#media-panel" data-toggle="tab"><?php echo e(get_string('media')); ?></a></li>
            </ul>
        </div>
        <div class="panel-body">
            <div class="tab-content">
                <div id="content-panel" class="tab-pane active">
                    <div class="panel">
                        <div class="panel-heading">
                            <ul class="nav nav-tabs">
                                <?php $__currentLoopData = $languages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $language): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                    <li class="tab <?php echo e($language->default ? 'active' : ''); ?>"><a href="#lang<?php echo e($language->id); ?>" data-parent="#content" data-toggle="tab"><img src="<?php echo e($language->flag); ?>"/><span><?php echo e($language->language); ?></span></a></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                            </ul>
                        </div>
                        <div class="panel-body">
                            <div class="tab-content">
                                <?php $__currentLoopData = $languages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $language): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                    <div id="lang<?php echo e($language->id); ?>" class="tab-pane <?php echo e($language->default ? 'active' : ''); ?>">
                                        <div class="col s12">
                                            <div class="form-group  <?php echo e($errors->has('name.'.$language->id.'') ? 'has-error' : ''); ?>">
                                                <?php echo e(Form::text('name['.$language->id.']',  $project->content($language->id)->name, ['class' => 'form-control', 'placeholder' => get_string('name')])); ?>

                                                <?php echo e(Form::label('name['.$language->id.']', get_string('name'))); ?>

                                                <?php if($errors->has('name.'.$language->id.'')): ?>
                                                    <span class="wrong-error">* <?php echo e($errors->first('name.'.$language->id.'')); ?></span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                        <div class="col s12">
                                            <?php echo e(Form::textarea('description['.$language->id.']', $project->content($language->id)->description, ['class' => 'hidden desc-content'])); ?>

                                            <?php if($errors->has('description.'.$language->id.'')): ?>
                                                <span class="wrong-error">* <?php echo e($errors->first('description.'.$language->id.'')); ?></span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                            </div>
                        </div>
                    </div>
                </div>
                <div id="location-panel" class="tab-pane">
                    <div class="col m4 s6">
                        <div class="form-group  <?php echo e($errors->has('country_id') ? 'has-error' : ''); ?>">
                            <?php echo e(Form::select('country_id', $countries, $project->country_id, ['class' => 'country-select form-control', 'placeholder' => get_string('country')])); ?>

                            <?php if($errors->has('country_id')): ?>
                                <span class="wrong-error">* <?php echo e($errors->first('country_id')); ?></span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="col m4 s6">
                        <div class="form-group  <?php echo e($errors->has('province_id') ? 'has-error' : ''); ?>">
                            <?php echo e(Form::select('province_id', $provinces, $project->province_id, ['class' => 'province-select form-control', 'placeholder' => get_string('province')])); ?>

                            <?php if($errors->has('province_id')): ?>
                                <span class="wrong-error">* <?php echo e($errors->first('province_id')); ?></span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="col m4 s6">
                        <div class="form-group  <?php echo e($errors->has('city_id') ? 'has-error' : ''); ?>">
                            <?php echo e(Form::select('city_id', $cities, $project->city_id, ['class' => 'city-select form-control', 'placeholder' => get_string('city')])); ?>

                            <?php if($errors->has('city_id')): ?>
                                <span class="wrong-error">* <?php echo e($errors->first('city_id')); ?></span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="col s12">
                        <div class="row mbot0">
                            <div class="col l6 m12 s12">
                                <div class="row mbot0">
                                    <div class="col l12 m12 s12">
                                        <div class="form-group  <?php echo e($errors->has('address') ? 'has-error' : ''); ?>">
                                            <?php echo e(Form::text('address', $project->address, ['class' => 'form-control', 'placeholder' => get_string('address')])); ?>

                                            <?php echo e(Form::label('address', get_string('address'))); ?>

                                            <?php if($errors->has('address')): ?>
                                                <span class="wrong-error">* <?php echo e($errors->first('address')); ?></span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="col l12 m12 s12">
                                        <div class="form-group  <?php echo e($errors->has('zip') ? 'has-error' : ''); ?>">
                                            <?php echo e(Form::text('zip', $project->zip, ['class' => 'form-control', 'placeholder' => get_string('zip')])); ?>

                                            <?php echo e(Form::label('zip', get_string('zip'))); ?>

                                            <?php if($errors->has('zip')): ?>
                                                <span class="wrong-error">* <?php echo e($errors->first('zip')); ?></span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="col l12 m12 s12">
                                        <div class="form-group">
                                            <?php echo e(Form::text('geo_lng', $project->geo_lng, ['class' => 'form-control', 'placeholder' => get_string('geo_lon'), 'readonly'])); ?>

                                            <?php echo e(Form::label('geo_lng', get_string('geo_lon'))); ?>

                                        </div>
                                    </div>
                                    <div class="col l12 m12 s12">
                                        <div class="form-group">
                                            <?php echo e(Form::text('geo_lat', $project->geo_lat, ['class' => 'form-control', 'placeholder' => get_string('geo_lat'), 'readonly'])); ?>

                                            <?php echo e(Form::label('geo_lat', get_string('geo_lat'))); ?>

                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col l6 m12 s12">
                                <div class="form-group  <?php echo e(($errors->has('location.geo_lon') || ($errors->has('location.geo_lon')))  ? 'has-error' : ''); ?>">
                                    <?php echo e(Form::text('marker', null, ['class' => 'form-control autocomplete', 'id' => 'address-map', 'placeholder' => get_string('drop_marker')])); ?>

                                    <?php echo e(Form::label('marker', get_string('drop_marker'))); ?>

                                    <?php if($errors->has('geo_lng') || $errors->has('geo_lat')): ?>
                                        <span class="wrong-error">* <?php echo e(get_string('google_address_required')); ?> </span>
                                    <?php endif; ?>
                                </div>
                                <div id="google-map">
                                </div>
                                <span class="field-info"><?php echo e(get_string('drag_marker')); ?></span>
                            </div>
                        </div>
                    </div>
                </div>
                <div id="media-panel" class="tab-pane">
                    <div class="col l12 m12 s12">
                        <div id="file-dropzone" class="dropzone">
                            <div class="dz-message"><?php echo e(get_string('upload_images')); ?><br/><i class="material-icons medium">cloud_upload</i>
                            </div>
                            <div class="fallback">
                            </div>
                        </div>
                    </div>

                    <div class="col s12">
                        <div class="form-group  <?php echo e($errors->has('video') ? 'has-error' : ''); ?>">
                            <?php echo e(Form::text('video', $project->video, ['class' => 'form-control', 'placeholder' => get_string('video_id')])); ?>

                            <?php echo e(Form::label('video', get_string('video_id'))); ?>

                            <?php if($errors->has('video')): ?>
                                <span class="wrong-error">* <?php echo e($errors->first('video')); ?></span>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="col l6 m6 s12">
                        <div class="input-group <?php echo e($errors->has('image') ? 'has-error' : ''); ?>">
                            <label class="input-group-btn">
                            <span class="btn btn-primary waves-effect"><?php echo e(get_string('logo')); ?> <i class="material-icons small">add_circle</i>
                                <?php echo Form::file('image', ['id' => 'image', 'class' => 'hidden']); ?>

                            </span>
                            </label>
                            <input type="text" class="form-control" readonly>
                        </div>
                        <?php if($errors->has('image')): ?>
                            <span class="wrong-error">* <?php echo e($errors->first('image')); ?></span>
                        <?php endif; ?>
                        <span class="field-info"><?php echo e(get_string('min_dimension_360')); ?></span>
                    </div>

                    <div class="hidden-fields hidden">
                    </div>
                </div>
                <div id="data-panel" class="tab-pane">
                    <div class="col s6">
                        <div class="form-group  <?php echo e($errors->has('project_type_id') ? 'has-error' : ''); ?>">
                            <?php echo e(Form::select('project_type_id', $project_types, $project->project_type_id, ['class' => 'category-select form-control', 'placeholder' => get_string('project_types')])); ?>

                            <?php echo e(Form::label('project_type_id', get_string('project_types'))); ?>

                            <?php if($errors->has('project_type_id')): ?>
                                <span class="wrong-error">* <?php echo e($errors->first('project_type_id')); ?></span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="col s6">
                        <div class="form-group  <?php echo e($errors->has('number_of_units') ? 'has-error' : ''); ?>">
                            <?php echo e(Form::number('number_of_units', $project->number_of_units, ['class' => 'category-select form-control', 'min' => 0, 'step' => 1, 'placeholder' => get_string('number_of_units')])); ?>

                            <?php echo e(Form::label('number_of_units', get_string('number_of_units'))); ?>

                            <?php if($errors->has('number_of_units')): ?>
                                <span class="wrong-error">* <?php echo e($errors->first('number_of_units')); ?></span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="col s6">
                        <div class="form-group  <?php echo e($errors->has('prices.min') ? 'has-error' : ''); ?>">
                            <?php echo e(Form::number('prices[min]', $project->prices['min'], ['class' => 'category-select form-control', 'min' => 0, 'step' => 1, 'placeholder' => get_string('price').' min'])); ?>

                            <?php echo e(Form::label('prices[min]', get_string('price') .' min')); ?>

                            <?php if($errors->has('prices.min')): ?>
                                <span class="wrong-error">* <?php echo e($errors->first('prices.min')); ?></span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="col s6">
                        <div class="form-group  <?php echo e($errors->has('prices.max') ? 'has-error' : ''); ?>">
                            <?php echo e(Form::number('prices[max]', $project->prices['max'], ['class' => 'category-select form-control', 'min' => 0, 'step' => 1, 'placeholder' => get_string('price').' max'])); ?>

                            <?php echo e(Form::label('prices[max]', get_string('price') .' max')); ?>

                            <?php if($errors->has('prices.max')): ?>
                                <span class="wrong-error">* <?php echo e($errors->first('prices.max')); ?></span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="col s6">
                        <div class="form-group  <?php echo e($errors->has('developer') ? 'has-error' : ''); ?>">
                            <?php echo e(Form::text('developer', $project->developer, ['class' => 'category-select form-control', 'placeholder' => get_string('developer')])); ?>

                            <?php echo e(Form::label('developer', get_string('developer'))); ?>

                            <?php if($errors->has('developer')): ?>
                                <span class="wrong-error">* <?php echo e($errors->first('developer')); ?></span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="col s6 backend-datepicker">
                        <div class="form-group  <?php echo e($errors->has('delivery_date') ? 'has-error' : ''); ?>">
                            <?php echo e(Form::text('delivery_date', $project->delivery_date, ['class' => 'datepicker category-select form-control', 'placeholder' => get_string('delivery_date')])); ?>

                            <?php echo e(Form::label('delivery_date', get_string('delivery_date'))); ?>

                            <?php if($errors->has('delivery_date')): ?>
                                <span class="wrong-error">* <?php echo e($errors->first('delivery_date')); ?></span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="col s6">
                        <div class="form-group  <?php echo e($errors->has('payment_plan') ? 'has-error' : ''); ?>">
                            <?php echo e(Form::text('payment_plan', $project->payment_plan, ['class' => 'category-select form-control', 'placeholder' => get_string('payment_plan')])); ?>

                            <?php echo e(Form::label('payment_plan', get_string('payment_plan'))); ?>

                            <?php if($errors->has('payment_plan')): ?>
                                <span class="wrong-error">* <?php echo e($errors->first('payment_plan')); ?></span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="col s12 well checkbox-grid">
                        <p><?php echo e(get_string('choose_features')); ?></p>
                        <?php $__currentLoopData = $features; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $feature): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                            <div class="col s2">
                                <div class="form-group">
                                    <input type="checkbox" name="features[]" <?php if((old('features') && in_array_r($feature->id, old('features'))) || ($project->features && in_array($feature->id, $project->features))): ?> checked <?php endif; ?> value="<?php echo e($feature->id); ?>" class="filled-in primary-color" id="<?php echo e($feature->id); ?>" />
                                    <label for="<?php echo e($feature->id); ?>"></label>
                                    <span class="checkbox-label"><?php echo e($feature->feature[$default_language->id]); ?></span>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                    </div>
                    
                    <div class="hidden-fields hidden">
                    </div>
                </div>
            </div>
            <div class="col clearfix s12 mtop10">
                <div class="form-group">
                    <button class="btn waves-effect" type="submit" name="action"><?php echo e(get_string('edit_project')); ?></button>
                    <a href="<?php echo e(route('company.project.index')); ?>" class="btn waves-effect"><?php echo e(get_string('project_all')); ?></a>
                    <a href="#" class="delete-button btn waves-effect btn-red" data-id="<?php echo e($project->id); ?>"><i class="material-icons color-white">delete</i></a>
                </div>
            </div>
            <?php echo e(Form::hidden('company_id', Auth::user()->id)); ?>

            <?php echo e(Form::hidden('agent_id', $project->agent_id ?: 0)); ?>

            <?php echo Form::close(); ?>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
    <script src="https://maps.googleapis.com/maps/api/js?key=<?php echo e(get_setting('google_map_key', 'site')); ?>&libraries=places"></script>
    <script>
        $(document).ready(function(){
            $('.desc-content').summernote({
                height: 200,
                maxwidth: false,
                minwidth: false,
                placeholder: '<?php echo e(get_string('enter_project_content')); ?>',
                disableDragAndDrop: true,
                toolbar: [
                    ["style", ["style"]],
                    ["font", ["bold", "underline", "clear"]],
                    ["color", ["color"]],
                    ["para", ["ul", "ol", "paragraph"]],
                ],callbacks: {
                    onPaste: function (e) {
                        var bufferText = ((e.originalEvent || e).clipboardData || window.clipboardData).getData('Text');
                        e.preventDefault();
                        document.execCommand('insertText', false, bufferText);
                    }
                }
            });
        
        // Datepickers
            $('.datepicker').datepicker({
                dateFormat: 'dd/mm/yy',
                minDate: 0,
                onSelect: function(dateText, inst) {
                    var startDate = $(this).datepicker('getDate');
                    startDate.setDate(startDate.getDate() + 1);
                    $("[name='delivery_date']").val(dateText);
                }
            });

            $(this).on('click change', '.country-select', function() {
                if(!(this.selectedIndex == -1)) getProvincesByCountry($(this).val());
            });

            $(this).on('click change', '.province-select', function() {
                if(!(this.selectedIndex == -1)) getCitiesByProvince($(this).val());                    
            });
        });

        function getProvincesByCountry(id) {
            $.ajax({
                url: '<?php echo e(route('company_property_get_provinces')); ?>',
                type: 'post',
                data: {_token: $('[name="_token"]').val(), country_id: id},
                success: function (data){
                    var html = '<option value=""><?php echo e(get_string('province')); ?></option>';
                    $.each(data, function(key, value){
                        html += '<option value="' + key + '">'+ value +'</option>';
                    });

                    $('.province-select').html(html);
                }   
            });
        }

        function getCitiesByProvince(id) {
            $.ajax({
                url: '<?php echo e(route('company_property_get_cities')); ?>',
                type: 'post',
                data: {_token: $('[name="_token"]').val(), province_id: id},
                success: function (data){
                    var html = '<option value=""><?php echo e(get_string('city')); ?></option>';
                    $.each(data, function(key, value){
                        html += '<option value="' + key + '">'+ value +'</option>';
                    });

                    $('.city-select').html(html);
                }   
            });
        }

        Dropzone.autoDiscover = false;
        $(document).ready(function(){
            var fileDropzone = $('#file-dropzone');
            $(fileDropzone).dropzone({
                url: '<?php echo e(url('/image_handler/upload')); ?>',
                paramsName: 'image',
                params: {_token: $('[name=_token]').val()},
                maxFilesize: 100,
                uploadMultiple: false,
                addRemoveLinks: true,
                maxfilesize: 1,
                parallelUploads: 1,
                maxFiles: 6,
                init: function() {

                    <?php if($project->images): ?>
                        <?php $__currentLoopData = $project->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                            var mockFile = { name: '<?php echo e($image->image); ?>', size: 100000 };
                            this.emit("addedfile", mockFile);
                            this.createThumbnailFromUrl(mockFile, '/images/data/<?php echo e($image->image); ?>');
                            this.emit("success", mockFile);
                        $('.hidden-fields').append('<input type="hidden" name="images[]" value="<?php echo e($image->image); ?>">');
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                    <?php endif; ?>

                    this.on('success', function(file, json) {
                        var selector = file._removeLink;
                        $(selector).attr('data-dz-remove', json.data);
                        $('.hidden-fields').append('<input type="hidden" name="images[]" value="'+ json.data +'">');
                    });

                    this.on('addedfile', function(file) {

                    });

                    this.on("removedfile", function(file) {
                        var selector = file._removeLink;
                        var data = $(selector).attr('data-dz-remove');
                        if(!data){
                            data = file.name;
                            $.ajax({
                                type: 'POST',
                                url: '<?php echo e(url('/image_handler/deleteBase')); ?>',
                                data: {data: data, _token: $('[name=_token]').val(), type: 'project', id: '<?php echo e($project->id); ?>'},
                                dataType: 'html',
                                success: function(msg){
                                    $('.hidden-fields').find('[value="'+ data +'"]').remove();
                                }
                            });
                        }else{
                            $.ajax({
                                type: 'POST',
                                url: '<?php echo e(url('/image_handler/delete')); ?>',
                                data: {data: data, _token: $('[name=_token]').val()},
                                dataType: 'html',
                                success: function(msg){
                                    $('.hidden-fields').find('[value="'+ data +'"]').remove();
                                }
                            });
                        }
                    });
                }
            });
        });

        // Google Map
        $(document).ready(function() {
            if(typeof google !== 'undefined' && google){
                var map = new google.maps.Map(document.getElementById('google-map'), {
                    center:{
                        lat: <?php echo e($project->geo_lng); ?>,
                        lng: <?php echo e($project->geo_lat); ?>

                    },
                    zoom: 10
                });
                var marker = new google.maps.Marker({
                    position: {
                        lat: <?php echo e($project->geo_lng); ?>,
                        lng: <?php echo e($project->geo_lat); ?>

                    },
                    map: map,
                    draggable: true
                });
                var infowindow = new google.maps.InfoWindow();
                var searchBox = document.getElementById('address-map');
                var autocomplete = new google.maps.places.Autocomplete(searchBox);

                autocomplete.bindTo('bounds', map);
                autocomplete.addListener('place_changed', function() {
                    infowindow.close();
                    marker.setVisible(false);
                    var place = autocomplete.getPlace();
                    if (!place.geometry) {
                        return;
                    }

                    // If the place has a geometry, then present it on a map.
                    if (place.geometry.viewport) {
                        map.fitBounds(place.geometry.viewport);
                    } else {
                        map.setCenter(place.geometry.location);
                        map.setZoom(15);
                    }

                    marker.setPosition(place.geometry.location);
                    marker.setVisible(true);

                    var address = '';
                    if (place.address_components) {
                        address = [
                            (place.address_components[0] && place.address_components[0].short_name || ''),
                            (place.address_components[1] && place.address_components[1].short_name || ''),
                            (place.address_components[2] && place.address_components[2].short_name || '')
                        ].join(' ');
                    }

                    infowindow.setContent('<div><strong>' + place.name + '</strong><br>' + address);
                    infowindow.open(map, marker);
                });

                google.maps.event.addListener(marker, 'position_changed', function () {
                    var lat = marker.getPosition().lat();
                    var lng = marker.getPosition().lng();
                    $('[name="geo_lng"]').val(lat);
                    $('[name="geo_lat"]').val(lng);
                });
                $('a[href$="location-panel"]').click(function(){
                    var currCenter = map.getCenter();
                    setTimeout(function(){
                        google.maps.event.trigger($("#google-map")[0], 'resize');
                        map.setCenter(currCenter);
                    }, 50);
                });
            }
        });
        $(document).ready(function(){
            $('.delete-button').click(function(event){
                event.preventDefault();
                var id = $(this).data('id');
                var token = $('[name="_token"]').val();
                bootbox.confirm({
                    title: '<?php echo e(get_string('confirm_action')); ?>',
                    message: '<?php echo e(get_string('delete_confirm')); ?>',
                    onEscape: true,
                    backdrop: true,
                    buttons: {
                        cancel: {
                            label: '<?php echo e(get_string('no')); ?>',
                            className: 'btn waves-effect'
                        },
                        confirm: {
                            label: '<?php echo e(get_string('yes')); ?>',
                            className: 'btn waves-effect'
                        }
                    },
                    callback: function (result) {
                        if(result){
                            $.ajax({
                                url: '<?php echo e(url('/company/project/')); ?>/'+id,
                                type: 'post',
                                data: {_method: 'delete', _token :token},
                                success:function(msg) {
                                    window.location = "/company/project";
                                }
                            });
                        }
                    }
                });
            });
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.company', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>