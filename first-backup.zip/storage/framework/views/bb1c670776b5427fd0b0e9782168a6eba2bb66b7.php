

<?php $__env->startSection('title'); ?>
    <title><?php echo e(get_string('edit_contractType') . ' - ' . get_setting('site_name', 'site')); ?></title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php $__env->startSection('page_title'); ?>
    <h3 class="page-title mbot10"><?php echo e(get_string('edit_contractType')); ?></h3>
<?php $__env->stopSection(); ?>
<div class="col s12">
    <?php if(!$errors->isEmpty()): ?>
        <span class="wrong-error">* <?php echo e(get_string('validation_error')); ?></span>
    <?php endif; ?>
        <?php echo Form::open(['method' => 'patch', 'url' => route('admin.taxonomy.contract-type.update', $contractType->id), 'files' => 'true']); ?>

    <div class="panel">
        <div class="panel-heading">
            <ul class="nav nav-tabs">
                <li class="tab active"><a href="#content-panel" data-toggle="tab"><?php echo e(get_string('content')); ?></a></li>
                <li class="tab"><a href="#data-panel" data-toggle="tab"><?php echo e(get_string('data')); ?></a></li>
            </ul>
        </div>
        <div class="panel-body">
            <div class="tab-content">
                <div id="content-panel" class="tab-pane active">
                    <div class="panel">
                        <div class="panel-heading">
                            <ul class="nav nav-tabs">
                                <?php $__currentLoopData = $languages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $language): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                    <li class="tab <?php echo e($language->default ? 'active' : ''); ?>"><a href="#lang<?php echo e($language->id); ?>" data-parent="#content" data-toggle="tab"><img src="<?php echo e($language->flag); ?>"/><span><?php echo e($language->language); ?></span></a></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                            </ul>
                        </div>
                        <div class="panel-body">
                            <div class="tab-content">
                                <?php $__currentLoopData = $languages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $language): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                    <div id="lang<?php echo e($language->id); ?>" class="tab-pane <?php echo e($language->default ? 'active' : ''); ?>">
                                        <div class="col s12">
                                            <div class="form-group  <?php echo e($errors->has('name.'.$language->id.'') ? 'has-error' : ''); ?>">
                                                <?php echo e(Form::text('name['.$language->id.']', $contractType->content($language->id)->name, ['class' => 'form-control', 'placeholder' => get_string('name')])); ?>

                                                <?php echo e(Form::label('name['.$language->id.']', get_string('name'))); ?>

                                                <?php if($errors->has('name.'.$language->id.'')): ?>
                                                    <span class="wrong-error">* <?php echo e($errors->first('name.'.$language->id.'')); ?></span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                            </div>
                        </div>
                    </div>
                </div>
                <div id="data-panel" class="tab-pane">
                    <div class="col s12">
                        <div class="form-group">
                            <?php echo e(Form::number('order', $contractType->order, ['class' => 'form-control', 'min' => '0', 'step' => 1, 'placeholder' => get_string('order')])); ?>

                            <?php echo e(Form::label('order', get_string('order'))); ?>

                        </div>
                    </div>
                </div>
            </div>
            <div class="col clearfix s12 mtop10">
                <div class="form-group">
                    <button class="btn waves-effect" type="submit" name="action"><?php echo e(get_string('edit_contractType')); ?></button>
                    <a href="<?php echo e(route('admin.taxonomy.contract-type.index')); ?>" class="btn waves-effect"><?php echo e(get_string('back')); ?></a>
                </div>
            </div>
            <?php echo Form::close(); ?>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>