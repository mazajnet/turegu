

<?php $__env->startSection('title'); ?>
    <title><?php echo e(get_string('prices') . ' - ' . get_setting('site_name', 'site')); ?></title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<?php $__env->startSection('page_title'); ?>
<?php $__env->stopSection(); ?>
<?php $points = get_string('points'); ?>
<div class="col s12">
    <h3 class="page-title mbot10"><?php echo e(get_string('packages')); ?></h3>
    <div class="table-responsive">
        <table class="table bordered striped">
            <thead class="thead-inverse">
            <tr>
                <th>
                    <input type="checkbox" class="filled-in primary-color" id="select-all" />
                    <label for="select-all"></label>
                </th>
                <th><?php echo e(get_string('package')); ?></th>
                <th><?php echo e(get_string('cost')); ?></th>
                <th><?php echo e(get_string('points')); ?></th>
                <th><?php echo e(get_string('bonus')); ?></th>
            </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $packages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $package): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?> 

                    <tr>
                        <td>
                            <input type="checkbox" class="filled-in primary-color" id="package-<?php echo e($package->id); ?>" />
                            <label for="package-<?php echo e($package->id); ?>"></label>
                        </td>
                        <td><?php echo e(get_string('package') .' #'. $package->id); ?></td>
                        <td><?php echo e(get_setting('currency', 'site') . $package->cost); ?></td>
                        <td><?php echo e($package->points .' '. $points); ?></td>
                        <td><?php echo e($package->bonus .' '.$points); ?></td>
                    </tr>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
            </tbody>
        </table>
    </div>
</div>
<div class="col m6 s12">
    <h3 class="page-title mbot10"><?php echo e(get_string('bannerType')); ?></h3>
    <div class="table-responsive">
        <table class="table bordered striped">
            <thead class="thead-inverse">
            <tr>
                <th>
                    <input type="checkbox" class="filled-in primary-color" id="select-all" />
                    <label for="select-all"></label>
                </th>
                <th><?php echo e(get_string('bannerType')); ?></th>
                <th><?php echo e(get_string('weekly')); ?></th>
                <th><?php echo e(get_string('monthly')); ?></th>
                <th><?php echo e(get_string('yearly')); ?></th>
                <th><?php echo e(get_string('maximum')); ?></th>
            </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $bannerTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bannerType): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?> 

                    <tr>
                        <td>
                            <input type="checkbox" class="filled-in primary-color" id="bannerType-<?php echo e($bannerType->id); ?>" />
                            <label for="bannerType-<?php echo e($bannerType->id); ?>"></label>
                        </td>
                        <td><?php echo e(get_string($bannerType->key)); ?></td>
                        <td><?php echo e($bannerType->weekly .' '. $points); ?></td>
                        <td><?php echo e($bannerType->monthly .' '. $points); ?></td>
                        <td><?php echo e($bannerType->yearly .' '.$points); ?></td>
                        <td><?php echo e($bannerType->maximum); ?></td>
                    </tr>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
            </tbody>
        </table>
    </div>
</div>
<div class="col m6 s12">
    <h3 class="page-title mbot10"><?php echo e(get_string('adTypes')); ?></h3>
    <div class="table-responsive">
        <table class="table bordered striped">
            <thead class="thead-inverse">
            <tr>
                <th>
                    <input type="checkbox" class="filled-in primary-color" id="select-all" />
                    <label for="select-all"></label>
                </th>
                <th><?php echo e(get_string('adType')); ?></th>
                <th><?php echo e(get_string('weekly')); ?></th>
                <th><?php echo e(get_string('monthly')); ?></th>
                <th><?php echo e(get_string('yearly')); ?></th>
                <th><?php echo e(get_string('maximum')); ?></th>
            </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $adTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $adType): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?> 

                    <tr>
                        <td>
                            <input type="checkbox" class="filled-in primary-color" id="adType-<?php echo e($adType->id); ?>" />
                            <label for="adType-<?php echo e($adType->id); ?>"></label>
                        </td>
                        <td><?php echo e(get_string($adType->key)); ?></td>
                        <td><?php echo e($adType->weekly .' '. $points); ?></td>
                        <td><?php echo e($adType->monthly .' '. $points); ?></td>
                        <td><?php echo e($adType->yearly .' '. $points); ?></td>
                        <td><?php echo e($adType->maximum); ?></td>
                    </tr>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.company', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>