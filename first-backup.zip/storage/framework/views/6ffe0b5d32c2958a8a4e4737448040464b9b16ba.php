<?php $__env->startSection('title'); ?>
    <title><?php echo e(get_string('memberships') . ' - ' . get_setting('site_name', 'site')); ?></title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php $__env->startSection('page_title'); ?>
    <h3 class="page-title mbot10"><?php echo e(get_string('memberships')); ?></h3>
<?php $__env->stopSection(); ?>
<div class="col s12">
    <table class="table bordered striped">
        <thead class="thead-inverse">
            <tr>
                <th style="width: 30%"></th>
                <?php $__currentLoopData = $memberships; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $membership): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                    <th><?php echo e(get_string($membership->key)); ?></th>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td style="font-weight: bold;"><?php echo e(get_string('monthly')); ?></td>
                <?php $__currentLoopData = $memberships; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $membership): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                    <td><?php echo e($membership->monthly .' '. get_string('points')); ?></td>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
            </tr>
            <tr>
                <td style="font-weight: bold;"> <?php echo e(get_string('agents')); ?></td>
                <?php $__currentLoopData = $memberships; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $membership): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                    <td><?php echo e($membership->agents); ?></td>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
            </tr>
            <tr>
                <td style="font-weight: bold;"><?php echo e(get_string('listings')); ?></td>
                <?php $__currentLoopData = $memberships; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $membership): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                    <td><?php echo e($membership->listings); ?></td>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
            </tr>
            <tr>
                <td style="font-weight: bold;"><?php echo e(get_string('listing_duration')); ?></td>
                <?php $__currentLoopData = $memberships; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $membership): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                    <td><?php echo e($membership->listing_duration); ?></td>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
            </tr>
            <tr>
                <td style="font-weight: bold;"><?php echo e(get_string('projects')); ?></td>
                <?php $__currentLoopData = $memberships; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $membership): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                    <td><?php echo e($membership->projects ? get_string('yes') : get_string('no')); ?></td>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
            </tr>
            <tr>
                <td style="font-weight: bold;"><?php echo e(get_string('private_tour')); ?></td>
                <?php $__currentLoopData = $memberships; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $membership): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                    <td><?php echo e($membership->private_tour ? get_string('yes') : get_string('no')); ?></td>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
            </tr>
            <tr>
                <td style="font-weight: bold;"><?php echo e(get_string('view_tour')); ?></td>
                <?php $__currentLoopData = $memberships; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $membership): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                    <td><?php echo e($membership->view_tour ? get_string('yes') : get_string('no')); ?></td>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
            </tr>
            <tr>
                <td style="font-weight: bold;"><?php echo e(get_string('property_requests')); ?></td>
                <?php $__currentLoopData = $memberships; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $membership): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                    <td><?php echo e($membership->property_request ? get_string('yes') : get_string('no')); ?></td>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
            </tr>
            <tr>
                <td style="font-weight: bold;"> <?php echo e(get_string('search_company')); ?></td>
                <?php $__currentLoopData = $memberships; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $membership): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                    <td><?php echo e($membership->search_company ? get_string('yes') : get_string('no')); ?></td>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
            </tr>
            <tr>
                <td style="font-weight: bold;"><?php echo e(get_string('home_logo')); ?></td>
                <?php $__currentLoopData = $memberships; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $membership): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                    <td><?php echo e($membership->home_logo ? get_string('yes') : get_string('no')); ?></td>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
            </tr>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.company', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>