

<?php $__env->startSection('title'); ?>
    <title><?php echo e(get_string('properties') . ' - ' . get_setting('site_name', 'site')); ?></title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<?php $__env->startSection('page_title'); ?>
    <h3 class="page-title mbot10"><?php echo e(get_string('properties')); ?></h3>
<?php $__env->stopSection(); ?>
<div class="col l6 m8 s12 left left-align mbot10">
    <?php echo e(Form::open(['method' => 'post', 'url' => route('company_property_search')])); ?>

    <div class="form-group col s8 autocomplete-fix">
        <?php echo e(Form::text('term', null, ['class' => 'form-control', 'id' => 'term', 'placeholder' => get_string('search_properties')])); ?>

    </div>
    <div class="col l4 m4 s4">
        <button class="btn waves-effect" type="submit" name="action"><?php echo e(get_string('filter')); ?></button>
    </div>
    <?php echo e(Form::close()); ?>

</div>
<div class="col l6 m4 s12 right right-align mbot10">
    <a href="<?php echo e(route('company.property.create')); ?>" class="btn waves-effect"> <?php echo e(get_string('create_property')); ?> <i class="material-icons small">add_circle</i></a>
    <a href="#" class="mass-delete btn waves-effect btn-red"><i class="material-icons color-white">delete</i></a>
</div>
<div class="col s12">
    <?php if(Session::has('maximum_listings')): ?>
        <span class="wrong-error">* <?php echo e(get_string('maximum_listings')); ?></span>
    <?php endif; ?>
    <?php if($properties->count()): ?>
        <div class="table-responsive">
            <table class="table bordered striped">
                <thead class="thead-inverse">
                <tr>
                    <th>
                        <input type="checkbox" class="filled-in primary-color" id="select-all" />
                        <label for="select-all"></label>
                    </th>
                    <th><?php echo e(get_string('property')); ?></th>
                    <th><?php echo e(get_string('company')); ?></th>
                    <th><?php echo e(get_string('agent')); ?></th>
                    <th><?php echo e(get_string('type')); ?></th>
                    <th><?php echo e(get_string('contract_type')); ?></th>
                    <th><?php echo e(get_string('location')); ?></th>
                    <th><?php echo e(get_string('status')); ?></th>
                    <th class="icon-options"><?php echo e(get_string('options')); ?></th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $properties; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $property): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                    <tr>
                        <td>
                            <input type="checkbox" class="filled-in primary-color" id="<?php echo e($property->id); ?>" />
                            <label for="<?php echo e($property->id); ?>"></label>
                        </td>
                        <td><?php echo e($property->contentDefault->name); ?></td>
                        <td><?php if($property->company): ?><?php echo e($property->company->user->username); ?> <?php else: ?> <i class="small material-icons color-red">clear</i> <?php endif; ?></td>
                        <td><?php if($property->agent): ?><?php echo e($property->agent->user->username); ?> <?php else: ?> <i class="small material-icons color-red">clear</i> <?php endif; ?></td>
                        <td><?php echo e($property->type ? $property->type->contentDefault->name : ''); ?></td>
                        <td><?php echo e($property->contract ? $property->contract->contentDefault->name : ''); ?></td>
                        <td><?php echo e($property->city ? $property->city->contentDefault->name .', ' : ''); ?> <?php echo e($property->province ? $property->province->contentDefault->name .' - ' : ''); ?>  <?php echo e($property->country ? $property->country->contentDefault->name : ''); ?></td>
                        <td class="page-status"><?php echo e($property->status ? get_string('active') : get_string('pending')); ?></td>
                        <td>
                            <div class="icon-options">
                                <a href="<?php echo e(url('property').'/'.$property->alias); ?>" title="<?php echo e(get_string('view_property')); ?>"><i class="small material-icons color-primary">visibility</i></a>
                                <a href="<?php echo e(route('company.property.edit', $property->id)); ?>" title="<?php echo e(get_string('view_property')); ?>"><i class="small material-icons color-primary">mode_edit</i></a>
                                <?php if(!$property->agent_id): ?> 

                                <a class="assign-button" data-id="<?php echo e($property->id); ?>" data-toggle="modal" href="#user-modal" title="<?php echo e(get_string('assign_agent')); ?>"><i class="small material-icons color-primary">person</i></a> 

                                <?php endif; ?>
                                <a href="#" class="delete-button" data-id="<?php echo e($property->id); ?>" title="<?php echo e(get_string('delete_property')); ?>"><i class="small material-icons color-red">delete</i></a>
                                <a href="#" class="activate-button <?php echo e($property->status ? 'hidden': ''); ?>" data-id="<?php echo e($property->id); ?>" title="<?php echo e(get_string('activate_property')); ?>"><i class="small material-icons color-primary">done</i></a>
                                <a href="#" class="deactivate-button <?php echo e($property->status ? '': 'hidden'); ?>" data-id="<?php echo e($property->id); ?>" title="<?php echo e(get_string('deactivate_property')); ?>"><i class="small material-icons color-primary">close</i></a>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                </tbody>
            </table>
        </div>
        <?php echo e($properties->links()); ?>

    <?php else: ?>
        <strong class="center-align"><?php echo e(get_string('no_results')); ?></strong>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
<div id="user-modal" class="modal not-summernote fade" role="dialog">
    <div class="modal-dialog">
        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <a href="#!" class="close" data-dismiss="modal" aria-label="Close"><i class="material-icons">clear</i></a>
                <strong class="modal-title"><?php echo e(get_string('assign_agent')); ?></strong>
            </div>
            <div class="modal-body">
                <?php echo Form::open(['method' => 'post', 'url' => route('company_property_asign'), 'id' => 'user-form']); ?>

                <?php echo e(Form::input('hidden', 'property_id', null, ['class' => 'hidden', 'id' => 'property_id'])); ?>

                <div class="row mbot0">


                    <div class="col s12">
                        <div class="form-group  <?php echo e($errors->has('first_name') ? 'has-error' : ''); ?>">
                            <?php echo e(Form::select('user_id', $agents, null, ['required', 'class' => 'form-control', 'placeholder' => get_string('select_agent')])); ?>

                            <?php echo e(Form::label('user_id', get_string('select_agent'))); ?>

                            <?php if($errors->has('user_id')): ?>
                                <span class="wrong-error">* <?php echo e($errors->first('user_id')); ?></span>
                            <?php endif; ?>
                        </div>
                    </div>


                </div>
            </div>
            <div class="modal-footer">
                <a href="#!" class="waves-effect btn btn-default" data-dismiss="modal"><?php echo e(get_string('close')); ?></a>
                <button type="submit" name="action" class="update-lang-form waves-effect btn btn-default"><?php echo e(get_string('assign')); ?></button>
            </div>
            <?php echo Form::close(); ?>

        </div>
    </div>
</div>
    <script>
        $(document).ready(function(){
            
            $('.assign-button').click(function(e){
                $('[name="property_id"]').val($(this).data('id'));
            });

            $('.delete-button').click(function(event){
                event.preventDefault();
                var id = $(this).data('id');
                var selector = $(this).parents('tr');
                var token = $('[name="_token"]').val();
                bootbox.confirm({
                    title: '<?php echo e(get_string('confirm_action')); ?>',
                    message: '<?php echo e(get_string('delete_confirm')); ?>',
                    onEscape: true,
                    backdrop: true,
                    buttons: {
                        cancel: {
                            label: '<?php echo e(get_string('no')); ?>',
                            className: 'btn waves-effect'
                        },
                        confirm: {
                            label: '<?php echo e(get_string('yes')); ?>',
                            className: 'btn waves-effect'
                        }
                    },
                    callback: function (result) {
                        if(result){
                            $.ajax({
                                url: '<?php echo e(url('/company/property/')); ?>/'+id,
                                type: 'post',
                                data: {_method: 'delete', _token :token},
                                success:function(msg) {
                                    selector.remove();
                                    toastr.success(msg);
                                },
                                error:function(msg){
                                    toastr.error(msg.responseJSON);
                                }
                            });
                        }
                    }
                });
            });

            $('.activate-button').click(function(event){
                event.preventDefault();
                var id = $(this).data('id');
                var selector = $(this).parents('tr');
                var thisBtn = $(this).parents('.icon-options');
                var status = selector.children('.page-status');
                var token = $('[name="_token"]').val();
                bootbox.confirm({
                    title: '<?php echo e(get_string('confirm_action')); ?>',
                    message: '<?php echo e(get_string('activate_property_confirm')); ?>',
                    onEscape: true,
                    backdrop: true,
                    buttons: {
                        cancel: {
                            label: '<?php echo e(get_string('no')); ?>',
                            className: 'btn waves-effect'
                        },
                        confirm: {
                            label: '<?php echo e(get_string('yes')); ?>',
                            className: 'btn waves-effect'
                        }
                    },
                    callback: function (result) {
                        if(result){
                            $.ajax({
                                url: '<?php echo e(url('/company/property/activate/')); ?>/'+id,
                                type: 'post',
                                data: {_token :token},
                                success:function(msg) {
                                    thisBtn.children('.activate-button').addClass('hidden');
                                    thisBtn.children('.deactivate-button').removeClass('hidden');
                                    status.html('<?php echo e(get_string('active')); ?>');
                                    toastr.success(msg);
                                },
                                error:function(msg){
                                    toastr.error(msg.responseJSON);
                                }
                            });
                        }
                    }
                });
            });

            $('.deactivate-button').click(function(event){
                event.preventDefault();
                var id = $(this).data('id');
                var selector = $(this).parents('tr');
                var thisBtn = $(this).parents('.icon-options');
                var status = selector.children('.page-status');
                var token = $('[name="_token"]').val();
                bootbox.confirm({
                    title: '<?php echo e(get_string('confirm_action')); ?>',
                    message: '<?php echo e(get_string('deactivate_property_confirm')); ?>',
                    onEscape: true,
                    backdrop: true,
                    buttons: {
                        cancel: {
                            label: '<?php echo e(get_string('no')); ?>',
                            className: 'btn waves-effect'
                        },
                        confirm: {
                            label: '<?php echo e(get_string('yes')); ?>',
                            className: 'btn waves-effect'
                        }
                    },
                    callback: function (result) {
                        if(result){
                            $.ajax({
                                url: '<?php echo e(url('/company/property/deactivate/')); ?>/'+id,
                                type: 'post',
                                data: {_token :token},
                                success:function(msg) {
                                    thisBtn.children('.deactivate-button').addClass('hidden');
                                    thisBtn.children('.activate-button').removeClass('hidden');
                                    status.html('<?php echo e(get_string('pending')); ?>');
                                    toastr.success(msg);
                                },
                                error:function(msg){
                                    toastr.error(msg.responseJSON);
                                }
                            });
                        }
                    }
                });
            });

            $('.make-featured-button').click(function(event){
                event.preventDefault();
                var id = $(this).data('id');
                var selector = $(this).parents('tr');
                var thisBtn = $(this).parents('.icon-options');
                var status = selector.children('.page-featured');
                var token = $('[name="_token"]').val();
                bootbox.prompt({
                    title: '<?php echo e(get_string('confirm_action')); ?>',
                    inputType: 'select',
                    inputOptions: [
                        {
                            text: '<?php echo e(get_string('choose_your_package')); ?>',
                            value: '',
                        },
                        {
                            text: '<?php echo e(get_string('week_featured')); ?> - <?php echo e(get_setting('points_featured_week', 'payment')); ?> <?php echo e(get_string('points')); ?>',
                            value: '1',
                        },
                        {
                            text: '<?php echo e(get_string('month_featured')); ?> - <?php echo e(get_setting('points_featured_month', 'payment')); ?> <?php echo e(get_string('points')); ?>',
                            value: '2',
                        },
                        {
                            text: '<?php echo e(get_string('3months_featured')); ?> - <?php echo e(get_setting('points_featured_3months', 'payment')); ?> <?php echo e(get_string('points')); ?>',
                            value: '3',
                        }
                    ],
                    message: '<?php echo e(get_string('make_featured_confirm')); ?>',
                    onEscape: true,
                    backdrop: true,
                    buttons: {
                        cancel: {
                            label: '<?php echo e(get_string('no')); ?>',
                            className: 'btn waves-effect'
                        },
                        confirm: {
                            label: '<?php echo e(get_string('yes')); ?>',
                            className: 'btn waves-effect'
                        }
                    },
                    callback: function (result) {
                        if(result){
                            $.ajax({
                                url: '<?php echo e(url('/company/property/makefeatured/')); ?>/'+id,
                                type: 'post',
                                data: {_token :token, price: result},
                                success:function(msg) {
                                    thisBtn.children('.make-featured-button').addClass('hidden');
                                    thisBtn.children('.make-default-button').removeClass('hidden');
                                    status.html('<?php echo e(get_string('yes')); ?>');
                                    toastr.success(msg);
                                    setTimeout(function(){location.reload()}, 1500);
                                },
                                error:function(msg){
                                    toastr.error(msg.responseJSON);
                                }
                            });
                        }else{
                            toastr.warning('<?php echo e(get_string('choose_your_package')); ?>!');
                        }
                    }
                });
            });

            $('.make-default-button').click(function(event){
                event.preventDefault();
                var id = $(this).data('id');
                var selector = $(this).parents('tr');
                var thisBtn = $(this).parents('.icon-options');
                var status = selector.children('.page-featured');
                var token = $('[name="_token"]').val();
                bootbox.confirm({
                    title: '<?php echo e(get_string('confirm_action')); ?>',
                    message: '<?php echo e(get_string('make_default_confirm')); ?>',
                    onEscape: true,
                    backdrop: true,
                    buttons: {
                        cancel: {
                            label: '<?php echo e(get_string('no')); ?>',
                            className: 'btn waves-effect'
                        },
                        confirm: {
                            label: '<?php echo e(get_string('yes')); ?>',
                            className: 'btn waves-effect'
                        }
                    },
                    callback: function (result) {
                        if(result){
                            $.ajax({
                                url: '<?php echo e(url('/company/property/makedefault/')); ?>/'+id,
                                type: 'post',
                                data: {_token :token},
                                success:function(msg) {
                                    thisBtn.children('.make-default-button').addClass('hidden');
                                    thisBtn.children('.make-featured-button').removeClass('hidden');
                                    status.html('<?php echo e(get_string('no')); ?>');
                                    toastr.success(msg);
                                },
                                error:function(msg){
                                    toastr.error(msg.responseJSON);
                                }
                            });
                        }
                    }
                });
            });


            $('.mass-delete').click(function(event){
                event.preventDefault();
                var id = [];
                var selector = [];
                $("tbody input:checkbox:checked").each(function(){
                    id.push($(this).attr('id'));
                    selector.push($(this).parents('tr'));
                });
                var token = $('[name="_token"]').val();
                bootbox.confirm({
                    title: '<?php echo e(get_string('confirm_action')); ?>',
                    message: '<?php echo e(get_string('delete_confirm_bulk')); ?>',
                    onEscape: true,
                    backdrop: true,
                    buttons: {
                        cancel: {
                            label: '<?php echo e(get_string('no')); ?>',
                            className: 'btn waves-effect'
                        },
                        confirm: {
                            label: '<?php echo e(get_string('yes')); ?>',
                            className: 'btn waves-effect'
                        }
                    },
                    callback: function (result) {
                        if(result){
                            $.ajax({
                                url: '<?php echo e(url('/company/property/massdestroy')); ?>',
                                type: 'post',
                                data: {id: id, _token :token},
                                success:function(msg) {
                                    $.each(selector, function(index, item){
                                        $(this).remove();
                                    });
                                    $('#select-all').prop('checked', false);
                                    toastr.success(msg);
                                },
                                error: function(msg){
                                    toastr.error(msg.responseJSON);
                                }
                            });
                        }
                    }
                });
            });
            $('#term').autocomplete({
                source: '<?php echo e(url('/company/property/autocomplete')); ?>',
                minLength: 0,
                delay: 0,
                focus: function( event, ui ) {
                    $('#term').val( ui.item.name );
                    return false;
                },
                select: function( event, ui ) {
                    $('#term').val( ui.item.name).attr('data-id', ui.item.id);
                    return false;
                }}).data("ui-autocomplete")._renderItem = function( ul, item ) {
                return $( "<li></li>" )
                        .append( "<a href='#'>" + item.name + "</a>" )
                        .appendTo( ul );
            };
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.company', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>