

<?php $__env->startSection('title'); ?>
    <title><?php echo e(get_string('units') . ' - ' . get_setting('site_name', 'site')); ?></title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<?php $__env->startSection('page_title'); ?>
    <h3 class="page-title mbot10"><?php echo e(get_string('units')); ?></h3>
<?php $__env->stopSection(); ?>
    <div class="col l6 m4 s12 right right-align mbot10">
        <a href="<?php echo e(route('company_project_unit_create', $id)); ?>" class="btn waves-effect"> <?php echo e(get_string('create_unit')); ?> <i class="material-icons small">add_circle</i></a>
    </div>
    <div class="col s12">
        <?php if($units->count()): ?>
        <div class="table-responsive">
        <table class="table bordered striped">
            <thead class="thead-inverse">
            <tr>
                <th>
                    <input type="checkbox" class="filled-in primary-color" id="select-all" />
                    <label for="select-all"></label>
                </th>
                <th><?php echo e(get_string('unit')); ?></th>
                <th><?php echo e(get_string('project')); ?></th>
                <th><?php echo e(get_string('type')); ?></th>
                <th><?php echo e(get_string('price')); ?></th>
                <th class="icon-options"><?php echo e(get_string('options')); ?></th>
            </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $units; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unit): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                    <tr>
                        <td>
                            <input type="checkbox" class="filled-in primary-color" id="<?php echo e($unit->id); ?>" />
                            <label for="<?php echo e($unit->id); ?>"></label>
                        </td>
                        <td><?php echo e($unit->contentDefault->name); ?></td>
                        <td><?php echo e($unit->project ? $unit->project->contentDefault->name : ''); ?></td>
                        <td><?php echo e($unit->type ? $unit->type->contentDefault->name : ''); ?></td>
                        <td><?php echo e(get_setting('currency', 'site')); ?><?php echo e($unit->price); ?></td>
                        <td>
                            <div class="icon-options">
                                <a href="<?php echo e(route('company_project_unit_edit', [$id, $unit->id])); ?>"><i class="small material-icons color-primary">mode_edit</i></a>
                                <a href="#" class="delete-button" data-id="<?php echo e($unit->id); ?>"><i class="small material-icons color-red">delete</i></a>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
            </tbody>
        </table>
        </div>
        <?php echo e($units->links()); ?>

        <?php else: ?>
            <strong class="center-align"><?php echo e(get_string('no_results')); ?></strong>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
<script>
    $(document).ready(function(){
        $('.delete-button').click(function(event){
            event.preventDefault();
            var id = $(this).data('id');
            var selector = $(this).parents('tr');
            var token = $('[name="_token"]').val();
            bootbox.confirm({
                title: '<?php echo e(get_string('confirm_action')); ?>',
                message: '<?php echo e(get_string('delete_confirm')); ?>',
                onEscape: true,
                backdrop: true,
                buttons: {
                    cancel: {
                        label: '<?php echo e(get_string('no')); ?>',
                        className: 'btn waves-effect'
                    },
                    confirm: {
                        label: '<?php echo e(get_string('yes')); ?>',
                        className: 'btn waves-effect'
                    }
                },
                callback: function (result) {
                    if(result){
                        $.ajax({
                            url: '<?php echo e(url('/') . 'company/project/' . $id .'/unit/delete/'); ?>'+id,
                            type: 'post',
                            data: {_method: 'delete', _token :token},
                            success:function(msg) {
                                selector.remove();
                                toastr.success(msg);
                            },
                            error:function(msg){
                                toastr.error(msg.responseJSON);
                            }
                        });
                    }
                }
            });
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.company', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>