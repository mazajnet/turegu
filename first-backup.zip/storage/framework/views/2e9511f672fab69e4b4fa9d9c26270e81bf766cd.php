

<?php $__env->startSection('title'); ?>
    <title><?php echo e(get_string('ads') . ' - ' . get_setting('site_name', 'site')); ?></title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<?php $__env->startSection('page_title'); ?>
    <h3 class="page-title mbot10"><?php echo e(get_string('ads')); ?> - <?php echo e($user); ?></h3>
<?php $__env->stopSection(); ?>
<div class="col s12">
    <?php if($ads->count()): ?>
        <div class="table-responsive">
            <table class="table bordered striped">
                <thead class="thead-inverse">
                <tr>
                    <th>
                        <input type="checkbox" class="filled-in primary-color" id="select-all" />
                        <label for="select-all"></label>
                    </th>
                    <th><?php echo e(get_string('company')); ?></th>
                    <th><?php echo e(get_string('adType')); ?></th>
                    <th><?php echo e(get_string('property')); ?> / <?php echo e(get_string('project')); ?></th>
                    <th><?php echo e(get_string('payment_method')); ?></th>
                    <th><?php echo e(get_string('total')); ?></th>
                    <th><?php echo e(get_string('start_date')); ?></th>
                    <th><?php echo e(get_string('expires')); ?></th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $ads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ad): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                    <tr class="<?php echo e($ad->completed ? 'disabled-style' : ''); ?>">
                        <td>
                            <input type="checkbox" class="filled-in primary-color" id="<?php echo e($ad->id); ?>" />
                            <label for="<?php echo e($ad->id); ?>"></label>
                        </td>
                        <td><?php if($ad->company): ?><?php echo e($ad->company->username); ?><?php endif; ?></td>
                        <td><?php echo e($ad->type ? get_string($ad->type->key) : ''); ?></td>
                        <td><?php if($ad->property_id && $ad->property): ?> <?php echo e($ad->property->contentDefault->name); ?> <?php elseif($ad->project_id && $ad->project): ?> <?php echo e($ad->project->contentDefault->name); ?> <?php else: ?> X <?php endif; ?></td>
                        <td><?php echo e($ad->payment_method); ?></td>
                        <td><?php echo e($ad->payment_method == 'Points' ? '' : get_setting('currency', 'site')); ?><?php echo e($ad->total); ?></td>
                        <td><?php echo e($ad->created_at->format('Y-m-d')); ?></td>
                        <td><?php echo e($ad->expiresAt); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                </tbody>
            </table>
        </div>
        <?php echo e($ads->links()); ?>

    <?php else: ?>
        <strong class="center-align"><?php echo e(get_string('no_results')); ?></strong>
    <?php endif; ?>
</div>
<input type="hidden" class="token" value="<?php echo e(csrf_token()); ?>">
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>