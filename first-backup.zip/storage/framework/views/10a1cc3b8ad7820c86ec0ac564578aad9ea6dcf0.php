

<?php $__env->startSection('title'); ?>
    <title><?php echo e(get_string('packages') . ' - ' . get_setting('site_name', 'site')); ?></title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php $__env->startSection('page_title'); ?>
    <h3 class="page-title mbot10"><?php echo e(get_string('packages')); ?></h3>
<?php $__env->stopSection(); ?>
<div class="panel col s12">
    <div class="row">
        <div class="panel-heading">
            <ul class="nav nav-tabs">
                <li class="tab active"><a data-toggle="tab" href="#general_settings"><?php echo e(get_string('packages')); ?></a></li>
            </ul>
        </div>
        <?php echo Form::open(['url' => route('admin_packages_update'), 'method' => 'post', 'id' => "packages", 'class' => 'table-responsive']); ?>

        <div class="panel-body">
            <div class="tab-content">
                <div id="general_settings" class="tab-pane active">

                    
                    <?php $__currentLoopData = $packages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $package): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                    <div class="col s12">
                        <h3 class="page-title clearfix"><?php echo e(get_string('package')); ?> - #<?php echo e($package->id); ?></h3>
                    </div>
                    <div class="col m4 s12">
                        <div class="form-group  <?php echo e($errors->has('points') ? 'has-error' : ''); ?>">
                            <?php echo e(Form::number($package->id.'[points]', $package->points, ['class' => 'form-control', 'required', 'min' => 0, 'placeholder' => get_string('points')])); ?>

                            <?php echo e(Form::label('points', get_string('points'))); ?>

                            <?php if($errors->has('points')): ?>
                                <span class="wrong-error">* <?php echo e($errors->first('points')); ?></span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="col m4 s12">
                        <div class="form-group  <?php echo e($errors->has('cost') ? 'has-error' : ''); ?>">
                            <?php echo e(Form::number($package->id.'[cost]', $package->cost, ['class' => 'form-control', 'required', 'min' => 0, 'placeholder' => get_string('cost').' - '.get_setting('currency', 'site')])); ?>

                            <?php echo e(Form::label('cost', get_string('cost').' - '.get_setting('currency', 'site'))); ?>

                            <?php if($errors->has('cost')): ?>
                                <span class="wrong-error">* <?php echo e($errors->first('cost')); ?></span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="col m4 s12">
                        <div class="form-group  <?php echo e($errors->has('bonus') ? 'has-error' : ''); ?>">
                            <?php echo e(Form::number($package->id.'[bonus]', $package->bonus, ['class' => 'form-control', 'required', 'min' => 0, 'placeholder' => get_string('bonus').' '.get_string('points')])); ?>

                            <?php echo e(Form::label('bonus', get_string('bonus').' '.get_string('points'))); ?>

                            <?php if($errors->has('bonus')): ?>
                                <span class="wrong-error">* <?php echo e($errors->first('bonus')); ?></span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>

                </div>
            </div>
            <div class="col clearfix l4 m4 s12 mtop10">
                <div class="form-group">
                    <button class="btn waves-effect" type="submit" name="action"><?php echo e(get_string('update')); ?></button></div>
                </div>
            </div>
        <?php echo Form::close(); ?>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>