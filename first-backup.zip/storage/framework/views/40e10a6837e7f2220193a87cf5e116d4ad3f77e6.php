

<?php $__env->startSection('title'); ?>
    <title><?php echo e(get_string('banners') . ' - ' . get_setting('site_name', 'site')); ?></title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<?php $__env->startSection('page_title'); ?>
    <h3 class="page-title mbot10"><?php echo e(get_string('banners')); ?> - <?php echo e($user); ?></h3>
<?php $__env->stopSection(); ?>
<div class="col s12">
    <?php if($banners->count()): ?>
        <div class="table-responsive">
            <table class="table bordered striped">
                <thead class="thead-inverse">
                <tr>
                    <th>
                        <input type="checkbox" class="filled-in primary-color" id="select-all" />
                        <label for="select-all"></label>
                    </th>
                    <th><?php echo e(get_string('company')); ?></th>
                    <th><?php echo e(get_string('bannerType')); ?></th>
                    <th><?php echo e(get_string('payment_method')); ?></th>
                    <th><?php echo e(get_string('total')); ?></th>
                    <th><?php echo e(get_string('start_date')); ?></th>
                    <th><?php echo e(get_string('expires')); ?></th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $banners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $banner): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                    <tr class="<?php echo e($banner->completed ? 'disabled-style' : ''); ?>">
                        <td>
                            <input type="checkbox" class="filled-in primary-color" id="<?php echo e($banner->id); ?>" />
                            <label for="<?php echo e($banner->id); ?>"></label>
                        </td>
                        <td><?php if($banner->company): ?><?php echo e($banner->company->username); ?><?php endif; ?></td>
                        <td><?php echo e($banner->type ? get_string($banner->type->key) : ''); ?></td>
                        <td><?php echo e($banner->payment_method); ?></td>
                        <td><?php echo e($banner->payment_method == 'Points' ? '' : get_setting('currency', 'site')); ?><?php echo e($banner->total); ?></td>
                        <td><?php echo e($banner->created_at->format('Y-m-d')); ?></td>
                        <td><?php echo e($banner->expiresAt); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                </tbody>
            </table>
        </div>
        <?php echo e($banners->links()); ?>

    <?php else: ?>
        <strong class="center-align"><?php echo e(get_string('no_results')); ?></strong>
    <?php endif; ?>
</div>
<input type="hidden" class="token" value="<?php echo e(csrf_token()); ?>">
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>