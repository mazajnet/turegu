

<?php $__env->startSection('title'); ?>
    <title><?php echo e(get_string('my_account') . ' - ' . get_setting('site_name', 'site')); ?></title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php $__env->startSection('page_title'); ?>
    <h3 class="page-title mbot10"><?php echo e(get_string('my_account')); ?></h3>
<?php $__env->stopSection(); ?>
<?php if(Session::has('account_updated')): ?>
    <div class="col s12">
        <div class="col s12 text-centered">
            <h5 class="color-primary"><?php echo e(get_string('account_updated')); ?></h5>
        </div>
    </div>
<?php endif; ?>
<div class="col s12 mtop10">
    <?php echo Form::open(['method' => 'put', 'url' => route('company_my_account_update', Auth::user()->id), 'files' => 'true']); ?>

    <div class="col m6 s6">
        <div class="form-group <?php echo e($errors->has('username') ? 'has-error' : ''); ?>">
            <?php echo Form::text('username', $user->username, ['id' => 'username', 'class' => 'form-control', 'placeholder' => get_string('username')]); ?>

            <?php echo Form::label('username', get_string('username')); ?>

            <?php if($errors->has('username')): ?>
                <span class="wrong-error">* <?php echo e($errors->first('username')); ?></span>
            <?php endif; ?>
        </div>
    </div>
    <div class="col m6 s6">
        <div class="form-group <?php echo e($errors->has('email') ? 'has-error' : ''); ?>">
            <?php echo Form::email('email', $user->email, ['id' => 'email', 'class' => 'form-control', 'placeholder' => get_string('email_address')]); ?>

            <?php echo Form::label('email', get_string('email_address')); ?>

            <?php if($errors->has('email')): ?>
                <span class="wrong-error">* <?php echo e($errors->first('email')); ?></span>
            <?php endif; ?>
        </div>
    </div>
    <div class="col m6 s6 clearfix">
        <div class="form-group <?php echo e($errors->has('password') ? 'has-error' : ''); ?>">
            <?php echo Form::password('password', ['id' => 'password', 'class' => 'form-control', 'placeholder' => get_string('password')]); ?>

            <?php echo Form::label('password', get_string('password')); ?>

            <?php if($errors->has('password')): ?>
                <span class="wrong-error">* <?php echo e($errors->first('password')); ?></span>
            <?php endif; ?>
        </div>
    </div>
    <div class="col m6 s6">
        <div class="form-group <?php echo e($errors->has('password') ? 'has-error' : ''); ?>">
            <?php echo Form::password('password_confirmation', ['id' => 'password_confirmation', 'class' => 'form-control', 'placeholder' => get_string('password_confirmation')]); ?>

            <?php echo Form::label('password_confirmation', get_string('password_confirmation')); ?>

            <?php if($errors->has('password')): ?>
                <span class="wrong-error">* <?php echo e($errors->first('password')); ?></span>
            <?php endif; ?>
        </div>
    </div>



    <div class="col s12"><h3 class="page-title mtop20"><?php echo e(get_string('company')); ?></h3></div>
    


    <div class="col m6 s6">
        <div class="form-group <?php echo e($errors->has('company') ? 'has-error' : ''); ?>">
            <?php echo Form::text('company', $user->company->company, ['id' => 'company', 'class' => 'form-control', 'placeholder' => get_string('company')]); ?>

            <?php echo Form::label('company', get_string('company')); ?>

            <?php if($errors->has('company')): ?>
                <span class="wrong-error">* <?php echo e($errors->first('company')); ?></span>
            <?php endif; ?>
        </div>
    </div>
    <div class="col m6 s12">
        <div class="form-group <?php echo e($errors->has('website') ? 'has-error' : ''); ?>">
            <?php echo Form::text('website', $user->company->website, ['class' => 'form-control', 'required', 'placeholder' => get_string('website')]); ?>

            <?php echo Form::label('website', get_string('website')); ?>

            <?php if($errors->has('website')): ?>
                <span class="wrong-error">* <?php echo e($errors->first('website')); ?></span>
            <?php endif; ?>
        </div>
    </div>
    <div class="col m6 s12">
        <div class="form-group <?php echo e($errors->has('contact_email') ? 'has-error' : ''); ?>">
            <?php echo Form::email('contact_email', $user->company->email, ['class' => 'form-control', 'required', 'placeholder' => get_string('contact') .' '. get_string('email_address')]); ?>

            <?php echo Form::label('contact_email', get_string('contact') .' '. get_string('email_address')); ?>

            <?php if($errors->has('contact_email')): ?>
                <span class="wrong-error">* <?php echo e($errors->first('contact_email')); ?></span>
            <?php endif; ?>
        </div>
    </div>
    <div class="col m6 s12">
        <div class="form-group <?php echo e($errors->has('contact_phone') ? 'has-error' : ''); ?>">
            <?php echo Form::text('contact_phone', $user->company->phone, ['id' => 'phone', 'class' => 'form-control', 'required', 'placeholder' => get_string('contact') .' '. get_string('phone')]); ?>

            <?php echo Form::label('contact_phone', get_string('contact') .' '. get_string('phone')); ?>

            <?php if($errors->has('contact_phone')): ?>
                <span class="wrong-error">* <?php echo e($errors->first('contact_phone')); ?></span>
            <?php endif; ?>
        </div>
    </div>
    
    <div class="row">
    <div class="col m6 s12">
        <div class="col s12">
            <div class="form-group <?php echo e($errors->has('location.address') ? 'has-error' : ''); ?>">
                <?php echo Form::text('location[address]', $user->company->location['address'], ['class' => 'form-control', 'required', 'placeholder' => get_string('address')]); ?>

                <?php echo Form::label('location[address]', get_string('address')); ?>

                <?php if($errors->has('location.address')): ?>
                    <span class="wrong-error">* <?php echo e($errors->first('location.address')); ?></span>
                <?php endif; ?>
            </div>
        </div>
        <div class="col s12">
            <div class="form-group <?php echo e($errors->has('location.city') ? 'has-error' : ''); ?>">
                <?php echo Form::text('location[city]', $user->company->location['city'], ['class' => 'form-control', 'required','placeholder' => get_string('city')]); ?>

                <?php echo Form::label('location[city]', get_string('city')); ?>

                <?php if($errors->has('location.city')): ?>
                    <span class="wrong-error">* <?php echo e($errors->first('location.city')); ?></span>
                <?php endif; ?>
            </div>
        </div>
        <div class="col s12">
            <div class="form-group <?php echo e($errors->has('location.town') ? 'has-error' : ''); ?>">
                <?php echo Form::text('location[town]', $user->company->location['town'], ['class' => 'form-control', 'required','placeholder' => get_string('town')]); ?>

                <?php echo Form::label('location[town]', get_string('town')); ?>

                <?php if($errors->has('location.town')): ?>
                    <span class="wrong-error">* <?php echo e($errors->first('location.town')); ?></span>
                <?php endif; ?>
            </div>
        </div>
        <div class="col s12">
            <div class="form-group <?php echo e($errors->has('location.zip') ? 'has-error' : ''); ?>">
                <?php echo Form::text('location[zip]', $user->company->location['zip'], ['class' => 'form-control', 'required','placeholder' => get_string('zip')]); ?>

                <?php echo Form::label('location[zip]', get_string('zip')); ?>

                <?php if($errors->has('location.zip')): ?>
                    <span class="wrong-error">* <?php echo e($errors->first('location.zip')); ?></span>
                <?php endif; ?>
            </div>
        </div>
        <div class="col m6 s12">
            <div class="form-group <?php echo e($errors->has('location.geo_lat') ? 'has-error' : ''); ?>">
                <?php echo Form::text('location[geo_lat]', $user->company->location['geo_lat'], ['class' => 'form-control', 'required','placeholder' => get_string('geo_lat')]); ?>

                <?php echo Form::label('location[geo_lat]', get_string('geo_lat')); ?>

                <?php if($errors->has('location.geo_lat')): ?>
                    <span class="wrong-error">* <?php echo e($errors->first('location.geo_lat')); ?></span>
                <?php endif; ?>
            </div>
        </div>
        <div class="col m6 s12">
            <div class="form-group <?php echo e($errors->has('location.geo_lon') ? 'has-error' : ''); ?>">
                <?php echo Form::text('location[geo_lon]', $user->company->location['geo_lon'], ['class' => 'form-control', 'required','placeholder' => get_string('geo_lon')]); ?>

                <?php echo Form::label('location[geo_lon]', get_string('geo_lon')); ?>

                <?php if($errors->has('location.geo_lon')): ?>
                    <span class="wrong-error">* <?php echo e($errors->first('location.geo_lon')); ?></span>
                <?php endif; ?>
            </div>
        </div>

    </div>
    <div class="col m6 s12">
        <div id="google-map"></div>
    </div>
    </div>

    <div class="col s12">
        <div class="input-group">
            <label class="input-group-btn">
                    <span class="btn btn-primary waves-effect"><?php echo e(get_string('company_logo')); ?> <i class="material-icons small">add_circle</i>
                    <?php echo Form::file('avatar', ['id' => 'avatar', 'class' => 'hidden']); ?>

                    </span>
            </label>
            <input type="text" class="form-control" readonly>
        </div>
        <?php if($errors->has('logo')): ?>
            <span class="wrong-error">* <?php echo e($errors->first('logo')); ?></span>
        <?php endif; ?>
    </div>
    <div class="col clearfix l4 m4 s6 mtop20">
        <div class="form-group">
            <button class="btn waves-effect" type="submit" name="action"><?php echo e(get_string('update_profile')); ?></button>
        </div>
    </div>
    <?php echo Form::close(); ?>

</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer'); ?>
<script src="https://maps.googleapis.com/maps/api/js?key=<?php echo e(get_setting('google_map_key', 'site')); ?>&libraries=places"></script>

<script>
    // Google Map
    $(document).ready(function() {
        if(typeof google !== 'undefined' && google){
            var map = new google.maps.Map(document.getElementById('google-map'), {
                center:{
                    lat: <?php echo e($user->company->location['geo_lat']); ?>, 
                    lng: <?php echo e($user->company->location['geo_lon']); ?>

                },
                zoom:4
            });
            var marker = new google.maps.Marker({
                position: {
                    lat: <?php echo e($user->company->location['geo_lat']); ?>,
                    lng: <?php echo e($user->company->location['geo_lon']); ?>

                },
                map: map,
                draggable: true
            });
            var infowindow = new google.maps.InfoWindow();
            var searchBox = document.getElementById('address-map');
            var autocomplete = new google.maps.places.Autocomplete(searchBox);

            autocomplete.bindTo('bounds', map);
            autocomplete.addListener('place_changed', function() {
                infowindow.close();
                marker.setVisible(false);
                var place = autocomplete.getPlace();
                if (!place.geometry) {
                    return;
                }

                // If the place has a geometry, then present it on a map.
                if (place.geometry.viewport) {
                    map.fitBounds(place.geometry.viewport);
                } else {
                    map.setCenter(place.geometry.location);
                    map.setZoom(15);
                }

                marker.setPosition(place.geometry.location);
                marker.setVisible(true);

                var address = '';
                if (place.address_components) {
                    address = [
                        (place.address_components[0] && place.address_components[0].short_name || ''),
                        (place.address_components[1] && place.address_components[1].short_name || ''),
                        (place.address_components[2] && place.address_components[2].short_name || '')
                    ].join(' ');
                }

                infowindow.setContent('<div><strong>' + place.name + '</strong><br>' + address);
                infowindow.open(map, marker);
            });

            google.maps.event.addListener(marker, 'position_changed', function () {
                var lat = marker.getPosition().lat();
                var lng = marker.getPosition().lng();
                $('[name="location[geo_lat]"]').val(lat);
                $('[name="location[geo_lon]"]').val(lng);
            });
        }
    });
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.company', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>