<?php $__env->startSection('title'); ?>
    <title><?php echo e(get_string('create_view_tour') . ' - ' . get_setting('site_name', 'site')); ?></title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('style'); ?>
    <link href="<?php echo e(URL::asset('assets/css/plugins/backend_jquery-ui.min.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php $__env->startSection('page_title'); ?>
    <h3 class="page-title mbot10"><?php echo e(get_string('create_view_tour')); ?></h3>
<?php $__env->stopSection(); ?>
<div class="col s12">
    <?php if(!$errors->isEmpty()): ?>
        <span class="wrong-error">* <?php echo e(get_string('validation_error')); ?></span>
        
    <?php endif; ?>
    <?php echo Form::open(['method' => 'post', 'url' => route('company_view_tour_store', $viewTour)]); ?>

        <div class="panel">
            <div class="panel-heading">
                <ul class="nav nav-tabs">
                    <li class="tab"><a href="#data-panel" data-toggle="tab"><?php echo e(get_string('data')); ?></a></li>
                </ul>
            </div>
        <div class="panel-body">
            <div class="tab-content">
                <div id="data-panel" class="tab-pane active">
                    <div class="col s6">
                        <div class="form-group  <?php echo e($errors->has('agent_id') ? 'has-error' : ''); ?>">
                            <select class="form-control agent-select" name="agent_id" placeholder="<?php echo e(get_string('agent')); ?>">
                                <?php $__currentLoopData = $agents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                <option class="agent-select-option" value="<?php echo e($key); ?>"><?php echo e($value); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                            </select>
                            <?php echo e(Form::label('agent_id', get_string('agent'))); ?>

                            <?php if($errors->has('agent_id')): ?>
                                <span class="wrong-error">* <?php echo e($errors->first('agent_id')); ?></span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="col s6">
                        <div class="form-group  <?php echo e($errors->has('price') ? 'has-error' : ''); ?>">
                            <?php echo e(Form::number('price', null, ['class' => 'category-select form-control', 'min' => 0, 'step' => 1, 'placeholder' => get_string('price')])); ?>

                            <?php echo e(Form::label('price', get_string('price'))); ?>

                            <?php if($errors->has('price')): ?>
                                <span class="wrong-error">* <?php echo e($errors->first('price')); ?></span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="col s12 well checkbox-grid">
                        <p><?php echo e(get_string('properties')); ?></p>
                        <div id="properties-list">
                            
                        </div>
                    </div>
                    <div class="col l6 m6 s12">
                        <div class="form-group  <?php echo e($errors->has('start_date') ? 'has-error' : ''); ?>">
                            <?php echo e(Form::text('start_date', null, ['class' => 'start_date-picker form-control', 'placeholder' => get_string('start_date')])); ?>

                            <?php echo e(Form::label('start_date', get_string('start_date'))); ?>

                            <?php if($errors->has('start_date')): ?>
                                <span class="wrong-error">* <?php echo e($errors->first('start_date')); ?></span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="col l6 m6 s12">
                        <div class="form-group  <?php echo e($errors->has('end_date') ? 'has-error' : ''); ?>">
                            <?php echo e(Form::text('end_date', null, ['class' => 'end_date-picker form-control', 'placeholder' => get_string('end_date')])); ?>

                            <?php echo e(Form::label('end_date', get_string('end_date'))); ?>

                            <?php if($errors->has('end_date')): ?>
                                <span class="wrong-error">* <?php echo e($errors->first('end_date')); ?></span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="col l6 m6 s12">
                        <div class="form-group  <?php echo e($errors->has('location') ? 'has-error' : ''); ?>">
                            <?php echo e(Form::text('location', null, ['class' => 'feet-area form-control', 'placeholder' => get_string('location')])); ?>

                            <?php echo e(Form::label('location', get_string('location'))); ?>

                            <?php if($errors->has('location')): ?>
                                <span class="wrong-error">* <?php echo e($errors->first('location')); ?></span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="col s6">
                        <div class="form-group  <?php echo e($errors->has('accomodation') ? 'has-error' : ''); ?>">
                            <?php echo e(Form::select('accomodation', [0 => get_string('no'), 1 => get_string('yes')], null, ['class' => 'category-select form-control', 'placeholder' => get_string('accomodation')])); ?>

                            <?php echo e(Form::label('accomodation', get_string('accomodation'))); ?>

                            <?php if($errors->has('accomodation')): ?>
                                <span class="wrong-error">* <?php echo e($errors->first('accomodation')); ?></span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="col s6">
                        <div class="form-group  <?php echo e($errors->has('airport_pickup') ? 'has-error' : ''); ?>">
                            <?php echo e(Form::select('airport_pickup', [0 => get_string('no'), 1 => get_string('yes')], null, ['class' => 'category-select form-control', 'placeholder' => get_string('airport_pickup')])); ?>

                            <?php echo e(Form::label('airport_pickup', get_string('airport_pickup'))); ?>

                            <?php if($errors->has('airport_pickup')): ?>
                                <span class="wrong-error">* <?php echo e($errors->first('airport_pickup')); ?></span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="col s6">
                        <div class="form-group  <?php echo e($errors->has('air_flight_tickets') ? 'has-error' : ''); ?>">
                            <?php echo e(Form::select('air_flight_tickets', [0 => get_string('no'), 1 => get_string('yes')], null, ['class' => 'category-select form-control', 'placeholder' => get_string('air_flight_tickets')])); ?>

                            <?php echo e(Form::label('air_flight_tickets', get_string('air_flight_tickets'))); ?>

                            <?php if($errors->has('air_flight_tickets')): ?>
                                <span class="wrong-error">* <?php echo e($errors->first('air_flight_tickets')); ?></span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="col s6">
                        <div class="form-group  <?php echo e($errors->has('lunch') ? 'has-error' : ''); ?>">
                            <?php echo e(Form::select('lunch', [0 => get_string('no'), 1 => get_string('yes')], null, ['class' => 'category-select form-control', 'placeholder' => get_string('lunch')])); ?>

                            <?php echo e(Form::label('lunch', get_string('lunch'))); ?>

                            <?php if($errors->has('lunch')): ?>
                                <span class="wrong-error">* <?php echo e($errors->first('lunch')); ?></span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="col s6">
                        <div class="form-group  <?php echo e($errors->has('payment_method') ? 'has-error' : ''); ?>">
                            <?php echo e(Form::select('payment_method', $paymentMethods, null, ['class' => 'category-select form-control', 'placeholder' => get_string('payment_method')])); ?>

                            <?php echo e(Form::label('payment_method', get_string('payment_method'))); ?>

                            <?php if($errors->has('payment_method')): ?>
                                <span class="wrong-error">* <?php echo e($errors->first('payment_method')); ?></span>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col clearfix s12 mtop10">
                <div class="form-group">
                    <button class="btn waves-effect" type="submit" name="action"><?php echo e(get_string('create_view_tour')); ?></button>
                    <a href="<?php echo e(route('company_view_tour')); ?>" class="btn waves-effect"><?php echo e(get_string('back')); ?></a>
                </div>
            </div>
            <?php echo e(Form::hidden('company_id', Auth::user()->id)); ?>

            <?php echo Form::close(); ?>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
    <script>
        $(document).ready(function() {

            // Datepickers
            $('.start_date-picker').datepicker({
                dateFormat: 'dd/mm/yy',
                minDate: 0,
                onSelect: function(dateText, inst) {
                    var startDate = $(this).datepicker('getDate');
                    if($('.end_date-picker').hasClass('hasDatePicker')){
                        $('.end_date-picker').datepicker('destroy');
                    }
                    startDate.setDate(startDate.getDate() + 1);
                    $("[name='start_date']").val(dateText);
                    $("[name='end_date']").removeAttr('disabled');
                    $('.end_date-picker').datepicker({
                        dateFormat: 'dd/mm/yy',
                        minDate: startDate,
                        onSelect: function(dateText, inst) {
                            $("[name='end_date']").val(dateText);
                        }
                    });
                }
            });

            if($('.agent-select').val() != '') getPropertiesByAgent($('.agent-select').val());

            $(this).on('click change', '.agent-select', function () {

                if(!(this.selectedIndex == -1)) {
                    var id = $(this).val();
                    getPropertiesByAgent(id);
                }

            });

        });

        function getPropertiesByAgent(id) {

            $.ajax({
                url: '<?php echo e(route('company_properties_by_agent')); ?>',
                type: 'post', 
                data: {_token: $('[name="_token"]').val(), id: id},
                success: function (data){
                    
                    var html = '';
                    $.each(data, function(key, value) {
                        html += '<div class="col s2"><div class="form-group"><input type="checkbox" name="properties[]" value="' + key + '" class="filled-in primary-color" id="'+ key +'" /><label for="'+ key +'"></label><span class="checkbox-label">'+ value +'</span></div></div>';
                    });

                    $('#properties-list').html(html);
                }
            });
        }
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.company', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>