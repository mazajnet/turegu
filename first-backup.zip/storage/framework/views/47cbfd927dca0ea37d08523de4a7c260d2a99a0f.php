<?php $__env->startSection('title'); ?>
    <title><?php echo e(get_string('view_tours') . ' - ' . get_setting('site_name', 'site')); ?></title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<?php $__env->startSection('page_title'); ?>
    <h3 class="page-title mbot10"><?php echo e(get_string('view_tours')); ?></h3>
<?php $__env->stopSection(); ?>
    <div class="col l6 m4 s12 right right-align mbot10">
        <a href="<?php echo e(route('company_view_tour_create')); ?>" class="btn waves-effect"> <?php echo e(get_string('create_view_tour')); ?> <i class="material-icons small">add_circle</i></a>
    </div>
    <div class="col s12">
        <?php if($viewTours->count()): ?>
        <div class="table-responsive">
        <table class="table bordered striped">
            <thead class="thead-inverse">
            <tr>
                <th>
                    <input type="checkbox" class="filled-in primary-color" id="select-all" />
                    <label for="select-all"></label>
                </th>
                <th><?php echo e(get_string('agent')); ?></th>
                <th><?php echo e(get_string('date')); ?></th>
                <th><?php echo e(get_string('number_of_properties')); ?></th>
                <th><?php echo e(get_string('number_of_days')); ?></th>
                <th><?php echo e(get_string('price')); ?></th>
                <th class="icon-options"><?php echo e(get_string('options')); ?></th>
            </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $viewTours; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $viewTour): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                    <tr>
                        <td>
                            <input type="checkbox" class="filled-in primary-color" id="<?php echo e($viewTour->id); ?>" />
                            <label for="<?php echo e($viewTour->id); ?>"></label>
                        </td>
                        <td><?php if($viewTour->agent): ?> <?php echo e($viewTour->agent->username); ?>  <?php else: ?> <i class="small material-icons color-red">clear</i> <?php endif; ?></td>
                        <td><?php echo e($viewTour->start_date .' - '. $viewTour->end_date); ?></td>
                        <td><?php echo e($viewTour->number_of_properties); ?> </td>
                        <td><?php echo e($viewTour->number_of_days); ?> </td>
                        <td><?php echo e(get_setting('currency', 'site')); ?><?php echo e($viewTour->price); ?> </td>
                        <td>
                            <div class="icon-options">
                                <a href="<?php echo e(route('company_view_tour_edit', $viewTour)); ?>"><i class="small material-icons color-primary">mode_edit</i></a>
                                <a href="#" class="delete-button" data-id="<?php echo e($viewTour->id); ?>"><i class="small material-icons color-red">delete</i></a>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
            </tbody>
        </table>
        </div>
        <?php echo e($viewTours->links()); ?>

        <?php else: ?>
            <strong class="center-align"><?php echo e(get_string('no_results')); ?></strong>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
<script>
    $(document).ready(function(){
        $('.delete-button').click(function(event){
            event.preventDefault();
            var id = $(this).data('id');
            var selector = $(this).parents('tr');
            var token = $('[name="_token"]').val();
            bootbox.confirm({
                title: '<?php echo e(get_string('confirm_action')); ?>',
                message: '<?php echo e(get_string('delete_confirm')); ?>',
                onEscape: true,
                backdrop: true,
                buttons: {
                    cancel: {
                        label: '<?php echo e(get_string('no')); ?>',
                        className: 'btn waves-effect'
                    },
                    confirm: {
                        label: '<?php echo e(get_string('yes')); ?>',
                        className: 'btn waves-effect'
                    }
                },
                callback: function (result) {
                    if(result){
                        $.ajax({
                            url: '<?php echo e(route('company_view_tour_delete')); ?>',
                            type: 'post',
                            data: {_method: 'delete', _token :token, id: id},
                            success:function(msg) {
                                selector.remove();
                                toastr.success(msg);
                            },
                            error:function(msg){
                                toastr.error(msg.responseJSON);
                            }
                        });
                    }
                }
            });
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.company', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>